var id = 'dialogTestCCRTDropdownFilter';
var dialog = popups.createPopup(id, 0);
popups.append(dialog, $('#' + id + 'Content'));
dialog.css('background', 'white')
//dialog.css('min-width', '50%')
dialog.css('right', '10px')
dialog.css('bottom', '60px')


$scope.createDeskHierarchyHelper()

popups.filterDropdownDeskList = function filterDropdownDeskList() {

    var matches = popups.permissions;


    $.each(window.allOptions, function filter(k, opt) {
        opt.hidden = true
        opt.enabled = false;
    })

    var isOPCO = matches.includes('ccrt-access-opco')

    if (isOPCO) {
        console.log('show all')
        $scope.ui.opco.hidden = false;

        $.each(window.allOptions, function filter(k, opt) {
            opt.hidden = false
            opt.enabled = true;
        })

    } else {
        console.log('filtering')
        $scope.ui.opco.hidden = true;

        $.each(window.allOptions, function filter(k, opt) {
            if (opt.level == 0) {
                return;
            }
            if (opt.name == null) {
                return
            }
            opt.hidden = false;
            var name = opt.name.toLowerCase().split(' ').join('-');
            //var isDesk =
            console.log('search for ', name, opt.name)
            var userCanSeeOption = popups.doesHaveE3Group(name)
            if (opt.level == 1) {
                if (userCanSeeOption) {
                    opt.enabled = true
                    opt.hidden = false
                } else {
                    opt.hidden = true
                }
            } else {
                if (opt.level == 3) {
                    var userCanSeeDesk = popups.doesHaveE3Group(name + '-desk')

                    if (userCanSeeDesk) {
                        debugger
                    }
                }
                if (userCanSeeOption) {
                    opt.hidden = false
                    opt.enabled = true
                    if (opt.parent.hidden) {
                        //  opt.parent.enabled = false
                        opt.parent.hidden = false;
                    }

                    if (opt.parent.parent) {
                        if (opt.parent.parent.hidden) {
                            // opt.parent.parent.enabled = false
                            opt.parent.parent.hidden = false;
                        }
                    }

                }
            }
        })

    }

}

popups.convertNameToE3Permission = function convertNameToE3Permission(name) {
    var e3Name = name.toLowerCase();
    if (name.includes('-') == false) {
        //  e3Name = 'ccrt-access-'+name
        //} else {
        e3Name = name.toLowerCase().split(' ').join('-');
        e3Name = 'ccrt-access-' + e3Name
    }

    return e3Name
}


popups.doesHaveE3Group = function doesHaveE3Group(name) {
    var groupName = popups.convertNameToE3Permission(name)
    var hasEntitlement = popups.permissions.includes(groupName)
    return hasEntitlement
}

popups.permissions = [];
popups.hasPermission = function hasPermission(name, preAmble) {
    if (name == null) {
        return false;
    }
    var e3Name = popups.convertNameToE3Permission(name);
    if (preAmble) {
        e3Name += '-' + preAmble;
    }
    return popups.permissions.includes(e3Name)
}
popups.togglePermission = function togglePermission(name, preAmble) {
    var newArray = []
    var e3Name = popups.convertNameToE3Permission(name);
    if (preAmble) {
        e3Name += '-' + preAmble;
    }

    if (popups.hasPermission(e3Name)) {
        $.each(popups.permissions, function removePermission(k, v) {
            if (v == e3Name) {
                return;
            }
            newArray.push(v)
        })
        popups.permissions = newArray;
    } else {
        popups.permissions.push(e3Name)
    }
    $scope.remoting.data.userGroupOf = popups.permissions;
    popups.filterDropdownDeskList()
    popups.showDropdown();
}

popups.showDropdown = function showDropdown() {
    var x42NavBarNav_DropDown = $('ul.navbar-nav').find('li.dropdown');
    //x42NavBarNav_DropDown.addClass('open')
    x42NavBarNav_DropDown.mouseenter();
}

//popups.showLastDialog();

// setTimeout($scope.popups.showDialogsDemo, 500)
};



$scope.createDeskHierarchyHelper = function createDeskHierarchyHelper() {
    function DeskHierarchyHelper() {
        var p = this;
        var self = this;
        self.settings = {}
        self.data = {};

        p.init = function init(config) {
            self.settings = dv(config, {})
        };

        p.createDeskHierarchyTree = function createDeskHierarchyTree(fxDone) {
            var qdpPump = $scope.dep.qdpPump
            var envVariables = $scope.dep.envVariables

            window.displayItems = function displayItems() {
                var consoleOutput = []
                consoleOutput.push('var allSubsites =')
                consoleOutput.push(window.allSubsites)
                consoleOutput.push('')
                consoleOutput.push('var all_tabs =')
                consoleOutput.push(window.all_tabs)
                consoleOutput.push('')
                consoleOutput.push('var subsitesForUser =')
                consoleOutput.push(window.subsitesForUser)
                consoleOutput.push('')
                console.log(consoleOutput.join('\n'))

            }
            // debugger;
            qdpPump(envVariables.layoutManagerServer)
                .qdpCall({
                    func: '.ccrt.layout.ALL_SUBSITES',

                })
                .then(function on_ALL_SUBSITES(allSubsites) {
                    console.debug('on_ALL_SUBSITES', allSubsites);
                    console.table(allSubsites)

                    window.allSubsites = JSON.stringify(allSubsites)
                    var tree = {};



                })
                .catch(function onError(reason) {
                    console.error('could not recieve ALL_SUBSITES', reason);
                });


            qdpPump(envVariables.layoutManagerServer)
                .qdpCall({
                    func: '.ccrt.layout.ALL_TABS',

                })
                .then(function on_ALL_TABS(all_tabs) {
                    //    debugger
                    window.all_tabs = JSON.stringify(all_tabs)
                    console.debug('on_ALL_TABS', all_tabs);
                })
                .catch(function onError(reason) {
                    console.error('could not get ALL_TABS',
                        reason);
                });


            qdpPump(envVariables.layoutManagerServer)
                .qdpCall({
                    func: '.ccrt.layout.getSubsitesForUser',
                    arg1: '',
                    type1: 'sym',
                    req1: 'true',
                })
                .then(function on_getSubsitesForUser(subsitesForUser) {
                    window.subsitesForUser = JSON.stringify(subsitesForUser)
                    //  debugger
                    console.debug('getSubsitesForUser', userHasSubsiteFeature);

                })
                .catch(function onError(reason) {
                    console.error('could not get getSubsitesForUser',
                        reason);
                });


            p.getThing = function getThing(sdf) {
                qdpPump(envVariables.layoutManagerServer)
                    .qdpCall({
                        func: '.ccrt.layout.getSubsitesForUser',
                        /*  arg1: 'feature',
                         type1: 'sym',
                         req1: 'true',

                         arg2: 'subsite',
                         type2: 'sym',
                         req2: 'true',*/
                    })
                    .then(function onRecieveSubsiteFeatureEntitlement(userHasSubsiteFeature) {
                        debugger
                        console.debug('userHasSubsiteFeature', userHasSubsiteFeature);
                        //userHasSubsiteFeature = false;
                        currentUser.userHasSubsiteFeature = userHasSubsiteFeature;
                        if (userHasSubsiteFeature) {
                            $rootScope.$broadcast('$feature.userHasSubsites', userHasSubsiteFeature)
                        }
                    })
                    .catch(function onError(reason) {
                        console.error('could not determine entitlement to subsite feature',
                            reason);
                    });
            }

        }

        /**
         * Disables/Enables and Hides Tree nodes
         * @param fxDone
         */
        p.filterDeskHierarchy = function filterDeskHierarchy(fxDone) {

        }

        /**
         * Modifies pivot table when tree node clicked
         * @param itemClicked
         * @param fxDone
         */
        p.onUserClickDeskHierarchy = function onUserClickDeskHierarchy(itemClicked, fxDone) {

        }

        p.openDeskHierarchyVerificationTool = function openDeskHierarchyVerificationTool() {
            window.showFilterDebugDialog();
        }

        function defineQMethods() {
            p.q = {};
            p.q.getItem = function getItem() {

            }
        }

        defineQMethods();

        //debugger;
        function defineDeskHierarchyVerificationTool() {

            //debugger;
            p.showFilterDebugDialog = function showFilterDebugDialog(open) {
                $scope.remoting.txtSearchName = 'jay'
                $scope.remoting.onSearchNames(false, function onGotUsers(users) {
                    if (users.length == 0) {
                        return
                    }
                    var firstUser = users[0];
                    self.testUserPermission(firstUser);
                })
                popups.dialogTestCCRTDropdownFilter.show();
                //popups.dialogTestQCalls.show();
                //if (open) {
                //    $('.btnHideDialogContent').click()
                //}

            }
            window.showFilterDebugDialog = self.showFilterDebugDialog;
            p.testUserPermission = function showFilterDebugDialog(user) {
                console.log('ok', user)

                $scope.remoting.txtUserGroupOf = user.uid;
                $scope.remoting.data.fxOnUserGroupOf = function onHave(matches) {
                    console.log('...', '|||', '===', matches)
                    popups.permissions = matches;
                    popups.filterDropdownDeskList(matches)
                }
                $scope.remoting.onGetUserGroupOf()

                //$scope.remoting
            }
        }

        defineDeskHierarchyVerificationTool();

    }

    var dHH =
        $scope.dHH = $scope.deskHierarchyHelper = new DeskHierarchyHelper();

    dHH.init();

    dHH.createDeskHierarchyTree()
    $scope.enable_DeskHierarchyHelper_LocalUIMode(dHH)

    dHH.createDeskHierarchyTree(onFinished_createDeskHierarchyTree)
    function onFinished_createDeskHierarchyTree(tree) {
        dHH.filterDeskHierarchy();
    }

}


$scope.enable_DeskHierarchyHelper_LocalUIMode = function enable_DeskHierarchyHelper_LocalUIMode(dHH) {

    dHH.settings.localUI = true;
    var self = dHH;

    var p = self;


    p.createDeskHierarchyTree = function createDeskHierarchyTree(fxDone) {
        $scope.data.deskList = [
            /*  {
             "name": "Complex ",
             "children": [{"name": "Function ", "children": [{"name": "Desk Name"}]}]
             },*/ {
                "name": "Credit",
                "children": [{
                    "name": "Primary",
                    "children": [{"name": "Credit Primary"}]
                }, {
                    "name": "Trading",
                    "children": [{"name": "US IG"}, {"name": "US High Yield"}, {"name": "US Index"}, {"name": "EU Flow"}, {"name": "Asia Credit"}, {"name": "US Lev Loans"}, {"name": "Corp Retail"}, {"name": "Distressed Trading - JP"}, {"name": "Distressed Trading - EU"}, {"name": "Distressed Trading - AP"}, {"name": "Distressed Trading - NA"}]
                }, {"name": "Mgmt", "children": [{"name": "Credit Corp Mgmt"}]}, {
                    "name": "EBS",
                    "children": [{"name": "Credit Corp EBS"}]
                }]
            }, {
                "name": "DSP",
                "children": [{"name": "Trading", "children": [{"name": "DSP Ongoing"}]}, {
                    "name": "Legacy",
                    "children": [{"name": "DSP Legacy"}]
                }, {"name": "EBS", "children": [{"name": "DSP EBS"}]}]
            }, {
                "name": "Macro",
                "children": [{"name": "Trading", "children": [{"name": "Macro Retail"}]}]
            }, {
                "name": "Munis",
                "children": [{
                    "name": "Primary",
                    "children": [{"name": "Munis Primary"}]
                }, {"name": "Trading", "children": [{"name": "Munis Trading"}]}, {
                    "name": "EBS",
                    "children": [{"name": "Muni EBS"}]
                }]
            }, {
                "name": "Repo",
                "children": [{"name": "Repo", "children": [{"name": "Repo EU"}, {"name": "Repo US"}]}]
            }, {
                "name": "SPG",
                "children": [{"name": "Primary", "children": [{"name": "SPG Primary"}]}, {
                    "name": "Lending",
                    "children": [{"name": "US Warehouse"}, {"name": "US CREL"}, {"name": "EU Lending"}]
                }, {
                    "name": "Trading",
                    "children": [{"name": "US SPG Credit"}, {"name": "US SPG Agency"}, {"name": "EU SPG Credit"}, {"name": "SPG Retail"}]
                }, {"name": "Mgmt", "children": [{"name": "SPG Mgmt"}]}, {
                    "name": "EBS",
                    "children": [{"name": "SPG EBS"}]
                }, {"children": [{}]}]
            }]
        var allOptions = []

        // This function handles arrays and objects
        function eachRecursive(obj, tabs, level) {
            if (tabs == null) {
                tabs = ''
                level = 0
            }
            tabs += '\t';

            console.log(tabs, 'in tree', obj.name, obj)


            obj.level = level;
            allOptions.push(obj)
            if (obj.children == null) {
                return
            }

            $.each(obj.children, function procChild(k, child) {
                //if ( child.children ) {
                child.parent = obj;
                eachRecursive(child, tabs, level + 1);
                // }
            })

            /*if (typeof obj[k] == "object" && obj[k] !== null) {
             eachRecursive(obj[k]);
             }
             else {

             }*/

            /*    console.log('in tree', obj.name)
             if ( child.children ) {
             eachRecursive(child, tabs);
             }
             // do something...
             }*/
        }

        var y = {};
        y.children = $scope.data.deskList;
        eachRecursive(y);

        window.allOptions = allOptions;

        if (fxDone) {
            fxDone()
        }
    }


    p.filterDeskHierarchy = function filterDeskHierarchy(fxDone) {


        if (fxDone) {
            fxDone()
        }
    }


    return;


    dHH.createDeskHierarchyTree(onFinished_createDeskHierarchyTree)
    function onFinished_createDeskHierarchyTree(tree) {
        dHH.createDeskHierarchyTree(onFinishedCreateTree);
    }

}
