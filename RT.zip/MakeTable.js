/*
 */


var sh = require('shelpers').shelpers;
var shelpers = require('shelpers');
var request = require('request')
var EasyRemoteTester = shelpers.EasyRemoteTester;

var $ = {};
$.each = sh.each

function MakeTable() {
    var p = MakeTable.prototype;
    p = this;
    var self = this;

    self.settings = {}
    self.data = {};

    p.init = function init(config) {
        self.settings = sh.dv(config, {});
        self.settings.output = sh.dv(self.settings.output, {});
        var t = sh.timer()
        var contents = sh.readJSONFile(self.settings.file)
        t.time('how long to load file?')

        self.setupData()
        return;
    }

    p.setupData = function setupData() {
        var allSubsites = sh.readJSONFile('allSubsites.json')
        var all_tabs = sh.readJSONFile('all_tabs.json')
        var subsitesForUser =sh.readJSONFile('subsitesForUser.json')

        self.data.allSubsites = allSubsites;
        self.data.all_tabs = all_tabs;
        self.data.subsitesForUser = subsitesForUser;

        var showInput = false;
        if (showInput) {
            var columns = sh.log.table(allSubsites, true);
            var columns = sh.log.table(self.data.all_tabs, true);
            var columns = sh.log.table(self.data.subsitesForUser, true);
        }

       // var columns = sh.log.table(self.data.all_tabs, true);


        //return;
        self.indexSubsites(self.data.subsitesForUser)
        //console.log(allSubsites[0])
       // sh.x()
        // return
        self.indexAllTabs(self.data.all_tabs)


        self.testSelection();
    }

    p.indexSubsites = function indexAllTabs(inputSubsiteList) {
        var tree = [];
        var allSubsites = []
        var dictByLevel1 = {}
        var dictByLevel2 = {}
        $.each(inputSubsiteList, function onAddSubsite(k, sub) {
            var newSubsite = {};
            newSubsite.type = sub.Family;
            newSubsite.level = sub.Level1Order
            newSubsite.subsite = sub.Subsite
            newSubsite.name = sub.Subsite;
            
            if (newSubsite.level == 0) {
                tree.push(newSubsite)
                dictByLevel1[sub.Level1] = newSubsite
            }
            if (newSubsite.level == 1) {
                tree.push(newSubsite)
                dictByLevel1[sub.Level1] = newSubsite
            }

            if (newSubsite.level == 2) {
                var parentNode = dictByLevel1[sub.Level1]
                if (parentNode == null) {
                    throw new Error(['parent is null ', JSON.stringify(sub)].join(', '));
                }
                if (parentNode.children == null) {
                    parentNode.children = []
                }


                if (sub.Level1 == 'SPG') {
                    //debugger
                }
                //console.error('adding ', sub)

                var parentNode2ndLevel = dictByLevel2[sub.Level1 + '_' + sub.Level2]
                if (parentNode2ndLevel == null) {
                    var parentNode2ndLevel = {};
                    parentNode2ndLevel.name = sub.Level2
                    parentNode2ndLevel.children = [];
                    dictByLevel2[sub.Level2] = parentNode2ndLevel
                    parentNode.children.push(parentNode2ndLevel)
                    newSubsite.parent = parentNode;
                    //throw new Error( ['parentNode2ndLevel is null ',  JSON.stringify(sub)].join(', ') );
                }
                //   parentNode.children.push(parentNode2ndLevel)
                parentNode2ndLevel.children.push(newSubsite);
                newSubsite.parent = parentNode2ndLevel; 
            }
            //newSubsite.parent =
            // console.log(sub)
            allSubsites.push(newSubsite)
        })


        var showOutput = false;
        showOutput = true;
        if (showOutput) {
            console.log('outputTree:')
            //var columns = sh.log.table(allSubsites2, true);
            //debugger
            var root = {};
            root.name = 'root'
            root.children = tree
            self.utils.traverseTreePrint(root)
            self.data.root = root;
            //console.table(allSubsites)
        }
        
        self.data.allSubsites = allSubsites; 
    }

    p.indexAllTabs = function indexAllTabs(inputTabList) {
        var dictSubsiteToTabs = {};
        self.data.dictSubsiteToTabs = dictSubsiteToTabs;

        $.each(inputTabList, function onAddSubsite(k, tab) {
            var key = [tab.Complex, tab.Function, tab.Desk].join('_')
            if (key.slice(-1) == '_') {
                key = key.slice(0, -1)
            }
            if (key.slice(-1) == '_') {
                key = key.slice(0, -1)
            }
            if (key == '') {
                key = 'opco'
            }
            var tabs = dictSubsiteToTabs[key]
            if (tabs == null) {
                tabs = [];
            }
            tabs.push(tab)
            dictSubsiteToTabs[key] = tabs
        })

        var showOutput = false;
        //showOutput = true;
        if (showOutput) {
            console.log('indexAllTabs:')
            console.log(dictSubsiteToTabs)
        }
        
        
        //add tab groups to subsites -
        $.each(self.data.allSubsites, function addTabsToSubsite(k,subsite){

            var itemKey = []
            itemKey.push(subsite.name)
            if ( subsite.name.toLowerCase() == 'opco') {
                itemKey = ['opco']
            }
            if ( subsite.level > 1) {
                if (subsite.parent) {
                    itemKey.push(subsite.parent.name)
                }

                if (subsite.parent && subsite.parent.parent) {
                    itemKey.push(subsite.parent.parent.name)
                }
            }
            itemKey =itemKey.reverse()
            var keyTabs = itemKey.join('_')
            var tabs = self.data.dictSubsiteToTabs[keyTabs]
            if ( tabs  == null ) {
               // throw new Error(['did not find tabs', keyTabs, itemKey].join(' '))
            }
            subsite.tabs = tabs;
            //console.log(k, subsite)
            //console.log(k, subsite)
        })

        var showOutput = false;
        //showOutput = true;

        if ( showOutput ) {
            console.log('all subsites with tabsets attached:')
            console.log(self.data.allSubsites)
        }
        
    }

    p.testSelection = function tesSelection() {
        self.selectItem(1)
        self.selectItem(2, 2)
        self.selectItem(3, 2, 1)
    }

    p.selectItem = function selectItem(index1, index2, index3, fxDone) {

        var itemKey = []
        var item1 = self.data.root.children[index1 - 1]
        itemKey.push(item1.name)
        if ( item1.name.toLowerCase() == 'opco') {
            itemKey = ['opco']
        }
        if (index2) {
            var item2 = item1.children[index2 - 1]
            itemKey.push(item2.name)
        }

        if (index3) {
            var item3 = item2.children[index3 - 1]
            itemKey.push(item3.name)
        }

        var key = itemKey.join('_')
        //console.error('itemKey', key)
        var tabs = self.data.dictSubsiteToTabs[key]
        //console.error('\t', 'itemKey', tabs)

        if ( fxDone ) {
            fxDone(tabs, key)
        }
    }


    function defineUtils() {
        p.utils = {};

        p.utils.traverseTree = function traverseTree() {
            function eachRecursive(obj, tabs, level) {
                if (tabs == null) {
                    tabs = ''
                    level = 0
                }
                tabs += '\t';

                console.log(tabs, 'in tree', obj.name, obj)


                obj.level = level;
                allOptions.push(obj)
                if (obj.children == null) {
                    return
                }

                $.each(obj.children, function procChild(k, child) {
                    //if ( child.children ) {
                    child.parent = obj;
                    eachRecursive(child, tabs, level + 1);
                    // }
                })

                /*if (typeof obj[k] == "object" && obj[k] !== null) {
                 eachRecursive(obj[k]);
                 }
                 else {

                 }*/

                /*    console.log('in tree', obj.name)
                 if ( child.children ) {
                 eachRecursive(child, tabs);
                 }
                 // do something...
                 }*/
            }
        }


        p.utils.traverseTreePrint = function eachRecursive(obj, tabs, level) {
            if (tabs == null) {
                tabs = ''
                level = 0
            }
            tabs += '\t';

            childrenLength = ''
            if (obj.children) {
                var childrenLength = obj.children.length
            }
            console.log(tabs, '-', obj.name, childrenLength)


            obj.level = level;
            // allOptions.push(obj)
            if (obj.children == null) {
                return
            }

            $.each(obj.children, function procChild(k, child) {
                //if ( child.children ) {
                child.parent = obj;
                eachRecursive(child, tabs, level + 1);
                // }
            })

        }
    }

    defineUtils()

    p.test = function test() {
    }

    p.proc = function debugLogger() {
        if (self.silent == true) {
            return
        }
        sh.sLog(arguments)
    }

}

exports.MakeTable = MakeTable;

console.log(exports.reloadAny, module.parent)
if (module.parent == null || exports.reloadAny) {
    var i = new MakeTable();
    var config = {}
    config.fxDone = function onTestComplete(list, data) {
    }
    i.init(config)
}