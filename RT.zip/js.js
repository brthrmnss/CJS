
$scope.ui = {};

$scope.ui.opco = {};

$scope.ctlFilterOptions = []
$scope.data.ctlFilterOptions = [];

$scope.data.dictFields2 = {};
$scope.data.dictFields2['complex'] = ['SPG', 'Credit', 'Munis']

$scope.data.dictFields2['function'] = [
    {complex: 'SPG', 'function': 'Trading'},
    {complex: 'SPG', 'function': 'Lending'}]


$scope.data.dictFields2['desk'] = ['US Lev Loans', 'US IG',
    'US SPG Credit', 'US SPG Agency']

$scope.ui.selectItem = function selectItem(propName, item) {
    var oldItem = $scope.data[propName]
    if (oldItem) {
        oldItem.selected = false;
    }

    if (item) {
        item.selected = true;
    }

    $scope.data[propName] = item;
}

$scope.ui.onViewTreeOPCO = function onViewTreeOPCO(selectedComplex, $event) {
    console.log('rolled over opco', null)//,  $event.target)
    $scope.ui.selectItem('currentComplex', null);
    $scope.ui.selectItem('currentFunction', null);
    //   $scope.ui.selectItem('currentComplex', null);

    /*var target = $event.target
     var ui = $(target)
     if ( ui.hasClass('glyphicon')) {
     ui = ui.parent();
     }

     var position = $(ui).offset();
     position.left += ui.width();
     position.left += 20;
     position.top -= 1;*/

    $('.listCurrentComplexChildren').hide()
    $('.listCurrentFunctionChildren').hide();
}
$scope.ui.onViewTreeComplex = function onViewTreeComplex(selectedComplex, $event) {
    console.log('rolled over', selectedComplex) //,  $event.target)
    $scope.ui.selectItem('currentComplex', selectedComplex);
    $scope.ui.selectItem('currentFunction', null);

    var target = $event.target
    var ui = $(target)
    if (ui.hasClass('glyphicon')) {
        ui = ui.parent();
    }
    if (ui.is('span')) {
        ui = ui.parent();
    }

    var position = $(ui).offset();
    position.left += ui.width();
    position.left += 20;
    position.top -= 1;

    console.log('movie complexChildren to', position)
    $('.listCurrentComplexChildren').offset(position)

    var randomId = Math.random();
    $scope.data.onViewTreeComplex = randomId

    setTimeout(function on() {
        if ($scope.data.onViewTreeComplex != randomId) {
            return
        }
        var position = $(ui).offset();
        position.left += ui.width();
        position.left += 20;
        position.top -= 1;
        $('.listCurrentComplexChildren').offset(position)
    }, 200)
    $('.listCurrentComplexChildren').show()
    $('.listCurrentFunctionChildren').hide();
}

$scope.ui.onViewTreeFunction = function onViewTreeFunction(selectedFunction, $event) {
    console.log('rolled over', selectedFunction) //,  $event.target)
    $scope.ui.selectItem('currentFunction', selectedFunction);


    $('.listCurrentFunctionChildren').show();
    var target = $event.target
    var ui = $(target)
    if (ui.hasClass('glyphicon')) {
        ui = ui.parent();
    }

    var position = $(ui).offset();
    position.left += ui.width();
    position.left += 30;
    position.top -= 1;

    var randomId = Math.random();
    $scope.data.onViewTreeFunction = randomId


    setTimeout(function on() {
        if ($scope.data.onViewTreeFunction != randomId) {
            return
        }
        var position = $(ui).offset();
        position.left += ui.width();
        position.left += 30;
        position.top -= 1;
        $('.listCurrentFunctionChildren').offset(position)
    }, 50)
    console.log('\t', 'to', position, $event.target)

    $('.listCurrentFunctionChildren').offset(position)
}


$scope.ui.onSelectTreeOPCO = function onSelectTreeOPCO(selectedComplex, $event) {
    console.log('onSelectTreeOPCO', 'opco')
    $('.listCurrentComplexChildren').hide()
    $('.listCurrentFunctionChildren').hide();

    $scope.ui.selectItem('currentComplex', null);
    $scope.ui.selectItem('currentFunction', null);
    //$scope.ui.selectItem('currentComplex', null);

    $scope.ui.createTabsForCTL(null, 'opco')
}

$scope.ui.onSelectTreeComplex = function onSelectTreeComplex(selectedComplex, $event) {
    console.log('onSelectTreeComplex', selectedComplex)
    $('.listCurrentComplexChildren').hide()
    $('.listCurrentFunctionChildren').hide();
    //...
    $scope.ui.selectItem('currentComplex', selectedComplex);

    $scope.ui.createTabsForCTL(selectedComplex, 'currentComplex')
}

$scope.ui.onSelectTreeFunction = function onSelectTreeFunction(selectedFunction, $event) {
    console.log('onSelectTreeFunction', selectedFunction)
    $('.listCurrentComplexChildren').hide()
    $('.listCurrentFunctionChildren').hide();
    $scope.ui.selectItem('currentFunction', selectedFunction);

    $scope.ui.createTabsForCTL(selectedFunction, 'currentFunction')
}

$scope.ui.onSelectTreeDesk = function onSelectTreeDesk(selectedDesk, $event) {
    console.log('onSelectTreeDesk', selectedDesk)
    $('.listCurrentComplexChildren').hide()
    $('.listCurrentFunctionChildren').hide();
    //...
    $scope.ui.selectItem('currentDesk', selectedDesk);

    $scope.ui.createTabsForCTL(selectedDesk, 'currentDesk')
}

$scope.ui.x42NavBarNav_DropDownLeave = function x42NavBarNav_DropDownLeave() {
    $('.listCurrentComplexChildren').hide()
    $('.listCurrentFunctionChildren').hide();
    console.log('error', '...')
}
//x42NavBarNav_DropDownEnter

var uiDropdown = $('#dialogNavBar_SubsiteMenuContent');
//debugger
uiDropdown.on('mouseleave', function onMouseOut(delayed) {
    if ($scope.destroyed == true) {
        uiDropdown.off('mouseleave', onMouseOut)
        return;
    }

    $('.listCurrentComplexChildren').hide()
    $('.listCurrentFunctionChildren').hide();
})


$scope.ui.createTabsForCTL =
    function onAdjustTabs(item, prop, includeDefault) {
        var tabs = {};

        function filterOnFieldAndValue(field, value) {
            var qWhereClauseStr = field + '=`$("' + value + '")' //, Function=`$("Trading")
            return qWhereClauseStr;
        }

        /* $scope.data.ctlFilterOptions = [];
         if ( fieldName != null && fieldName != '' ) {
         dropdownCTLOptions = $scope.data.dictFields[fieldName]
         if ( dropdownCTLOptions ) {
         $scope.data.ctlFilterOptions = dropdownCTLOptions
         $scope.data.ctlFilterOptions = $scope.data.ctlFilterOptions.concat();
         $scope.data.ctrlFilterOptionsType = fieldName;
         $scope.data.ctlFilterOptions_selection = $scope.data.ctlFilterOptions[0]
         }
         }
         console.log('what is this',fieldName, SubsiteName,
         arr, $scope.data.ctlFilterOptions)
         */
        var newTabs = []
        var pathName = [];

        if (prop == 'currentComplex') {
            var newTab = {}
            newTab.type = 'ctl'
            newTab.fields = ['Function', 'Desk', 'subDesk1']
            newTab.whereClause = filterOnFieldAndValue('Complex', item.name)
            newTab.name = item.name;
            newTabs.push(newTab)
            pathName.push(newTab.name)
        }

        if (prop == 'currentFunction') {
            var newTab = {}
            newTab.type = 'ctl'
            newTab.fields = ['Desk', 'subDesk1', 'subDesk2']
            newTab.whereClause = [
                filterOnFieldAndValue('Complex', $scope.data.currentComplex.name),
                filterOnFieldAndValue('Function', item.name)

            ].join(', ')
            newTab.name = item.name;
            newTabs.push(newTab)

            pathName.push($scope.data.currentComplex.name)
            pathName.push($scope.data.currentFunction.name)
        }

        if (prop == 'currentDesk') {
            var newTab = {}
            newTab.type = 'ctl'
            newTab.fields = ['subDesk1', 'subDesk2', 'subDesk3']
            //newTab.whereClause = 'Desk=`$("' + item.name + '")'
            newTab.whereClause = filterOnFieldAndValue('Desk', item.name)
            newTab.name = item.name;
            newTabs.push(newTab)

            pathName.push($scope.data.currentComplex.name)
            pathName.push($scope.data.currentFunction.name)
            pathName.push($scope.data.currentDesk.name)
        }

        if (prop == 'opco') {
            $scope.popups.setSiteName('');
            includeDefault = true
            newTab = $scope.utilsFx.getTabs()[0]
            // return;
        } else {
            $scope.popups.setSiteName(item.name);
            // $scope.popups.setSiteName(pathName.join('/'));
        }


        //$tabs.pusdf()
        tabs = $scope.utilsFx.getTabs();

        var addedDynamicTabs = false;
        var joinedTabs = [];
        $.each(tabs, function filterTabs(k, tab) {
            if (tab.type == 'ctl') {
                return;
            }
            //delete tab.$$hashKey
            //tab.index = k;
            if (tab.type == 'default') {
                tab.hidden = true;
                if (includeDefault == true) {
                    tab.hidden = false;
                }
            }

            if (tab.type == 'userTab') {
                if (addedDynamicTabs == false) {
                    addedDynamicTabs = true
                    joinedTabs = joinedTabs.concat(newTabs)
                }
            }

            joinedTabs.push(tab)

        });

        console.error('updating tabs', tabs)
        if (addedDynamicTabs == false) {
            joinedTabs = joinedTabs.concat(newTabs)
        }

        $scope.utilsFx.setUITabs(joinedTabs);


        setTimeout(function showNewTab() {
            //$scope.tBH.data.currentLayoutTab.src = 'forcereload'
            //$scope.tBH.destroyLayout()

            //force change where clause

            setTimeout(function onChangeLayout() {
                $scope.onSelectTab(newTab);
                $scope.onSelectTab(newTab);
            }, 500)

        }, 500)


    }


$scope.ui.generateTabLayout =
    function generateTabLayout(fieldName, btn, arr, SubsiteName) {

        btn.click(function onAdjustTabs() {
            var tabs = {};

            $scope.data.ctlFilterOptions = [];
            if (fieldName != null && fieldName != '') {
                dropdownCTLOptions = $scope.data.dictFields[fieldName]
                if (dropdownCTLOptions) {
                    $scope.data.ctlFilterOptions = dropdownCTLOptions
                    $scope.data.ctlFilterOptions = $scope.data.ctlFilterOptions.concat();
                    $scope.data.ctrlFilterOptionsType = fieldName;
                    $scope.data.ctlFilterOptions_selection = $scope.data.ctlFilterOptions[0]
                }
            }
            console.log('what is this', fieldName, SubsiteName,
                arr, $scope.data.ctlFilterOptions)

            var newTabs = []

            if (SubsiteName == 'Complex') {
                /* if ( tab.name == 'Function') {
                 }*/
                var newTab = {}
                newTab.type = 'ctl'
                newTab.fields = ['Function', 'Desk', 'subDesk1']
                newTab.filters = ['complex==SPG']
                newTab.name = dropdownCTLOptions[0]
                newTabs.push(newTab)
                /* newTab = $scope.utilsFx.cloneObj(newTab);
                 newTab.name ='Credit'
                 newTabs.push(newTab)
                 newTab = $scope.utilsFx.cloneObj(newTab);
                 newTab.name ='Munis'
                 newTabs.push(newTab)*/
            }

            if (SubsiteName == 'Function') {
                /* if ( tab.name == 'Function') {
                 }*/
                var newTab = {}
                newTab.type = 'ctl'
                newTab.fields = ['Desk', 'subDesk1', 'subDesk2']
                newTab.filters = ['complex==SPG']
                newTab.name = dropdownCTLOptions[0]
                newTabs.push(newTab)
                /* newTab = $scope.utilsFx.cloneObj(newTab);
                 newTab.name ='Credit'
                 newTabs.push(newTab)
                 newTab = $scope.utilsFx.cloneObj(newTab);
                 newTab.name ='Munis'
                 newTabs.push(newTab)*/
            }

            if (SubsiteName == 'Desk') {
                /* if ( tab.name == 'Function') {
                 }*/
                var newTab = {}
                newTab.type = 'ctl'
                newTab.fields = ['subDesk1', 'subDesk2', 'subDesk3']
                newTab.filters = ['complex==SPG']
                newTab.name = dropdownCTLOptions[0]
                newTabs.push(newTab)
                /* newTab = $scope.utilsFx.cloneObj(newTab);
                 newTab.name ='Credit'
                 newTabs.push(newTab)
                 newTab = $scope.utilsFx.cloneObj(newTab);
                 newTab.name ='Munis'
                 newTabs.push(newTab)*/
            }

            $scope.popups.setSiteName(SubsiteName);

            //$tabs.pusdf()
            tabs = $scope.utilsFx.getTabs();

            var addedDynamicTabs = false;
            var joinedTabs = [];
            $.each(tabs, function filterTabs(k, tab) {
                if (tab.type == 'ctl') {
                    return;
                }
                //delete tab.$$hashKey
                //tab.index = k;
                if (tab.type == 'default') {
                    tab.hidden = false;
                    if (arr.includes('noDefault')) {
                        tab.hidden = true;
                    }
                }

                if (tab.type == 'userTab') {
                    if (addedDynamicTabs == false) {
                        addedDynamicTabs = true
                        joinedTabs = joinedTabs.concat(newTabs)
                    }
                }

                joinedTabs.push(tab)

            });

            console.error('error', tabs)
            if (addedDynamicTabs == false) {
                joinedTabs = joinedTabs.concat(newTabs)
            }

            $scope.utilsFx.setUITabs(joinedTabs);
            $scope.data.dictFields

        })
    }
$scope.ui.createConfigBar = function createConfigBar() {


    return;


    var idCTLConfigBar = 'ctl_config_bar';
    var ui = $('#' + idCTLConfigBar)


    //if (ui.length == 0){
    ui.remove();
    var noDefault = 'noDefault'
    //}
    var x42NavBar = $('.x42-nav-header-body').find('.toolbar-table').find('.grouping-left')
    ui = uiUtils.tag('div')
    ui.attr('id', idCTLConfigBar)
    ui.addClass('group')
    x42NavBar.append(ui)


    var btn = uiUtils.tag('button')
    btn.text('Default')
    ui.append(btn)
    $scope.ui.generateTabLayout('', btn, [], '')


    var btn = uiUtils.tag('button')
    btn.text('OPCO')
    ui.append(btn)
    $scope.ui.generateTabLayout('Complex', btn, ['opco', 'complex'], 'OPCO')

    var btn = uiUtils.tag('button')
    btn.text('Complex')
    ui.append(btn)
    $scope.ui.generateTabLayout('Complex', btn, [noDefault, 'complex'], 'Complex')

    var btn = uiUtils.tag('button')
    btn.text('Function')
    ui.append(btn)
    $scope.ui.generateTabLayout('Function', btn, [noDefault, 'function'], 'Function')

    var btn = uiUtils.tag('button')
    btn.text('Desk')
    ui.append(btn)
    $scope.ui.generateTabLayout('Desk', btn, [noDefault, 'desk'], 'Desk')


    ui.append($('#dialogCTL'))
}

$scope.data.dictFields = {};


$scope.ui.getFields = function getFields(fieldName, fxDone) {
    var args = [
        "rpc",
        "",
        '[".pt.getFieldValues",["",".ccrt.pnl.GetPnLUnpivottedMQYComparisonView[2017.06.08;1b;1b;`fidInternal]","Desk"],"S*S"]'
    ]

    if (fieldName == null) {
        fieldName = "Desk"
    }

    var qCall = $scopeSubsites.pTBH.data.pivotTable.scope.vm.table
    var qParams = [
        ".pt.getFieldValues",
        ["", qCall, fieldName],
        "S*S"]

    $scopeSubsites.pTBH.data.pivotTable.scope.vm.pump.send(
        "rpc", function onField(errors, stuff) {
            console.log('err', fieldName,
                errors, stuff)
            //debugger;
            $scope.data.dictFields[fieldName] = errors;
            fxDone(stuff, fieldName)
        }, qParams)
}

setTimeout(function on() {
    $scope.ui.getFields("Desk", function ok() {
    })
    $scope.ui.getFields("Complex", function ok() {
    })
    $scope.ui.getFields("Function", function ok() {
    })
}, 1500)

$scope.ui.createConfigBar();

setTimeout(function testNewDialog() {
    window.showFilterDebugDialog()
}, 1500)