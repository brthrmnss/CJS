Example usages for components
