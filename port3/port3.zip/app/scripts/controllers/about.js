'use strict';

/**
 * @ngdoc function
 * @name 74App.controller:AboutCtrl
 * @description
 * # AboutCtrl
 * Controller of the 74App
 */
angular.module('74App')
  .controller('AboutCtrl', function ($scope) {
    $scope.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
