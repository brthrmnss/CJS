/**
 *
 * tourCtrl
 *
 */

angular
    .module('homer')
    .controller('tourCtrl', tourCtrl)

function tourCtrl($scope) {





}