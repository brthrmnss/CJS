cd /etc/openvpn/
nodejs DelayInputCommand.js "vpn command= sudo openvpn /etc/openvpn/US\ East.ovpn"


