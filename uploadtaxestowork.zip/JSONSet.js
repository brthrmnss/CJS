var sh = require('shelpers').shelpers;
var shelpers = require('shelpers');

function JSONSet() {
    var p = JSONSet.prototype;
    p = this;
    var self = this;

    self.settings = {};
    self.data = {}

    p.init = function init(config) {
        self.settings = sh.dv(config, {});
        config = self.settings;

        self.getFiles();
    }

    p.getFiles = function getFiles(config) {
        var filename = sh.getFileName(self.settings.fileInput);
        var filename2 = sh.getFileNameOnly(filename);

        var dirOutput  = __dirname + '/' + 'output/'
        var fileWork = dirOutput  + filename;

        self.proc(filename)
        self.proc(filename2)

        self.data.fileInput = self.settings.fileInput;
        self.data.fileWork = fileWork + '.work.json';
        self.data.fileOutput = fileWork  + '.output.json';
        self.data.fileOutput2 = fileWork  + '.output2.json';

        self.data.fileOutputTemplate = fileWork  //why:: add files later

        sh.throwErrorIfFileNotFound = function throwErrorIfFileNotFound(file, msg) {
            msg = sh.dv(msg, '')
            if ( sh.fileExists( file ) == false ) {
                throw new Error(msg +  '  file not found: ' + file)
            }
        }

        sh.throwErrorIfFileNotFound(self.data.fileInput, 'inputFileNotFound')

        self.data.work = sh.fs.readJSONFile(self.data.fileWork ,{info:{},list:[]}, true )
        //self.data.work.list = []; //why: force refresh
        if ( self.data.work.list.length == 0 ) {
            self.proc('list is emtpy, so grabbing from input file')
            self.data.work.list = sh.fs.readJSONFile(self.data.fileInput ,null, false )
        }
        if ( self.settings.inputIsOutput_doesNotFilter ) {
            //why: do not save file
            self.proc('processing output file as input')
            self.data.work.list = sh.fs.readJSONFile(self.data.fileOutput ,null, false )

        }
        // gfg.g
        //sh.fs.readJSONFile(self.data.fileOutput ,{list:[]}, true )

        self.index = 0;

        self.data.work.info.lastTouched = new Date();
        self.data.work.info[self.settings.fileIterator]=new Date();

        self.data.listFiltered = [];
        var IteratorClass = require(self.settings.fileIterator).IteratorClass;
        var inst = new IteratorClass();
        inst.runner = self;
        sh.callIfDefined(inst.init, self.settings)
        sh.async(self.data.work.list, function procEachItem(item, _fxDone) {

            function fxDone(){
                if ( self.settings.delayEachInvocation != true  ) {
                    _fxDone();
                } else {
                    setTimeout(function delayForStackSizeExceede() {
                        _fxDone();
                    })
                }

            }
            function fxIteratorDone(json) {
                self.index ++;
                /*if ( json == null ) {
                 self.proc('remove item')
                 return
                 }*/
                /*if ( item.filetered != true  )
                 {
                 self.filteredItems
                 }*/
                if( item.filtered == true ) {
                    fxDone();
                    return;
                }
                sh.callIfDefined(inst.fxAddItem, item);
                self.data.listFiltered.push(item);
                item.index = self.data.listFiltered.length;
                fxDone();
            }

            inst.fxCallback(item, fxIteratorDone, self.index, self)
        }, function allDone() {
            inst.runner = self;
            sh.callIfDefined(inst.fxDone)
            self.proc('what is length', self.data.listFiltered.length)

            // process.exit()

            self.finishedWriting()
        })
    }

    p.finishedWriting = function finishedWriting() {
        sh.each(self.data.listFiltered, function (k,v) {
            v.index = k;
        });
        if ( self.settings.inputIsOutput_doesNotFilter ) {
            //why: do not save file
            self.proc('not saving the output file again')
            sh.callIfDefined(self.settings.fxDone)
            //self.data.work.list = sh.fs.readJSONFile(self.data.fileOutput ,null, false )
            return;
        }
        if ( self.settings.storeOutputFileElsewhere ) {
            sh.fs.writeJSONFile(self.data.fileOutput2, self.data.listFiltered  )
            sh.callIfDefined(self.settings.fxDone)
            return;
        }
        //asdf.g
        self.proc('...', 'finished')
        self.data.work.info.count =  self.data.work.list.length;
        self.data.work.info.filterCount = self.data.listFiltered.length;
        sh.fs.writeJSONFile(self.data.fileWork, self.data.work )
        sh.fs.writeJSONFile(self.data.fileOutput, self.data.listFiltered  )

        sh.callIfDefined(self.settings.fxDone)
    }

    p.createAdditionalFile = function createAdditionalJSONFile(name, data) {
        var fileStore = self.data.fileOutputTemplate+'.'+name+''+'.json';
        //self.proc('...', 'finished')
        sh.fs.writeJSONFile(fileStore, data);
    }
    p.createAdditionalFlatFile = function createAdditionalFlatFile(name, data) {
        var fileStore = self.data.fileOutputTemplate+'.'+name+''+'.txt';
        //self.proc('...', 'finished')
        if ( sh.isArray(data)) {data = data.join("\n")};
        sh.writeFile(fileStore, data);
    }
    
    p.test = function test(config) {
    }


    function defineUtils() {
        var utils = {};
        p.utils = utils;
        utils.getFilePath = function getFilePath(file) {
            var file = self.settings.dir+'/'+ file;
            return file;
        }

        p.proc = function debugLogger() {
            if ( self.silent == true) {
                return;
            }
            sh.sLog(arguments);
        };
    }
    defineUtils()
}

exports.JSONSet = JSONSet;

if (module.parent == null) {
    var instance = new JSONSet();
    var config = {};
    config.fileInput = 'G:/Dropbox/projects/crypto/ritv/imdb_movie_scraper/IMDB_App_Output/tv_series_top_250_num_votes,desc_1994,2017.json.dl.json.filtered.json';
    config.fileIterator = 'G:/Dropbox/projects/crypto/ritv/distillerv3/utils/JSONSet/JSONSetTestIterator.js'
    instance.init(config)
    instance.test();
}



