var fs = require('fs'),
    xml2js = require('xml2js');
var sh = require('shelpers').shelpers;
/*

 var dir = 'C:/trash/epub/HBR\'s 10 Must Reads on Leadersh - Harvard Business Review'
 var fileToc = dir + '/' + 'toc.ncx'

 var parser = new xml2js.Parser();
 var data = fs.readFileSync(fileToc ) //, function(err, data) {
 parser.parseString(data, function (err, result) {
 // console.dir(result);
 var x = result.ncx.navMap[0].navPoint;
 var files = []
 sh.each(x, function onAddEachFile(k,v) {
 files.push(v.content[0].$.src)
 })
 console.dir(x);
 console.log(files)
 console.log('Done');
 sh.toJSONString(files, true)
 // sh.toJSONString(x, true)
 });


 */


/**
 * Created by user1 on 2/7/14.
 *
 *
 * 1 find content on piratebay
 * 2 download content via put.io to blasdf
 * 3 iterate over content, add rotten tomato information
 * 4 add new content to db
 *
 * insight:  seperate rotten as a later step
 * get content first
 */

/**
 *
 */
var sh = require('shelpers').shelpers;
var fs = require("fs");
var async = require('async');
var mkdirp = require("mkdirp");

/*
 Goal is to extract file
 to dir
 so 5thelement.zip
 to dirExtract+/5thElement/....

 */
function MergeEpub() {

    var p = MergeEpub.prototype;
    p = this;
    var self = this;

    self.data = {};

    self.init = function init(options) {

        self.settings = options;


    }

    self.go = function go(options) {


        self.fileOutput = self.settings.dir + '/'+ 'epub.html';
        if ( sh.fileExists(self.fileOutput)) {
            self.done()
            return;
        }
        self.fileOutput = self.settings.dir + '/'+'OEBPS/'+ 'epub.html';
        if ( sh.fileExists(self.fileOutput)) {
            self.done()
            return;
        }


        // var dir = 'C:/trash/epub/HBR\'s 10 Must Reads on Leadersh - Harvard Business Review'
        dir = self.settings.dir;
        var fileToc = dir + '/' + 'toc.ncx'
        if ( sh.fileExists(fileToc)==false) {
            self.settings.dir = self.settings.dir +'/' +'OEBPS/'
            dir = self.settings.dir;
            var fileToc = dir + '/' + 'toc.ncx'
        }
        var parser = new xml2js.Parser();
        var data = fs.readFileSync(fileToc ) //, function(err, data) {
        parser.parseString(data, function (err, result) {
            // console.dir(result);
            var x = result.ncx.navMap[0].navPoint;
            var files = []
            sh.each(x, function onAddEachFile(k,v) {
                var fileSrc = v.content[0].$.src;

                fileSrc = fileSrc.split('#')[0];

                if ( files.indexOf(fileSrc) != -1 ) {
                    return; //skip included
                }
                files.push(fileSrc)
            })
            console.dir(x);
            console.log(files)
            console.log('Done');
            sh.toJSONString(files, true)


            self.data.files = files;
            self.mergeFiles();
            // sh.toJSONString(x, true)
        });



    }



    self.mergeFiles = function mergeFiles(options) {
        var dir = self.settings.dir;

        var fileOutput = dir + '/'+ 'epub.html';


        var contents = '';
        sh.each(self.data.files, function onAddEachFile(k,v) {
            var  filePart = dir + '/'+ v
            contents += sh.readFile(filePart)
        })

        sh.writeFile(fileOutput, contents)
        // self.mergeFiles();
        self.done()
    }


    self.done = function done(options) {
        sh.callIfDefined(self.settings.fxDone, self.fileOutput)
    }


    function defineUtils() {
        p.utils = {}
    }
    defineUtils();
    /**
     * Receive log commands in special format
     */
    p.proc = function proc() {
        sh.sLog(arguments)
    }
}

if (module.parent == null) {

    var options = {}
    options.callback = function onDone(dirExtract, token){
        console.log('done', dirExtract)
    }
    options.dirExtract = 'dirExtractionTarget'
    options.fileToExtract = '/home/user/trash/downloads/Wiz Khalifa - No Sleep.mp3.zip'
    var go = new MergeEpub()
    var dir = 'C:/trash/epub/HBR\'s 10 Must Reads on Leadersh - Harvard Business Review'
    options.dir = dir;
    options.fxDone  = function done(){}
    go.init(options);
    go.go()
    return;

}


exports.MergeEpub = MergeEpub;