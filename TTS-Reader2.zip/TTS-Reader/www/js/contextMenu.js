$(document).ready(function() {

    if ($("#test").addEventListener) {
        $("#test").addEventListener('contextmenu', function(e) {
            alert("You've tried to open context menu"); //here you draw your own menu
            e.preventDefault();
        }, false);
    } else {

        //document.getElementById("test").attachEvent('oncontextmenu', function() {
        //$(".test").bind('contextmenu', function() {
        $('body').on('contextmenu',  function() {

            // alert("contextmenu"+event);
            document.getElementById("rmenu").className = "showContextMenu";
            document.getElementById("rmenu").style.top =  event.clientY//mouseY(event);
            document.getElementById("rmenu").style.left =  event.clientX //mouseX(event);


            window.contextMenuHelper.storeSelection();

            $('#rmenu').css('top', event.clientY);
            $('#rmenu').css('left', event.clientX - $('#rmenu').width() - 10);
            //debugger
            //window.event.returnValue = false;


        });
    }

    function ContextMenuHelper() {
        var self = this;
        var p = this;

        self.data = {};

        p.copy = function copy() {
            var txt = self.getCurrentSelectionText();
            txt = self.data.txt;
            var bookname =  window.sentenceHelper.data.rr.getBookName();
            console.log('selected text', txt, bookname)

            $.ajax({
                url: "/store_doc",
                data: {
                    text:txt,
                    dir:bookname,
                    notes:'',
                    currentIndex:window.sentenceHelper.data.currentSentences.currentIndex
                },
                type:'post',
                success: function(result){
                    console.log('saved bookmark');
                }
            });

        }

        p.getCurrentSelectionText =  function getSelectionText() {
            var text = "";
            if (window.getSelection) {
                text = window.getSelection().toString();
            } else if (document.selection && document.selection.type != "Control") {
                text = document.selection.createRange().text;
            }
            return text;
        }
        p.storeSelection =  function storeSelection() {
            //why: have to store selected text before context action of clickn
            // on faux context menu
            self.data.txt =  self.getCurrentSelectionText()
        }
    }

    window.contextMenuHelper = new ContextMenuHelper();

});

// this is from another SO post...  
$(document).bind("click", function(event) {
    document.getElementById("rmenu").className = "hideContextMenu";
});



function mouseX(evt) {
    if (evt.pageX) {
        return evt.pageX;
    } else if (evt.clientX) {
        return evt.clientX + (document.documentElement.scrollLeft ?
                document.documentElement.scrollLeft :
                document.body.scrollLeft);
    } else {
        return null;
    }
}

function mouseY(evt) {
    if (evt.pageY) {
        return evt.pageY;
    } else if (evt.clientY) {
        return evt.clientY + (document.documentElement.scrollTop ?
                document.documentElement.scrollTop :
                document.body.scrollTop);
    } else {
        return null;
    }
}