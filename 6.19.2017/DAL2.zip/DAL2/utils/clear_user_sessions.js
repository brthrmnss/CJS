/**
 * Utility Script clears all sessions in db
 */
var shelpers = require('shelpers');
var sh = shelpers.shelpers;
var rh = require('rhelpers');


var dirSessions = sh.getUserHome()+'/'+"sessions_login_api"


var cluster_settings  = require( '../' + 'cluster_config.json' );
if ( cluster_settings.sessions != null ) {
    dirSessions= cluster_settings.sessions.dirSessions;

}

var server_config = rh.loadRServerConfig(true);

function removeSessionDir(dirSessions) {
    sh.fs.rmrf(dirSessions);
    console.log('removing', dirSessions)
    sh.fs.mkdirp(dirSessions);
}

dirSessions = server_config.loginAPI.dir_sessions;
removeSessionDir(dirSessions);

dirSessions= server_config.global.dir_login_consumer_sessions;
removeSessionDir(dirSessions);

//CrednetialServerquickStart
var dirSessions = sh.getUserHome() + '/' + 'trash/vidserv/'+'login_api_sessions';
removeSessionDir(dirSessions);

var dirSessions = sh.getUserHome()+'/trash/vidserv/'+'test_login_consumer_api_sessions';
removeSessionDir(dirSessions);

var dirSessions = sh.getUserHome()+'/trash/sessions_test/';
removeSessionDir(dirSessions);