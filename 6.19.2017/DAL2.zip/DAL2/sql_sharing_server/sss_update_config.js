/**
 * Created by user1 on 1/27/2018.
 */

var sh = require('shelpers').shelpers;
var shelpers = require('shelpers');

function SSSUpdateConfig() {
    var p = SSSUpdateConfig.prototype;
    p = this;
    var self = this;

    self.settings = {};
    self.data = {}

    p.init = function init(config) {
        self.settings = sh.dv(config, {});
        config = self.settings;

        self.data.file = sh.fs.join(__dirname, '..', 'cluster_config2_overrides.json')
        self.method();
    }

    p.method = function method() {

        var contents = sh.readJSONFile(self.data.file, {}, true)
        contents.peers = sh.dv(contents.peers, {})
        contents.peers[sh.hostname()] = sh.getIp()
        console.log(contents.peers, 'peers')
        sh.writeJSONFile(self.data.file, contents )
    }

    p.test = function test(config) {
    }


    function defineUtils() {
        var utils = {};
        p.utils = utils;
        utils.getFilePath = function getFilePath(file) {
            var file = self.settings.dir+'/'+ file;
            return file;
        }

        p.proc = function debugLogger() {
            if ( self.silent == true) {
                return;
            }
            sh.sLog(arguments);
        };
    }
    defineUtils()
}

exports.SSSUpdateConfig = SSSUpdateConfig;

if (module.parent == null) {
    var instance = new SSSUpdateConfig();
    var config = {};
    instance.init(config)
    instance.test();
}


