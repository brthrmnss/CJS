/**
 * Created by user on 1/13/16.
 */

var shelpers = require('shelpers');
var EasyRemoteTester = shelpers.EasyRemoteTester;

var SSS_Cluster_RCLike = require('./sss_cluster_loader').SSS_Cluster_RCLike;

if (module.parent == null) {
    var service = new SSS_Cluster_RCLike();
    var config = {};
    //config.overrideName = 'a'
    config.updateTableDefsFile = true;
    service.init(config);

}