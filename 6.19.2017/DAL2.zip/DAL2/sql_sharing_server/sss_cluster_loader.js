/**
 * Created by user on 1/13/16.
 */
/**
 * Created by user on 1/3/16.
 */
/*
 TODO:
 Test that records are delete?
 //how to do delete, have a delte colunm to sync dleet eitems
 */
//require('stackup');
var rh = require('rhelpers');
var sh = require('shelpers').shelpers;
var shelpers = require('shelpers');
var express = require('express');
var SequelizeHelper = shelpers.SequelizeHelper;
var EasyRemoteTester = shelpers.EasyRemoteTester;

var SQLSharingServer = require('./sql_sharing_server').SQLSharingServer;

var CreateInitialDatabase = shelpers.CreateInitialDatabase;

function SSS_Cluster_RCLike() {
    var p = SSS_Cluster_RCLike.prototype;
    p = this;
    var self = this;

    self.settings = {};
    self.data = {}
    self.data.peers = [];

    p.init = function init(config) {
        self.settings = sh.dv(config, {});
        config = self.settings;

        //self.settings.file = sh.dv(self.settings.file, __dirname+'/'+'../'+'../'+ 'cluster_config.json')
        self.settings.file = sh.dv(self.settings.file, __dirname + '/' + '../' + 'cluster_config2.json')
        self.config = sh.readJSONFile(self.settings.file)

        self.data.dbConfig = {
            "ip": "127.0.0.1",
            "databasename": "yetidb",
            "user": "yetidbuser",
            "pass": "aSDDD545y^",
            "port": "3306"
        }

        if ( self.settings.updateTableDefsFile ) {
            self.updateClusterConfigIfNeeded();
            return;
        }

        self.settings.fileConfigOverride = sh.dv(self.settings.fileConfigOverride,
            __dirname + '/' + '../' + 'cluster_config2_overrides.json')
        self.data.configOverride = sh.readJSONFile(self.settings.fileConfigOverride, {}, true)

        if (self.data.configOverride.peers) {
            self.config.peers = self.data.configOverride.peers;
        }
        self.cluster_config = self.config;


        self.cluster_config.port = sh.dv(self.data.configOverride.port, 12001);
        self.settings.startingPort = sh.dv(self.cluster_config.port, 12001);


        self.setupOverides();
        self.createConfig()

        sh.catchErrors(function saveAll() {
            // asdfl.g
        })

        self.startLikeRC();
    }

    p.setupOverides = function setupOverides() {
        var configOverride = {};
        configOverride.mysql = {
            "ip": "127.0.0.1",
            "databasename": "yetidb",
            //"user" : "yetidbuser",
            //"pass" : "aSDDD545y^",
            "port": "3306"
        };
        configOverride.mysql.logging = true;
        rh.configOverride = configOverride;
    }

    p.updateAllServices = function updateAllServices() {
        sh.each(self.data.allPeers, function refreshPeers(k, v) {
            v.refreshPeers(self.data.peers)
        })
    }

    p.startLikeRC = function startLikeRC() {
        self.setupOverides()
        // self.createServerA();
        //  self.createServerB();


        self.createMyNode()
        // self.updateAllServices();
        return;
    }

    p.createMyNode = function createMyNode() {
        var ip = sh.getIp()
        var foundPeerName = null
        var foundIp = null

        var searchedPeers = []

        var peers = self.data.baseConfig.cluster_config.peers;
        sh.each(peers, function searchForMyInfo(k, peer) {
            searchedPeers.push(k)
            if (peer.ip.includes(ip)) {
                foundPeerName = k;
                foundIp = peer
            }
        })
        if ( global.clusterLoaderOverrideName ) {
            console.log(sh.n, 'cleared for override',
            'global.clusterLoaderOverrideName', global.clusterLoaderOverrideName)
            self.settings.overrideName = global.clusterLoaderOverrideName
        }
        if (self.settings.overrideName) {
            var foundPeerName = null
            var foundIp = null
            sh.each(peers, function searchForMyInfo(k, peer) {
                if (k == self.settings.overrideName) {
                    foundPeerName = k;
                    foundIp = peer
                }
                if (peer.peerName &&
                    peer.peerName == self.settings.overrideName) {
                    foundPeerName = peer.peerName;
                    foundIp = peer.ip
                }
            })
        }
        //
        sh.throwIfNull(foundPeerName, 'did nto find (my) peer', self.settings.overrideName, searchedPeers)
        sh.throwIfNull(foundIp, 'did not find ip could not start')

        if (foundIp.ip) {
            foundIp = foundIp.ip; //why neede
        }
        self.createTestNode(foundPeerName, foundIp)
    }

    p.createServerB = function createServerB() {
        var i = self.createTestNode('b', "127.0.0.1:12101")
    }

    p.createConfig = function createConfig() {
        //load confnig frome file
        //peer has gone down ... peer comes back
        //real loading
        //multipe tables

        //define tables to sync and time
        //create 'atomic' modes for create/update and elete
        var cluster_config = {
            peers: [
                /*  {a: "127.0.0.1:12001"},
                 {b: "127.0.0.1:12101"}*/
            ]
        };

        cluster_config = sh.clone(self.cluster_config)

        sh.each(cluster_config.peers, function asdf(k, peer) {
            if (peer.includes(':') == false) {
                cluster_config.peers[k] = peer + ':' + cluster_config.port;
            }
        });


        function convertPeerStringsToObjects() {
            /*if ( self.data.peers.length == 0 ) {
             config.ignore0Peers = true;
             }*/

            //self.data.peers.push(peerDef)
            //config.cluster_config.peers = self.data.peers.concat()
            var newPeers = {};
            var peers = [];

            sh.each(cluster_config.peers, function asdf(k, peerStr) {
                var o2 = sh.splitIpAndPort(peerStr)
                /* //output.ip = o2.ip;
                 output.peerIp = o2.ip;
                 output.port = o2.port;
                 return output
                 if ( peer.includes(':')==false) {
                 cluster_config.peers[k] = peer+':'+cluster_config.port;
                 }*/

                newPeer = {}
                newPeer[k] = peerStr;
                newPeer.ip = peerStr;
                newPeer.peerName = k
                //newPeers.push(newPeer)
                newPeers[k] = newPeer;
                peers.push(newPeer)
            });

            // newPeers.numOfPeers = peers.length;
            cluster_config.peers = newPeers;

        }

        convertPeerStringsToObjects()


        //cluster_config.tables = ['file', 'user']
        //cluster_config.tables = ['user']
        sh.each(cluster_config.tableDefs, function fixDef(k, tableDef) {
            tableDef.tableOptions = {
                freezeTableName: true,
            }
            tableDef.syncSettings = {
                syncTime: 30,
            }
          //  asdf.g
        })

        cluster_config.peerConfig = {};
        // cluster_config.peerConfig.peers = ['file', 'user']

        var config = {};

        self.data.cluster_config = cluster_config;
        self.data.topology = {};
        self.data.allPeers = [];
        self.data.config = {};
        config.cluster_config = self.data.cluster_config;
        config.port = self.settings.startingPort;
        config.peerName = 'a';
        config.tableName = 'aA';
        config.useHandleTablesV2 = true;
        config.useHandleTablesV2_offsetIpAddresses = true;
        //config.fxDone = self.t.testInstances

        config.noDefaultFields = true
        //config.dbConfigOverride = true
        config.dbLogging = false
        config.dbConfig = self.data.dbConfig;

        //config.dbLogging = true
        config.debugUpsert = true
        config.debugUpsert = false
        config.password = 'dirty'
        self.data.baseConfig = config;
    }
    p.createNode = function createNode(name) {
        var service = new SQLSharingServer();
        service.init(self.data.baseConfig);
        var a = service;
        self.data.allPeers.push(service)
        self.data.topology.a = a;
    }
    p.createTestNode = function createNode(name, ip, overrideCfg) {

        var config = sh.clone(self.data.baseConfig);
        config.ip = ip;
        sh.mergeObjects(overrideCfg, config)

        var o3 = sh.splitIpAndPort(ip)
        config.port = o3.port;

        //config.port = self.settings.startingPort + self.data.allPeers.length;
        config.peerName = name;
        config.tableName = name + 'A';

        var peerDef = {};
        peerDef[name] = config.ip;
        /*if ( self.data.peers.length == 0 ) {
         config.ignore0Peers = true;
         }*/

        //self.data.peers.push(peerDef)
        //config.cluster_config.peers = self.data.peers.concat()

        var service = new SQLSharingServer();

        var rh = require('rhelpers');
        config.fxOverrideDBConfig = function fxOverrideDBConfig(cfg) {
            if (name == 'b') {
                cfg.dbName = 'yetidb2'
                // asdf.g
                // asdf.g
            }
        }

        global.debugDBA = true

        //self.data.startFxs.push(function onk() {
        //  peers =
        //service.fxInitPeer = function fxInitPeer(peers) {
        // config.cluster_config.peers = config.cluster_config.peers.concat(peers)
        service.init(config)
        //}
        //    })
        /* if (clearPeers != true) {
         service.init(config);
         } else {
         service.fxInitPeer = function fxInitPeer(peers) {
         config.cluster_config.peers = config.cluster_config.peers.concat(peers)
         service.init(config)
         }
         }*/

        var a = service;
        self.data.allPeers.push(service)
        self.data.topology[name] = a;

        service.preConfig = config;
        return service;
    }
    p.updateClusterConfigIfNeeded = function updateClusterConfigIfNeeded(fxDoneUConfig) {
        //self.config = sh.readJSONFile(self.settings.file)
        var tableDefs = self.config.tableDefs;
        var listTableDefs = [];

        var foundTableNames = []


        sh.each(tableDefs, function convertToArr(k,tableDef) {
            tableDef.tableName = k;
            foundTableNames.push(k)
            listTableDefs.push(tableDef)
        })


        sh.each(self.config.tables, function convertToArr(k,tableName) {
            var tableDef = {};
            tableDef.tableName = tableName;
            if ( foundTableNames.includes(tableName)){
                return;
            }
            listTableDefs.push(tableDef)
            tableDefs[tableName]=tableDef
        })


        sh.async(listTableDefs, function fixDef(tableDef, fxDoneIt) {
            /*tableDef.tableOptions = {
                freezeTableName: true,
            }
            tableDef.syncSettings = {
                syncTime: 30,
            }*/

            /*if ( tableDef.fields ) {
                fxDoneIt()
                return;
            }*/


            var instance = new CreateInitialDatabase();
            var config = {};
            instance.init(config)

            instance.config.setDbName(self.data.dbConfig.databasename);
            instance.config.sP(self.data.dbConfig.pass);
            instance.config.setUser(self.data.dbConfig.user);

            console.log(tableDef.tableName)

            instance.table.db_showTableFieldsAsRestHelper(tableDef.tableName, function onK(data
            ) {
                tableDef.fields = data.fields;
                fxDoneIt()
            });

           //asdf.g
        }, function finshedAll() {

            console.log(self.config)
           sh.writeJSONFile(self.settings.file,  self.config )
            sh.cid(fxDoneUConfig)
        })




    }

    p.test = function test(config) {
    }

    function defineUtils() {
        var utils = {};
        p.utils = utils;
        utils.getFilePath = function getFilePath(file) {
            var file = self.settings.dir + '/' + file;
            return file;
        }

        utils.cPeer = function cPeer(peerName) {
            var peer = null;
            if (sh.isString(peerName) == false) {
                peer = peerName;
                return peer
            }
            var peer = self.data.topology[peerName];
            return peer;
            //self.utils.cPeer(peerNode)
        }

        p.proc = function debugLogger() {
            if (self.silent == true) {
                return;
            }
            sh.sLog(arguments);
        };
    }

    defineUtils()
}

exports.SSS_Cluster_RCLike = SSS_Cluster_RCLike;

if (module.parent == null) {
    var service = new SSS_Cluster_RCLike();
    var config = {};
    service.init(config);


}
exports.SSSD = SSS_Cluster_RCLike;



