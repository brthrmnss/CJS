/**
 * Created by smorris1 on 1/3/14.
 */
var sh = require('shelpers').shelpers;


//AutoHotKeyAutomator = require('./AutoHotKeyAutomator.js').AutoHotKeyAutomator
AutoHotKeyEvernote = require('./AutoHotKeyEvernote.js').AutoHotKeyEvernote


if (module.parent == null) {
    var y = new AutoHotKeyEvernote();
    y.init();


    y.setTitleMatchMode()
    y.ifXAlert('WinActive("WebStorm")',  'sdfsdfsf')

    y.msgBox('testing')
  //  y.showCommands()



    y.writeAHKFile();
    return;

    var url = 'p'

    y.goToWindow('Extensions', 'chrome://extensions/')

    y.goToUrl(p);
    y.wait(2)
    y.tab()
    y.enterText()
    y.tab()
    y.enterText();
    y.tab()
    y.enter();

    return;

}




