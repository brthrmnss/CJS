/**
 * Created by morriste on 9/20/2016.
 */

/*
open file 
run through many 'rule' files 
keep filtering list until finished 
most do not filter list 

get things, filter list, 
generate output files, add to global question files 
remove item if you want to ...
 */