/**
 * Created by user1 on 2/7/14.
 *
 *
 * 1 find content on piratebay
 * 2 download content via put.io to blasdf
 * 3 iterate over content, add rotten tomato information
 * 4 add new content to db
 *
 * insight:  seperate rotten as a later step
 * get content first
 */


var request = require('request');
var cheerio = require('cheerio');
var sh = require('shelpers').shelpers
var PromiseHelper = require('shelpers').PromiseHelper;
var OptionsHelper = require('shelpers').OptionsHelper
var fs = require("fs")
var async = require('async');
var request = require('request');
var request = request.defaults({jar: true})
var mkdirp = require("mkdirp")
var progress = require('request-progress');


/*
 wiht new promise helpers
 spromos

 search for content, query==>url
 */
function DistillerV2() {

    var p = DistillerV2.prototype;
    p = this
    var self = this;

    self.go = function go(options) {

        //load options
        var paramsHelper = new OptionsHelper();
        paramsHelper.loadOptions(options)
        var fxCallback = paramsHelper.addOption('callback', 'completion callback', true)
        var query = paramsHelper.addOption('query',
            'what torrent to look for', false)
        var test = paramsHelper.addOption('test',
            'go into test mode', false)
        var downloadFiles = paramsHelper.addOption('downloadFiles',
            'download files', false)

        //create work token
        var token = {}
        //token.options = options;
        token.putioUsername = paramsHelper.addOption('putioUsername',
            'go into test mode', false, 'trevmoreano')
        token.putioPassword = paramsHelper.addOption('putioPassword',
            'download files', false, '12121212')

        token.extractFiles = paramsHelper.addOption('extractFiles',
            'extractFiles', false, true)
        token.dirExtractFiles = paramsHelper.addOption('dirExtractFiles',
            'dirExtractFiles', true )

        self.token = token
        self.token.showFileList = true;
        self.token.showFileList = false;
        token.query=query
        //TODO fix this, it should not be called all over ...
        //only at the end of processing ...
        token.fxCallback=fxCallback;
        //token.bail = false; // = asdf;
        token.bail = false
        token.test = options.test
        //placeholders
        token.match = null


        token.settings = {}


        var urlTorrent = paramsHelper.addOption('urlTorrent',
            'urlTorrent of torrent to download', false)
        token.urlTorrent = urlTorrent;

        if ( token.urlTorrent == null && token.query == null ) {
            throw ['Need either a urlTorrent, or a query', options].join(' ') //'dddddd'
            return
        }

        var downloadFile = paramsHelper.addOption('downloadFile',
            'should file be downloaded?', false, false)
        if ( downloadFile ) {
            var downloadFileDir = paramsHelper.addOption('downloadFileDir',
                'where to store downloaded file', true, null)
        }
        token.settings.downloadFile = downloadFile;
        token.settings.downloadFileDir = downloadFileDir;

        token.rewriteExisting = paramsHelper.addOption('rewriteExisting',
            'rewrite file if it already exists', false, false )

        //self.token.addTorrentLinks=[]
        //self.token.addTorrentLinks.push('magnet:?xt=urn:btih:97414f92446a95d142c7e87621735cb645a6ff8e&dn=The+5th+Element%281997%29.720P.BRRip.H264.%5BResource+RG%5D&tr=udp%3A%2F%2Ftracker.openbittorrent.com%3A80&tr=udp%3A%2F%2Ftracker.publicbt.com%3A80&tr=udp%3A%2F%2Ftracker.istole.it%3A6969&tr=udp%3A%2F%2Fopen.demonii.com%3A1337')
        //create work chain

        var work = new PromiseHelper();
        work.wait = token.simulate==false;
        //work.
        work.startChain(token)
            .add(self.loginPutio)
            .log()
            .add(self.searchPutIO_YourFiles_forTorrent)
            .add(self.utils.clearTransfers)
            .add(self.searchPutIO_Transfers_forTorrent)
            //.add(self.act_clearAllTransfers)
            .add(self.logic.act_BailIfFileInLibrary)
            .log()
            //get files ....
            //make sure file is valid
            //.add(self.listUserFiles)
            // .add(self.getTransfersInfo)
            .add(self.getTransfersInfo)
            //... //...
            //... ... | ....
            .add(self.downloadTorrentToPutIO_addToTransfers)
            .add(self.logic.act_waitForTransferToComplete)
            //.add(self.downloadFile)
            .utils.wait3Secs()
            .add(self.logic.getDownloadName)
            .add(self.logic.downloadCompletedTransfer)
            .add(self.listTransfers)
            .add(self.putio.removeDownloadFileFromTransfers)
            .add(self.putio.removeDownloadFileFromMyFiles)
            .add(self.putio.verifyFileDeleted)
            .add(self.logic.extractFile)
            .add(self.exitChain)
            .end();
    }

    p.exitChain = function exitChain(token, cb) {
        cb()
        if ( token.fxCallback != null ) {
            self.proc('passed on ')
            token.fxCallback(token.pathDownload, token)
        }

    }

    p.logic= {}
    /**
     * if the token has a matching item on .... proceed to the next task
     * if not, return the file url on the callback
     * @param token
     * @param cb
     */
    p.logic.act_BailIfFileInLibrary = function act_BailIfFileInLibrary(token, cb) {
        if ( token.bail == false ) {
            cb();
            return;
        }
        if ( token.match == null ) {
            cb()
            return;
        }

        if ( token.match != null ) {
            self.proc('found a match for query')
            self.putio.getDownloadLink(token.match.id, token.fxCallback)
            //cb()
        }

    }

    /**
     * Iterate over the transfers
     * If there is as matching transfer ...that is complete ... let's return thatr file
     *
     * @param token
     * @param cb
     */
    p.logic.act_waitForTransferToComplete = function act_waitForTransferToComplete(token, cb) {
        var intervalObject = null;
        var matchingTransfer = null
        function  checkTransfers () {
            //check transfers
            var opts = {}
            opts.callback = function processTransfers(json) {
                //looking fot a complete transfer
                var completedTransfer = null
                self.proc('checking transfers', token.query)
                sh.each(json.transfers, function (itemIndex, transfer) {
                    var num = itemIndex + 1
                    num += '.'
                    var completed = transfer.status == 'COMPLETED'
                    if ( completed == false ) {
                        completed = transfer.status == 'SEEDING'
                    }
                    var sameFileWeAreDownloading = transfer.magneturi == token.urlTorrent
                    sameFileWeAreDownloading = sh.startsWith(token.urlTorrent, transfer.magneturi)
                    //more complete search
                    if (sameFileWeAreDownloading == false) { //bookmark: waiting for transfer to finish
                        var preamble = transfer.magneturi.split("=")[0]
                        /*
                         transfer.magneturi
                         magnet:?xt=urn:btih:7ee94e8203b37f4acf946a5d40a5b40dee7e077b&dn=Ray+Donovan+S01E02+REPACK+HDTV+x264-ASAP+%5Beztv%5D

                         token.urlTorrent
                         magnet:?xt=urn:btih:b9140f268f5246aa8e94d7471311f032f113fce8&dn=Brian%5C%27s+Song+Dvdrip+H264+Bookerdog.mp4&tr=udp%3A%2F%2Ftracker.openbittorrent.com%3A80&tr=udp%3A%2F%2Ftracker.publicbt.com%3A80&tr=udp%3A%2F%2Ftracker.istole.it%3A6969&tr=udp%3A%2F%2Fopen.demonii.com%3A1337
                         */
                        if ( sh.startsWith(token.urlTorrent,preamble) ) { //torrent link
                            sameFileWeAreDownloading = token.urlTorrent == transfer.magneturi
                        } else {
                            self.proc(tag.diagnostic, 'we do not have the same type of urls')
                        }

                    }
                    //console.log(transfer.name, token.urlTorrent, transfer.magneturi)
                    if ( completed && sameFileWeAreDownloading) {
                        completedTransfer = transfer;
                        self.proc('found completedTransfer');
                        return false;
                    }
                    if ( sameFileWeAreDownloading ) {
                        token.transfer = transfer
                    }
                    //bookmark: show all active downloads
                    // console.log(num,   transfer.name, completed)
                    if ( completed ) { return  }
                    console.log(num,   transfer.name, completed, transfer.percent_done, transfer.down_speed)
                })

                if ( completedTransfer != null ) {
                    self.proc('completed the transfer');
                    clearInterval(token.intervalID)
                    token.intervalID = null
                    token.finishedTransfer = completedTransfer;
                    cb()
                }
            }


            //opts.
            p.putio.listTransfers(opts)
            //  cb()

        }

        token.intervalID =  setInterval( checkTransfers, 5000 )

        checkTransfers();


    }


    /**
     * Get name/size of file to download by using HEAD request
     * @param token
     * @param cb
     */
    p.logic.getDownloadName = function getDownloadName(token, cb) {
        if ( token.test ) {
            self.proc('test so skipping')
            cb()
            return;
        }
        var finishedTransfer = token.finishedTransfer;
        var file_id = finishedTransfer.file_id

        var fxGetDownloadLink = function fxTransferComplete(url) {
            token.urlDownload = url;

            var headRequestOptions = {}
            headRequestOptions.url = url
            headRequestOptions.method = "HEAD"

            function fxGotFileInfoCallback(error, response, body) {
                if ( response == null ) {
                    console.error(error); throw 'd'
                    return;
                }
                var contentDownloadName =  self.utils.getFileNameFromHeaders(response.headers)
                token.contentDownloadName = contentDownloadName
                var contentLength =  self.utils.getContentLengthFromHeaders(response.headers)
                token.contentFileSize = contentLength

                //override name
                if ( token.downloadFileName == null ) {
                    token.pathDownload =  token.settings.downloadFileDir + '/' +contentDownloadName
                }
                cb()
            }

            request(headRequestOptions, fxGotFileInfoCallback)


        }
        self.putio.getDownloadLink(file_id,fxGetDownloadLink)



    }



    p.logic.downloadCompletedTransfer = function downloadCompletedTransfer(token, cb) {
        if ( token.test ) {
            self.proc('test so skipping')
            cb()
            return;
        }
        var finishedTransfer = token.finishedTransfer;
        var file_id = finishedTransfer.file_id
        var fxTransferComplete = function fxTransferComplete(url) {
            if ( token.settings.downloadFile != true  ) {
                token.fxCallback(url)
            } else {
                var http = require('http');
                var fs = require('fs');
                mkdirp.sync(token.settings.downloadFileDir)
                var fileDest =  token.pathDownload
                if ( fs.existsSync(fileDest)) {
                    if ( self.utils.compareFileSize(fileDest, token.contentFileSize) ) {
                        if ( token.rewriteExisting != true ) {
                            //bookmark: how do we skip existing files?
                            self.proc(token.query, 'This file, already exists', 'will not override', fileDest, 'rewriteExisting')
                            cb();
                            return;
                        }
                    }
                    self.proc('warning ... file exists', token.query, fileDest )
                }
                token.timer = new sh.newTimer()


                var downloadFx = function download (url, dest, cb) {
                    var fs = require('fs');
                    var request = require('request');
                    var progress = require('request-progress');

                    var lastCount = 0
                    var monitorReq = request(url);

                    // Note that the options argument is optional
                    progress(monitorReq, {
                        throttle: 2000,  // Throttle the progress event to 2000ms, defaults to 1000ms
                        delay: 1000      // Only start to emit after 1000ms delay, defaults to 0ms
                    })
                        .on('progress', function (state) {
                            //console.log('received size in bytes', state.received);
                            // The properties bellow can be null if response does not contain
                            // the content-length header
                            // console.log('total size in bytes', state.total);

                            //console.log('-', state.percent, '%');
                            try {
                                var diff = state.received-lastCount
                                var remainingBytes = state.total - state.received
                                var throttle = 2000
                                var remainingProgressEvents = remainingBytes/diff
                                var remainingTime = remainingProgressEvents* throttle / 1000
                                //console.log('rem', (remainingTime/60).toFixed())
                                lastCount = state.received
                            } catch ( e) {}
                            // self.proc('', token.timer.remaining(state.percent/100))
                            console.log('-Prog>>', state.percent, '%', '\t', token.timer.remaining(state.percent/100), (remainingTime/60 ).toFixed(),  token.contentDownloadName);
                        })
                        .on('error', function (err) {
                            // Do something with err
                        })
                        .pipe(fs.createWriteStream(dest))
                        .on('error', function (err) {
                            // Do something with err
                        })
                        .on('close', function (err) {
                            // Saved to doogle.png!
                            cb('saved ' + dest)
                            token.fxCallback(dest, token)
                        })
                }


                function fxDoneSavingFile(msg) {
                    cb(msg)
                }

                //downloadFx(url, fileDest, fxDoneSavingFile )

                var AxelDownloader = require('./AxelDownloader').AxelDownloader;

                var n = new AxelDownloader()
                var downloadSettings = {}
                downloadSettings.a = null;
                downloadSettings.n = 16;
                downloadSettings.username = token.putioUsername
                downloadSettings.password = token.putioPassword

                downloadSettings.url = url;//"https://s11.put.io/zipstream/2535971.zip?token=01606bb68b7011e3b864002481265109"

                downloadSettings.renameFileTo = fileDest;

                downloadSettings.fxCallback = function fxCallback(ok) {
                    self.proc('ok')
                    fxDoneSavingFile(ok)
                }
                n.get(downloadSettings)


            }

        }
        self.putio.getDownloadLink(file_id,fxTransferComplete)
        //cb()
    }


    p.logic.extractFile = function extractFile(token, cb) {
        if ( token.test ) {
            self.proc('test so skipping')
            cb()
            return;
        }
        if ( token.extractFiles == false  ) {
            self.proc(' token.extractFile',  token.extractFiles)
            cb()
            return;
        }
        if ( token.dirExtractFiles == null  ) {
            throw 'need extraction dir'
            return;
        }

        var FileExtractor = require('./FileExtractor').FileExtractor;

        var extractSettings = {}
        extractSettings.callback = function onDone(dirExtract, extractionToken){
            self.proc('done', dirExtract)
            token.dirExtract   = dirExtract
            //what is template?
            token.dirFullExtractionDir = dirExtract
            cb();
        }
        extractSettings.dirExtract = 'dirExtractionTarget'
        extractSettings.fileToExtract = '/home/user/trash/downloads/Wiz Khalifa - No Sleep.mp3.zip'

        extractSettings.dirExtract = token.dirExtractFiles;
        extractSettings.fileToExtract = token.pathDownload; // '/home/user/trash/downloads/Wiz Khalifa - No Sleep.mp3.zip'



        var go = new FileExtractor()
        go.go(extractSettings);

        return;
        var finishedTransfer = token.finishedTransfer;
        var file_id = finishedTransfer.file_id
        var fxTransferComplete = function fxTransferComplete(url) {
            if ( token.settings.downloadFile != true  ) {
                token.fxCallback(url)
            } else {
                var http = require('http');
                var fs = require('fs');
                mkdirp.sync(token.settings.downloadFileDir)
                var fileDest =  token.pathDownload
                if ( fs.existsSync(fileDest)) {
                    if ( self.utils.compareFileSize(fileDest, token.contentFileSize) ) {
                        if ( token.rewriteExisting != true ) {
                            //bookmark: how do we skip existing files?
                            self.proc(token.query, 'This file, already exists', 'will not override', fileDest, 'rewriteExisting')
                            cb();
                            return;
                        }
                    }
                    self.proc('warning ... file exists', token.query, fileDest )
                }
                token.timer = new sh.newTimer()


                var downloadFx = function download (url, dest, cb) {
                    var fs = require('fs');
                    var request = require('request');
                    var progress = require('request-progress');

                    var lastCount = 0
                    var monitorReq = request(url);

                    // Note that the options argument is optional
                    progress(monitorReq, {
                        throttle: 2000,  // Throttle the progress event to 2000ms, defaults to 1000ms
                        delay: 1000      // Only start to emit after 1000ms delay, defaults to 0ms
                    })
                        .on('progress', function (state) {
                            //console.log('received size in bytes', state.received);
                            // The properties bellow can be null if response does not contain
                            // the content-length header
                            // console.log('total size in bytes', state.total);

                            //console.log('-', state.percent, '%');
                            try {
                                var diff = state.received-lastCount
                                var remainingBytes = state.total - state.received
                                var throttle = 2000
                                var remainingProgressEvents = remainingBytes/diff
                                var remainingTime = remainingProgressEvents* throttle / 1000
                                //console.log('rem', (remainingTime/60).toFixed())
                                lastCount = state.received
                            } catch ( e) {}
                            // self.proc('', token.timer.remaining(state.percent/100))
                            console.log('-Prog>>', state.percent, '%', '\t', token.timer.remaining(state.percent/100), (remainingTime/60 ).toFixed(),  token.contentDownloadName);
                        })
                        .on('error', function (err) {
                            // Do something with err
                        })
                        .pipe(fs.createWriteStream(dest))
                        .on('error', function (err) {
                            // Do something with err
                        })
                        .on('close', function (err) {
                            // Saved to doogle.png!
                            cb('saved ' + dest)
                            token.fxCallback(dest, token)
                        })
                }


                function fxDoneSavingFile(msg) {
                    cb(msg)
                }

                //downloadFx(url, fileDest, fxDoneSavingFile )

                var AxelDownloader = require('./AxelDownloader').AxelDownloader;

                var n = new AxelDownloader()
                var downloadSettings = {}
                downloadSettings.a = null;
                downloadSettings.n = 16;
                downloadSettings.username = token.putioUsername
                downloadSettings.password = token.putioPassword

                downloadSettings.url = url;//"https://s11.put.io/zipstream/2535971.zip?token=01606bb68b7011e3b864002481265109"

                downloadSettings.renameFileTo = fileDest;

                downloadSettings.fxCallback = function fxCallback(ok) {
                    self.proc('ok')
                    fxDoneSavingFile(ok)
                }
                n.get(options)


            }

        }
        self.putio.getDownloadLink(file_id,fxTransferComplete)
        //cb()
    }



    //holder for putio singleton functiosns
    p.putio = {}
    p.putio.getDownloadLink = function getDownlink(file_ids, cb ) {
        //https://api.put.io/v2/files/zip?noredirect&file_ids=202737835

        var form = {}
        form.noredirect=''
        form.file_ids = file_ids
        var url = self.utils.makeUrl2('files/zip?noredirect')///'+query ) //https://api.put.io/login'
        url += '&file_ids='+file_ids
        var requestOptions = {}

        requestOptions.url = url
        // requestOptions.form = form;
        requestOptions.method = "POST"

        request(requestOptions, fxCallback)

        function fxCallback(error, response, body) {

            self.proc(url)
            // return
            // self.proc(body)
            //return
            var json = self.utils.parseJSON(body)
            //{ size: 2190137530,
            //    status: 'OK',
            //    url: 'https://s09.put.io/zipstream/2315741.zip?token=509a1dca03ad11e486cb001018321b64' }
            self.proc('url', json.url )
            self.proc('size', json.size/(1000*1000) )
            var match = null;
            if ( json.url == null ) { //check transfers
                throw 'issue with json.url ....'
            }

            if (cb) { cb(json.url)}
            //
        }
    }

    /**
     * Converts santizied torrent links into putio transfers
     * @param token
     * @param cb
     */
    p.putio.verifyFileDeleted = function verifyFileDeleted(token, cb) {
        if (token.test) {
            self.proc('test so skipping')
            cb()
            return;
        }

        //call that search transfers method ...

        cb();
    }
    /**
     * Converts sanitized torrent links into putio transfers
     * @param token
     * @param cb
     */
    p.putio.removeDownloadFileFromTransfers = function removeDownloadFileFromTransfers(token, cb) {
        if ( token.test ) {
            self.proc('test so skipping')
            cb()
            return;
        }
        if ( token.doNotRemoveFromMyFiles ) {
            self.proc('token.doNotRemoveFromTransfers')
            cb()
        }
        //todo: make this a util that takes the url snippect and the form ifnromaton ....
        //https://api.put.io/v2/transfers/cancel
        var url = self.utils.makeUrl('transfers/cancel')
        var form = {}
        //form.noredirect=''
        if (token.transfer != null) {
            form.tranfer_ids = token.transfer.id; //question: are there times when match is not valid?
        } else {
            form.tranfer_ids = token.finishedTransfer.id; //question: are there times when match is not valid?
            //    self.proc('transfer is null')
           // cb();//
           // return;
        }
        function fxCanceldTranfers() {

        }
        self.utils.makePutIORequest('transfers/cancel', form, null, cb)
    }



    /**
     * Converts santizied torrent links into putio transfers
     * @param token
     * @param cb
     */
    p.putio.removeDownloadFileFromMyFiles = function removeDownloadFileFromMyFiles(token, cb) {
        if ( token.test ) {
            self.proc('test so skipping')
            cb()
            return;
        }
        if ( token.doNotRemoveFromMyFiles ) {
            self.proc('token.doNotRemoveFromMyFiles')
            cb()
            return;
        }
        //todo: make this a util that takes the url snippect and the form ifnromaton ....
        //var url = self.utils.makeUrl('files/delete')
        var form = {}
        //form.noredirect=''
        if (token.transfer != null) {
            form.file_ids = token.transfer.file_id; //question: are there times when match is not valid?
        } else {
            form.file_ids = token.finishedTransfer.file_id; //question: are there times when match is not valid?
            //    self.proc('transfer is null')
            // cb();//
            // return;
        }
        //token.match.id //question: are there times when match is not valid?
        self.utils.makePutIORequest('files/delete', form, fxCanceledTransfer)

        function fxCanceledTransfer(body) {
            cb()
        }
    }




    p.loginPutio = function loginPutio(token, cb) {
        //self.proc('here')
        var url = 'https://api.put.io/login'
        var requestOptions = {}

        requestOptions.method = 'POST'
        requestOptions.url = url

        var form = {}
        form.name = token.putioUsername;//'trevmoreano'
        form.password = token.putioPassword; //'12121212'
        form.next = '/your-files?'
        requestOptions.form = form

        request(requestOptions, fxCallback)

        function fxCallback(error, response, body) {

            //self.proc('body', body)

            var msg = 'You should be redirected automatically to target URL'
            var success = sh.includes(body, msg )
            if ( success == false ) {
                self.proc('cananot log in')
                self.proc('body', body)
                throw 'no login'

            }
            var json = {}
            try {
                json = JSON.parse(body)
            } catch (e  ) {
                self.proc('cant make json')
            }

            cb()
        }


        //cb()
    }

    p.listUserFiles = function getFiles(token, cb) {
        var url = self.utils.makeUrl('your-files') //https://api.put.io/login'
        var requestOptions = {}

        requestOptions.url = url

        request(requestOptions, fxCallback)

        function fxCallback(error, response, body) {

            //self.proc('body', body)

            var content = sh.getArrayContentBetween(body, "var collection = ", "\n")

            if ( sh.endsWith(content, ';') ) {
                content = content.slice(0, -1)
            }
            var json = {}
            try {
                json = JSON.parse(content)
            } catch (e  ) {
                self.proc('cant make json')
            }

            if ( self.token.showFileList ) {
                self.proc('file list')
                sh.each(json, function (itemIndex, file) {
                    var num = itemIndex + 1
                    num += '.'
                    console.log(num,
                        file.name, null)

                })
            } else {
                self.proc('you have', json.length, 'files')
            }

            cb()
        }


        //cb()
    }


    /**
     * Search is broken
     * @param token
     * @param cb
     */
    p.searchPutIO_YourFiles_forTorrent = function searchPutIO_YourFiles_forTorrent(token, cb) {
        if ( token.query == null ) {
            cb() //only look for matches if query defined ....
            return;
        }

        var query = token.query.replace(new RegExp(' ', 'gi'), '+')
        var url = self.utils.makeUrl2('files/search/'+query+'/page/0') //https://api.put.io/login'

        var query = token.query
        var url = self.utils.makeUrl2('files/search/'+query ) //https://api.put.io/login'
        var requestOptions = {}

        requestOptions.url = url
        //requestOptions.method = "POST"

        request(requestOptions, fxCallback)

        function fxCallback(error, response, body) {

            self.proc(url)
            // return
            // self.proc(body)
            //return
            var json = self.utils.parseJSON(body)


            var match = null;

            self.proc('search results')
            //   if ( self.token.showFileList ) {
            sh.each(json.files, function (itemIndex, file) {
                var num = itemIndex + 1
                num += '.'
                console.log(num,
                    file.name, null)

                if ( file.content_type == 'application/x-directory') {
                    match = file;
                }

            })
            // } else {
            //     self.proc('you have', json.length, 'files')
            // }

            token.match = match;

            // if ( match != null )

            cb()
        }


        //cb()
    }


    /**
     * The your files search is broken ... try the transfers
     * store on match if found
     * @param token
     * @param cb
     */
    p.searchPutIO_Transfers_forTorrent = function searchPutIO_Transfers_forTorrent(token, cb) {
        if ( token.query == null ) {
            cb() //only look for matches if query defined ....
            return;
        }

        if ( token.match != null ) {
            self.proc('do not need to search for transfer .... file is complete')
            cb() //only look for matches if query defined ....
            return;
        }

        function foundMatchCallback(match) {
            if ( match != null ) {
                token.match= match
            }
            cb();
        }

        self.utils.checkTransfersForFile(token, foundMatchCallback);
    }


    p.putio.listTransfers = function listTransfers(opts) {
        var url = self.utils.makeUrl('v2/transfers/list')
        var requestOptions = {}
        requestOptions.url = url
        request(requestOptions, fxRequestComplete)
        function fxRequestComplete(error, response, body) {
            var json = self.utils.parseJSON(body, false, 'could not parse list transfers')
            sh.each(json.transfers, function (itemIndex, file) {
                var num = itemIndex + 1
                num += '.'
                file.magneturi
                file.percent_done
                var completed = file.status == 'COMPLETED'
                if ( completed ) {
                    return
                }
                // console.log(num,   file.name, completed, file.percent_done, file.down_speed)

            })
            opts.callback(json)
        }


    }

    /**
     * What does this do?
     * Check for valid torrent link
     * @param token
     * @param cb
     */
    p.getTransfersInfo = function getTransfersInfo(token, cb) {
        var url = self.utils.makeUrl('v2/transfers/info');

        var requestOptions = {}
        requestOptions.method = 'POST'
        requestOptions.url = url;

        var form = {}
        form.urls = self.token.urlTorrent
        requestOptions.form = form
        request(requestOptions, fxCallback_OnGetTransferInfo)

        function fxCallback_OnGetTransferInfo(error, response, body) {
            self.proc('body', body)

            var json = {}
            try {
                json = JSON.parse(body)
            } catch (e  ) {
                self.proc('cant make json')
            }

            if ( json.ret.length < 0 ) {
                throw 'could not convert torrent into real file ... so we cannot download it ....'
            } else {
                //bookmark: link sanitized
                var url = json.ret[0].url
                self.proc('can download torrent', json.ret[0].name, json.ret[0].type_name)
                self.token.addTorrentLinks = [url]; //make sure this matches
                self.token.torrentName = json.ret[0].name;
                self.proc(url, self.token.urlTorrent);
            }
            cb()
        }
    }


    /**
     * Converts santizied torrent links into putio transfers
     * @param token
     * @param cb
     */
    p.downloadTorrentToPutIO_addToTransfers = function addMulti(token, cb) {

        if ( token.test ) {
            self.proc('test so skipping')
            cb()
            return;
        }

        var url = self.utils.makeUrl('v2/transfers/add-multi')
        //url = 'https://api.put.io/v2/transfers/add-multi'
        var requestOptions = {}
        requestOptions.method = 'POST'
        requestOptions.url = url
        var form = {}

        var addTorrentLinks = self.token.addTorrentLinks
        //'magnet:?xt=urn:btih:97414f92446a95d142c7e87621735cb645a6ff8e&dn=The+5th+Element%281997%29.720P.BRRip.H264.%5BResource+RG%5D&tr=udp%3A%2F%2Ftracker.openbittorrent.com%3A80&tr=udp%3A%2F%2Ftracker.publicbt.com%3A80&tr=udp%3A%2F%2Ftracker.istole.it%3A6969&tr=udp%3A%2F%2Fopen.demonii.com%3A1337'

        var jsonTorrentRequest = []

        sh.each(addTorrentLinks, function (itemIndex, url) {
            var jsonUrl = {}
            jsonUrl = {}
            // "save_parent_id":"","extract":false,"email_when_complete":false}
            jsonUrl.url = url
            jsonUrl.save_parent_id = ""
            jsonUrl.extract = false
            jsonUrl.email_when_complete = false
            jsonTorrentRequest.push(jsonUrl)
        })

        form.urls = JSON.stringify(jsonTorrentRequest)
        requestOptions.form = form
        request(requestOptions, fxCallback)

        function fxCallback(error, response, body) {
            var json = {}
            try {
                json = JSON.parse(body)
            } catch (e  ) {
                self.proc('cant make json')
            }
            self.token.downloadUrls= json;
            cb()
        }
    }


    p.listTransfers = function listTransfers(token, cb) {
        var url = self.utils.makeUrl('v2/transfers/list')
        var requestOptions = {}

        requestOptions.url = url

        request(requestOptions, fxCallback)

        function fxCallback(error, response, body) {

            //self.utils.extractJSONFromHTMLPage(body, "var collection = ", "\n")
            var json = self.utils.parseJSON(body, false, 'could not parse list transfers')
            //  if ( self.token.showFileList ) {
            sh.each(json.transfers, function (itemIndex, file) {
                var num = itemIndex + 1
                num += '.'
                file.magneturi
                file.percent_done
                var completed = file.status == 'COMPLETED'
                console.log(num,   file.name, completed)

            })
            //  } else {

            cb()
        }


        //cb()
    }

    p.getFirstQueryResult = function getFirstQueryResult(token, cb) {

        self.proc('here')
        cb()
    }


    function createUtilityFunctions() {
        p.utils = {}
        /**
         * Receive log commands in special format
         */
        p.utils.makeUrl = function makeUrl(url_) {
            return 'https://api.put.io/'+url_
        }
        /**
         * Receive log commands in special format
         */
        p.utils.makeUrl2 = function makeUrl2(url_) {
            return 'https://api.put.io/v2/'+url_
        }

        p.utils.extractJSONFromHTMLPage =
            function extractJSONFromHTMLPage (body, starter, ender, throwError) {
                var content = sh.getArrayContentBetween(body, starter, ender)

                //check for terminating semicolon
                if ( sh.endsWith(content, ';') ) {
                    content = content.slice(0, -1)
                }
                var json = {}
                try {
                    json = JSON.parse(content)
                } catch (e  ) {
                    self.proc('cant parse json')
                    if ( throwError ) {
                        throw e;
                    }
                }
                return json
            }

        p.utils.parseJSON =
            function parseJSON (jsonStr, throwError, errorMessage) {
                var json = {}
                try {
                    json = JSON.parse(jsonStr)
                } catch (e  ) {

                    if (  throwError  ) {
                        console.error(errorMessage)
                        throw e;
                    } else {
                        self.proc('cant parse json', errorMessage)
                    }



                }
                return json
            }


        /**
         * Content-dispotion uses a filename= property
         * @param headers
         * @param callback
         */
        p.utils.getFileNameFromHeaders =
            function getFileNameFromHeaders(headers, callback) {
                //attachment; filename="The 5th Element(1997).720P.BRRip.H264.ResourceRG by Dusty.zip"
                var contentDownloadName = headers['content-disposition']
                if ( contentDownloadName != null ) {
                    contentDownloadName = contentDownloadName.split("filename=")[1]
                    contentDownloadName = sh.unquote(contentDownloadName)
                    //callback(contentDownloadName)
                }
                return contentDownloadName
            }


        /**
         * content-length uses a filename= property
         * @param headers
         * @param callback
         */
        p.utils.getContentLengthFromHeaders =
            function getFileNameFromHeaders(headers, callback) {
                //content-length = 257513065
                var contentLength = headers['content-length']
                if ( contentLength != null ) {
                }
                return contentLength
            }


        /**
         * IS file same size in bytes as the bytes?
         * @param filename
         * @returns {*}
         */
        p.utils.compareFileSize = function compareFileSize(filename, compareToFileSize) {
            var stats = fs.statSync(filename)
            var fileSizeInBytes = stats["size"]
            if ( compareToFileSize == fileSizeInBytes) {
                return true;
            }
            return false;
        }
    }

    createUtilityFunctions();


    function createDBPutio() {
        p.utils.checkTransfersForFile =  function  checkTransfersForFile (token, cb) {
            //check transfers
            var opts = {}
            opts.callback = function processTransfers(json) {
                //looking fot a complete transfer
                var completedTransfer = null
                self.proc('checking transfers', token.query)
                sh.each(json.transfers, function (itemIndex, transfer) {
                    var num = itemIndex + 1
                    num += '.'
                    var completed = transfer.status == 'COMPLETED'
                    var sameFileWeAreDownloading = transfer.magneturi == token.urlTorrent
                    sameFileWeAreDownloading = sh.startsWith(token.urlTorrent, transfer.magneturi)
                    //more complete search
                    if (sameFileWeAreDownloading == false) { //bookmark: waiting for transfer to finish
                        var preamble = transfer.magneturi.split("=")[0]
                        /*
                         transfer.magneturi
                         magnet:?xt=urn:btih:7ee94e8203b37f4acf946a5d40a5b40dee7e077b&dn=Ray+Donovan+S01E02+REPACK+HDTV+x264-ASAP+%5Beztv%5D

                         token.urlTorrent
                         magnet:?xt=urn:btih:b9140f268f5246aa8e94d7471311f032f113fce8&dn=Brian%5C%27s+Song+Dvdrip+H264+Bookerdog.mp4&tr=udp%3A%2F%2Ftracker.openbittorrent.com%3A80&tr=udp%3A%2F%2Ftracker.publicbt.com%3A80&tr=udp%3A%2F%2Ftracker.istole.it%3A6969&tr=udp%3A%2F%2Fopen.demonii.com%3A1337
                         */
                        if ( sh.startsWith(token.urlTorrent,preamble) ) { //torrent link
                            sameFileWeAreDownloading = token.urlTorrent == transfer.magneturi
                        } else {
                            self.proc(tag.diagnostic, 'we do not have the same type of urls')
                        }

                    }
                    if ( sameFileWeAreDownloading ) {
                        token.transfer = transfer
                    }
                    //console.log(transfer.name, token.urlTorrent, transfer.magneturi)
                    if ( completed && sameFileWeAreDownloading) {
                        completedTransfer = transfer;
                        self.proc('found completedTransfer');
                        return false;
                    }

                    //bookmark: show all active downloads
                    // console.log(num,   transfer.name, completed)
                    if ( completed ) { return  }
                    console.log(num,   transfer.name, completed, transfer.percent_done, transfer.down_speed)
                })

                if ( cb != null  ) {
                    cb(completedTransfer);
                }

                return;
                if ( completedTransfer != null ) {
                    self.proc('completed the transfer');
                    clearInterval(token.intervalID)
                    token.intervalID = null
                    token.finishedTransfer = completedTransfer;
                    cb()
                }
            }


            //opts.
            p.putio.listTransfers(opts)
            //  cb()
        }
        /**
         * If you do not clear the transfers you will pick up stale results
         * @param token
         * @param cb
         */
        p.utils.clearTransfers =  function  clearTransfers (token, cb) {
            //throw 'not implemted....'
            //https://api.put.io/v2/transfers/clean
            self.utils.makePutIORequest('transfers/clean', null,null, cb);
        }



        p.utils.makePutIORequest = function makePutIORequest(urlEnd, postDataForm, fxCallback, cb ) {
            //https://api.put.io/v2/files/zip?noredirect&file_ids=202737835
            var url = self.utils.makeUrl2(urlEnd)
            // 'files/zip?noredirect')///'+query ) //https://api.put.io/login'
            var requestOptions = {}
            requestOptions.url = url
            if (postDataForm) {
                requestOptions.form = postDataForm;
            }
            requestOptions.method = "POST"
            request(requestOptions, fxRequestCallback)
            function fxRequestCallback(error, response, body) {
                self.proc('complete', url)
                if ( response.statusCode == '400') {
                    self.proc('400 status for', url)
                }
                if ( fxCallback != null ) {
                    fxCallback(body, response)
                }
                if (cb) {
                    cb()
                }
            }
        }
    }

    createDBPutio()

    /**
     * Receive log commands in special format
     */
    p.proc = function proc() {
        sh.sLog(arguments)
    }
}

if (module.parent == null) {

    var options = {}
    options.callback = function onDone(url){
        console.log('done', url)
    }

    options.downloadFile = true;
    var urlTorrent = 'magnet:?xt=urn:btih:97414f92446a95d142c7e87621735cb645a6ff8e&dn=The+5th+Element%281997%29.720P.BRRip.H264.%5BResource+RG%5D&tr=udp%3A%2F%2Ftracker.openbittorrent.com%3A80&tr=udp%3A%2F%2Ftracker.publicbt.com%3A80&tr=udp%3A%2F%2Ftracker.istole.it%3A6969&tr=udp%3A%2F%2Fopen.demonii.com%3A1337'
    urlTorrent = 'magnet:?xt=urn:btih:fdc599a6f498b93752479925062726e27de99cb9&dn=The+Simple+Guide+to+a+Minimalist+Life+-+Leo+Babuata&tr=udp%3A%2F%2Ftracker.openbittorrent.com%3A80&tr=udp%3A%2F%2Ftracker.publicbt.com%3A80&tr=udp%3A%2F%2Ftracker.istole.it%3A6969&tr=udp%3A%2F%2Fopen.demonii.com%3A1337'
    urlTorrent = 'magnet:?xt=urn:btih:11e8b03aa31caa1272cd03d25dbf24df3dc44f55&dn=Mach3+by+Artsoft+%2B+Crack+-+CNC+CAD+CAM&tr=udp%3A%2F%2Ftracker.openbittorrent.com%3A80&tr=udp%3A%2F%2Ftracker.publicbt.com%3A80&tr=udp%3A%2F%2Ftracker.istole.it%3A6969&tr=udp%3A%2F%2Fopen.demonii.com%3A1337'
    options.urlTorrent = urlTorrent
    options.downloadFileDir = 'c:/trash/downloads'
    var go = new DistillerV2()
    go.go(options);
}

exports.DistillerV2 = DistillerV2;