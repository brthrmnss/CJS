

var sh = require('shelpers').shelpers;
var shelpers = require('shelpers');



sh.runWhenFileChanged(__dirname, 'ListExtractorScraper.js')

