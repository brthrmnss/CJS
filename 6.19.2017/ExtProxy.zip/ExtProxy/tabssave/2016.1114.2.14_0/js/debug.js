// chrome.tabs.onUpdated.addListener(function(tabId, changeInfo, tab){
//   console.log("changeInfo: " + JSON.stringify(changeInfo));
// //   if(changeInfo.status === "complete") console.log(JSON.stringify(tab));
// });

// chrome.tabs.onCreated.addListener(function(tab){
//   console.log("new tab: ");
//   console.log(tab);
// });
