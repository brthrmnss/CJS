var shelpers = require('shelpers')
var sh = shelpers.shelpers;
var ReloadWatcher = shelpers.ReloadWatcher;

var shelpers = require('shelpers')
var sh = shelpers.shelpers;
var ReloadWatcher = shelpers.ReloadWatcher;


function ChromeAutomator() {
    var p = ChromeAutomator.prototype;
    p = this;
    var self = this;

    self.settings = {};
    self.data = {}

    p.init = function init(config) {
        self.settings = sh.dv(config, {});
        config = self.settings;

        self.connect();
    }

    p.connect = function connect() {
        var instance = new ReloadWatcher();
        var config = {};
        instance.init(config)

        instance.watchFileOnSOcket2(/*'bookCcvert'*/)
        self.data.instance = instance;


        instance.sendMsg('window.eval',
            {
                name: self.data.chromeTabName,
                evalStr: 'console.debug("test")'
            })


        instance.sendMsg('window.eval',
            {
                name: self.data.chromeTabName,
                evalStr: 'console.debug("---",window.boomBoomId)'
            })


        instance.sendMsg('window.eval',
            {
                name: self.data.chromeTabName,
                evalStr: '$("input").css("background-color", "red");'
            })


        /*  instance.sendMsg('window.eval',
         {
         name: 'xcal',
         evalStr: '$("input").css("background-color", "blue");'
         })
         //

         instance.sendMsg('window.eval',
         {
         name: 'xcal',
         evalStr: 'window.location = "http://www.yahoo.com"'
         })*/

    }


    p.searchImage = function searchImage(imageQury, downloadImg) {

        instance = self.data.instance;

        self.utils.sendMsg('$("input").css("background-color", "red");')
        self.utils.sendMsg('$("input").css("background-color", "blue");')

        var query = self.settings.query + '&source=lnms&tbm=isch'
        urlQuery = 'https://www.google.com/search?q=' + query + ''
        urlQuery = encodeURI(urlQuery)
        self.utils.sendMsg(`
                if ( window.location.toString() != ` + sh.qq(urlQuery) + ` ) { 
                    console.log(window.location.toString() , ` + sh.qq(urlQuery) + ` );
                    window.location = ` + sh.qq(urlQuery) + `
                }
                `
        )

        function asdf(index) {

            index = sh.dv(index, 1)
            name = self.settings.bookName + '/'
                + self.settings.query + '/'
                + self.settings.query
            instance.sendMsg('window.eval',
                {
                    name: 'xcal',
                    evalStr: `
                console.log('{{{...')
                //debugger
                var src = $('#search').find('img').eq(${index}).attr('src')
                var cdata = {}
                cdata.data = src;
                cdata.name = '${name}${index}.jpg';
                //debugger
                //console.log('src', src)
                uiUtils.postUrl('http://127.0.0.1:6006/doUp3/', cdata, function on(k){ 
                    console.log('k', k)
                })
                
                var cdata2 = {};
                cdata2.name = '${name}'
                cdata2.key = '${self.settings.query}.pics.[${index}]'
                cdata2.val = {name:cdata.name,date:new Date()}
                 uiUtils.postUrl('http://127.0.0.1:6006/doUpJSON/', cdata2, function on(k){ 
                    console.log('k', k)
                })
                
                /*
                var cdata2 = {};
                cdata2.name = '${name}'
                cdata2.key = '${self.settings.query}.pics.[${index}]'
                cdata2.val = {name:cdata.name,date:new Date()}
                 uiUtils.postUrl('http://127.0.0.1:6006/doUpJSON/', cdata2, function on(k){ 
                    console.log('k', k)
                })*/
                
                var cdata2 = {};
                cdata2.name = '${name}'
                cdata2.key = '${self.settings.query}.url'
                cdata2.val = window.location.toString()
                 uiUtils.postUrl('http://127.0.0.1:6006/doUpJSON/', cdata2, function on(k){ 
                    console.log('k', k)
                })
                `
                })
            //
        }

        setTimeout(asdf, 2000)
        setTimeout(asdf, 2000, 2)
        setTimeout(asdf, 2000, 3)
    }

    p.test = function test(config) {
    }


    function defineUtils() {
        var utils = {};
        p.utils = utils;
        utils.sendMsg = function sendMsg(evalStr) {
            instance.sendMsg('window.eval', {
                name: self.data.chromeTabName,
                evalStr: evalStr
            })
        }

        p.proc = function debugLogger() {
            if (self.silent == true) {
                return;
            }
            sh.sLog(arguments);
        };
    }

    defineUtils()
}

exports.ChromeAutomator = ChromeAutomator;

if (module.parent == null) {


    var instance = new ChromeAutomator();
    var config = {};
    config.chromeTabName = 'xcal'
    config.bookName = 'bookb'
    config.query = 'castor'
    instance.init(config)
    instance.connect();
    instance.searchImage('caster oil', true)
    //instance.test();
}
