var shelpers = require('shelpers')
var sh = shelpers.shelpers;
var ReloadWatcher = shelpers.ReloadWatcher;

var shelpers = require('shelpers')
var sh = shelpers.shelpers;
var ReloadWatcher = shelpers.ReloadWatcher;


function ChromeAutomator() {
    var p = ChromeAutomator.prototype;
    p = this;
    var self = this;

    self.settings = {};
    self.data = {}

    p.init = function init(config) {
        self.settings = sh.dv(config, {});
        config = self.settings;

        self.connect();
    }

    p.connect = function connect() {
        var instance = new ReloadWatcher();
        var config = {};
        instance.init(config)

        instance.watchFileOnSOcket2(/*'bookCcvert'*/)
        self.data.instance = instance;


        /*  instance.sendMsg('window.eval',
         {
         name: 'xcal',
         evalStr: '$("input").css("background-color", "blue");'
         })
         //

         instance.sendMsg('window.eval',
         {
         name: 'xcal',
         evalStr: 'window.location = "http://www.yahoo.com"'
         })*/

    }


    p.doImageSearch = function doImageSearch(xquery) {
        var query = xquery + '&source=lnms&tbm=isch'
        urlQuery = 'https://www.google.com/search?q=' + query + ''
        self.goToUrl(urlQuery)
    }

    p.waitForImageLoad = function waitForImageLoad(urlQuery) {
        return;
        $('input[title=Search]').val()
        urlQuery = encodeURI(urlQuery)
        self.utils.sendMsg(`
                if ( window.location.toString() != ` + sh.qq(urlQuery) + ` ) { 
                    console.log(window.location.toString() , ` + sh.qq(urlQuery) + ` );
                    window.location = ` + sh.qq(urlQuery) + `
                }
                `, true
        )
    }


    p.downloadImage = function downloadImage(urlQuery, index) {
        index = sh.dv(index, 0)
        name = self.settings.query
        self.utils.sendMsg(`
                console.log('{{{...')
                //debugger
                var src = $('#search').find('img').eq(${index}).attr('src')
                var cdata = {}
                cdata.data = src;
                cdata.name = 'dta/${name}/${name}${index}.jpg';
                //debugger
                //console.log('src', src)
                uiUtils.postUrl('http://127.0.0.1:6006/doUp3/', cdata, function on(k){ 
                        console.log('k', k)
                        sendResponse()
                })
                `, true
        )
    }


    p.goToUrl = function goToUrl(urlQuery) {
        urlQuery = encodeURI(urlQuery)
        self.utils.sendMsg(`
                if ( window.location.toString() != ` + sh.qq(urlQuery) + ` ) { 
                    console.log(window.location.toString() , ` + sh.qq(urlQuery) + ` );
                    window.location = ` + sh.qq(urlQuery) + `
                } else {
                    sendResponse()
                }
                `, true
        )
    }


    p.testAsync = function testAsync() {

        instance = self.data.instance;
        /*
         instance.sendMsg('window.eval',
         {
         name: self.data.chromeTabName,
         evalStr: 'console.debug("test")'
         })


         instance.sendMsg('window.eval',
         {
         name: self.data.chromeTabName,
         evalStr: 'console.debug("---",window.boomBoomId)'
         })


         instance.sendMsg('window.eval',
         {
         name: self.data.chromeTabName,
         evalStr: '$("input").css("background-color", "red");'
         })

         */

        self.utils.sendMsg('console.debug("test")')

        self.utils.sendMsg('logEval("test")')

        var query = self.settings.query + '&source=lnms&tbm=isch'
        urlQuery = 'https://www.google.com/search?q=' + query + ''

        self.doImageSearch(self.settings.query)
        self.waitForImageLoad(self.settings.query);
        self.downloadImage();
        self.data.instance.t.wait(1)

        /*self.data.instance.t.add(function ensureX()  {
         //  (1)
         })*/
        // self.utils.sendMsg('$("input").css("background-color", "red");')
        // self.utils.sendMsg('$("input").css("background-color", "blue");')

        //self.goToUrl(urlQuery)
        return;

    }


    p.getListOfBooks = function getListOfBooks(list) {


        var fileJSON = "C:/Users/user1/trash/bookCvert/test.htmlsentences.json"
        var json = sh.readJSONFile(fileJSON)
        var list = []
        sh.each(json, function f(k, v) {
            if (v.nouns2 == null) return;
            sh.each(v.nouns2, function onnoun(kk, vv) {
                if ( list.includes(vv)) { return }
                list.push(vv)
            })
        })
        console.log('list', list)
       // sdf.g
        self.data.list = list;

        self.data.instance.createTest();


        self.data.count = 0
        sh.async(list, function asdf(val, fx) {

            console.log(sh.n)
            self.data.count++

            console.log(self.data.count + '.', 'value', val)


            self.data.instance.t.add(function startLoop() {
                console.log('start loop', val)

                var dirBase = 'G:/Dropbox/projects/delegation/Reader/TTS-Reader/rips/image'
                var existingFile = sh.fs.join(dirBase, 'dta', val, val + '0.jpg')
                var exists = sh.fs.exists(existingFile)
                if (exists) {
                    console.log(sh.t, 'skip ', val)
                    fx()
                    self.data.instance.t.cb();
                    return
                }
                self.settings.query = val;
                 self.testAsync()
                self.data.instance.t.add(function onEndedIteration() {
                    console.log('ended ', val)

                    console.log('')


                    //console.log('crash')
                    // return
                    fx();
                    self.data.instance.t.cb();
                })


                self.data.instance.t.cb();

            })


            // fx();


        }, function onDone() {

        })

        return;

        instance = self.data.instance;
        /*
         instance.sendMsg('window.eval',
         {
         name: self.data.chromeTabName,
         evalStr: 'console.debug("test")'
         })


         instance.sendMsg('window.eval',
         {
         name: self.data.chromeTabName,
         evalStr: 'console.debug("---",window.boomBoomId)'
         })


         instance.sendMsg('window.eval',
         {
         name: self.data.chromeTabName,
         evalStr: '$("input").css("background-color", "red");'
         })

         */

        self.utils.sendMsg('console.debug("test")')

        self.utils.sendMsg('logEval("test")')

        var query = self.settings.query + '&source=lnms&tbm=isch'
        urlQuery = 'https://www.google.com/search?q=' + query + ''

        self.doImageSearch(self.settings.query)

        self.data.instance.t.wait(1)

        /*self.data.instance.t.add(function ensureX()  {
         //  (1)
         })*/
        // self.utils.sendMsg('$("input").css("background-color", "red");')
        // self.utils.sendMsg('$("input").css("background-color", "blue");')

        //self.goToUrl(urlQuery)
        return;

    }


    p.test = function test(config) {
    }


    function defineUtils() {
        var utils = {};
        p.utils = utils;
        utils.sendMsg = function sendMsg(evalStr, noReturn) {
            var data =
                {
                    evalBrowserName: self.settings.chromeTabName,
                    evalStr: evalStr
                }
            if (noReturn) {
                data.noReturn = true;
            }
            self.data.instance.sendMsgQ('window.eval', data)
        }

        p.proc = function debugLogger() {
            if (self.silent == true) {
                return;
            }
            sh.sLog(arguments);
        };
    }

    defineUtils()
}

exports.ChromeAutomator = ChromeAutomator;

if (module.parent == null) {


    var instance = new ChromeAutomator();
    var config = {};
    config.chromeTabName = 'kate'
    config.bookName = 'bookb'
    config.query = 'castor'
    instance.init(config)
    instance.connect();
    //  instance.searchImage('caster oil', true)
    //instance.test();
    //instance.testAsync();

    function asdf() {
        var listOfNames = ['Caster oil', 'hillary clinton', 'bobba']
        //instance.testAsync();
        instance.getListOfBooks(listOfNames)
    }

    asdf()
}
