console.log('input is enabled')
var sys = require("sys");

var stdin = process.openStdin();

stdin.addListener("data", function (d) {
// note:  d is an object, and when converted to a string it will
// end with a linefeed.  so we (rather crudely) account for that
// with toString() and then substring()
//console.log("you entered: [" +   d.toString().substring(0, d.length-1) + "]");
    var input = d.toString().substring(0, d.length - 1)
    console.log('entered', input)
// self.write(d)
//   terminal.stdin.write(d)
});

var shelpers = require('shelpers');
var sh = require('shelpers').shelpers;


sh.storeLogOutput('asf.txt')

console.log('s....')
console.error('s....')
