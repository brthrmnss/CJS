var http = require('http'),
    sys = require('sys');

var server = http.createServer(function (request, response) {
    //  asdf.g
    request.addListener('end', function () {
        response.writeHead(200, {
            'Content-Type': 'text/plain'
        });
       // asdf.g
      //  response.write(sys.inspect(request));
        //response.end();
//

    });

    function something(a, b, c) {
        console.log('l',a, b, c)
    }

    console.log('....')
    request.addListener('aborted', something);
    request.addListener('connect', something);
    request.addListener('upgrade', something);
    request.addListener('continue', something);
    request.addListener('end', something);
    response.writeHead(200, {"Content-Type": "text/html"});
    response.write("<!DOCTYPE \"html\">");
    response.write("<html>");
    response.write("<head>");
    response.write("<title>Hello World Page</title>");
    response.write("</head>");
    response.write("<body>");
    response.write("Hello World!");
    response.write("</body>");
    response.write("</html>");
    response.end();

});
server.listen(8000);