# Changelog

## 0.6

* Fixed slow motion audio bug
* Fixed MP3 lagging bug
* Fixed waveform display

## 0.5.1

* Ability to stop recording after particular milliseconds

## 0.5

* Added live recording callback
* Fixed bugs
