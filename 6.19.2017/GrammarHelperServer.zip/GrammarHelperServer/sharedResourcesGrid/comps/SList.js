/**
 * Created by user1 on 10/2/2017.
 */

function SList() {
    var self = this;
    var p = this;
    self.data = {};

    self.settings = {};
    self.settings.pageSize = 5;

    p.init = function init(cfg) {
        cfg = sh.dv(cfg);
        self.settings = cfg;


        self.data.ui = new UIComp();
        var cfg2 = u.clone(cfg);
        cfg2.fileName = 'slist.html';
        cfg2.div = cfg.div;
        //cfg2.fxPostRender = self.render;
        cfg2.fxPostRender = self.postRender;
        self.data.ui.init(cfg2);
        //self.render();


        var i = new self.settings.comp;
        var cfg = {};
        cfg.fxPreloadTemplate = function fxPreloadTemplate(cfg2) {
            //console.error('plreaded inner template', cfg.preload)
            self.data.cfg2 = cfg2;
            self.render();
        }
        cfg.preload = true;
        i.init(cfg)

        //  debugger


    }

    p.render = function render(query) {
        sh.cid(self.settings.fxRender)
        self.data.ui.loadTemplateContent();
    };


    p.postRender = function postRender(data, body, cfg) {
        self.data.renderData = arguments
        //debugger
        self.data._ui = cfg.ui;

        var listContents = cfg.ui.find('#listContents')
        if (self.settings.listGridMode) {
            listContents.addClass('grid-layout-container')
            if (self.settings.listGridMode) {
              //listContents
            }
        }

        if (self.settings.showRemoveAll) {
            //uiUtils.show()
            uiUtils.ifShow(self.settings.list.length > 0 , cfg.ui.find('#btnRemoveAll'))
            //cfg.ui.find('#listContents').show()
        }

        $.each(self.settings.list, function on(k, v) {
            // var div = u.tag('div');
            var i = new self.settings.comp;
            var cfg = u.clone(self.data.cfg2)

            UIComp.copyCfg(self.data.cfg2, cfg)
            cfg.itemData = v;
            if ($.isString(k)) {
                v.name = k;
            }
            cfg.preload = null;
            //u.copyObjProps(self.data.cfg2, cfg);
            cfg.baseUI = listContents
            cfg.fxRenderPartial = function fxRenderPartial(ui, itemData, _self) {
                /* var ui = $(html);
                 debugger;
                 ui.find('#labelName').text(v)
                 listContents.append(ui)*/
                // debugger;
                if (self.settings.listGridMode) {
                    ui.css('padding', '5px')
                    ui.addClass('grid-layout-item')
                }
                sh.forwardArgsTo(self.settings.fxRenderPartial, arguments)
            }
            cfg.parentUI = listContents;
            cfg.parent = self;
            cfg.listPartial = self.settings.listPartial
            i.init(cfg)
            self.data.ui.data.subItems.push(i)
            self.data.ui.data.configs.push(cfg)
            //listContents.append(div)
        })
        self.data.ui.pushVal({type: 'rake', key: 'txtVal', id: '#txtTxtVals'})

        self.data.ui.addClickToDom(self.data.ui.data.ui, self)
    };

    p.addListItem = function addListItem(item) {
        if (self.settings.list.includes(item)) {
            return;
        }
        self.settings.list.push(item)
        self.rerender();
    }
    p.getListItems = function getListItems(item) {
        return self.settings.list;

    }

    p.removeListItem = function removeListItem(item) {
        if (self.settings.list.includes(item) == false) {
            return;
        }
        uiUtils.removeFromArray(self.settings.list, item)
        self.rerender();
    }
    p.onRemoveAllItems = function onRemoveAllItems(item) {

            self.settings.list = []
        self.rerender();
    }

    p.rerender = function rerender(item) {
        self.data._ui.find('#listContents').html('')
        uiUtils.forwardArgsTo(self.postRender, self.data.renderData)
    }

    p.fxRenderPartial = function fxRenderPartial(ui, data, comp) {
        console.log('fxRenderPartial', ui, data, comp)
    };

    p.fxClickPartial = function fxClickPartial(ui, itemData, comp, event) {
        console.log('fxClickPartial', comp.settings.itemData)
        sh.forwardArgsTo(self.settings.fxClickPartial, arguments)
    };


    p.utils = {};
    p.utils.resetSearchId = function resetSearchId() {
        self.data.searchActive = false;
        self.data.searchId = null;
    }

}

