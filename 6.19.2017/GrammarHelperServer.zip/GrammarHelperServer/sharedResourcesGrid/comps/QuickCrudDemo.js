/**
 * Created by user1 on 10/2/2017.
 */


function QuickCrudDemo() {
    var self = this;
    var p = this;
    self.data = {};

    self.settings = {};
    self.settings.pageSize = 5;

    p.init = function init(cfg) {
        cfg = sh.dv(cfg);
        self.settings = cfg;
        cfg.div = '#quickCrudDemo'
        cfg.divMakeIfNotFound = true;
        self.data.ui = new UIComp();
        var cfg2 = u.clone(cfg);
        cfg2.fileName = 'quickCrudDemo.html';
        //cfg2.fxPostRender = self.render;
        cfg2.fxPostRender = self.postRender;
        self.data.ui.init(cfg2);
        self.render();
    }

    p.render = function render(query) {
        sh.cid(self.settings.fxRender)
        self.data.ui.loadTemplateContent();
    };

    p.postRender = function postRender(data, body, cfg) {

        /*var opts = QuickForm.createQF()
         qf = opts.qf;
         var i = opts.quickCrud()*/

        var qf = new QuickCrudConfigHelper(cfg);
        qf.quickForm.addTextInput('name', 'Prompt Name')
        qf.quickForm.addLabelField('id', 'id');
        qf.quickForm.addTextInput('ty', 't y');
        qf.quickForm.showElementLabels(true);//('ty', 't y');
        //qf.quickForm.showLabels = true;
        qf.divPartial = '#divQCDemo_partial'


        qf.fxGetItems = function fxGetItems(item) {
            // debugger
            item.name += ' ddd' + item.id
        }
        qf.fxProcessItem = function fxProcessItem(item) {
            // debugger
            item.name += ' ' + item.id
            return item;
        }

        qf.addClickForQList('xdelete', function onDeleteItem(item) {
            console.log('on delete item', item)
        })

        qf.addClickForQList('xname', function onClickName(item) {
            console.log('on xname item', item)
            // i.data.qf.redrawForm(item);
        })

        //qf.quickList.url('http://127.0.0.1:10001/file/')
        qf.uiConfig.targetDiv(cfg.ui.find('#qCDemoContents'))
        /*qf.uiConfig.fxInit(function onxInit() {
         console.log('on built')
         debugger
         })*/
        qf.fxQCrudUIReady(function onxInit(ui) {
            console.log('on built')
            var id2 = qf.divPartial
            UIComp.clearAll(id2)

            return;
            var ui2 = ui.find('#newModeFlag')
            /*UIComp.bindPush(ui2, function getVal() {
             return Math.random()
             }, 200, id2);
             */
            var ui2 = ui.find('#newModeFlag2')
            var b = UIComp.bindPush({
                ui: ui2,
                fxGetVal: function getVal() {
                    return Math.random()
                },
                retryTime: 200,
                id:id2
            });
            //b.bindAction();


            var ui2 = ui.find('#newModeFlag3')
            var b = UIComp.bindPush({
                ui: ui2,
                fxGetVal: function getVal() {
                    return Math.random()
                },
                fxGetVal2:function asdf(sdf) {
                    return parseFloat(sdf).toFixed(2)
                },
                retryTime: 0,
                id:id2
            });
            b.bindAction();


            function createTestDiv() {

            }

            // debugger
        })

        // qf.addRestHelper('http://127.0.0.1:10001/file/')
        /*
         var formObject2 = {};
         qf.loadForm(formObject2)

         qf.addTextInput('name', 'Prompt Name');
         qf.defaultValue('Sean')
         qf.required();
         qf.addTextInput('desc', 'Description');
         qf.defaultValue('')

         qf.addRadioGroup('desc2', ['a','b', 'c']);
         qf.defaultValue('c')
         */

        var i = new QuickCrud();
        i.init(qf);

        self.data.qf = self.data.quickForm = i;
        i.data.ui.callWhenChangedUIDataChanged(function onUpdated(o) {
            console.debug('boo', i.data)
            //self.data.ui.setText('#dbgRake', o.data.formObject)
            //self.data.ui.setText('#dbgRake', self.data.qf.data.formObject)
            self.data.ui.setText('#formObject', sh.toJSONString(
                self.data.qf.data.formObject
            ))
            // debugger;
        })
        //self.data.ui.pushVal({type:'rake', key:'txtVal', id:'#dbgRake', storeOnData:'formObject'})


        return;
    };


    p.utils = {};
    p.utils.resetSearchId = function resetSearchId() {
        self.data.searchActive = false;
        self.data.searchId = null;
    }

}

