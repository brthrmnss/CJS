/**
 * Created by user1 on 10/2/2017.
 */

function Paginator() {
    var self = this;
    var p = this;
    self.data = {};


    self.data.btnMore;
    self.data.btnMore2;

    self.settings = {};
    self.settings.pageSize = 5;

    p.init = function init() {}

    p.search = function search(query, pageNumber) {
        self.data.offset = 0 ;
        query.limit = self.settings.pageSize;
        query.offset = self.data.offset;
        self.data.offset += self.settings.pageSize;
        self.data.noMoreResults = false
        if ( pageNumber) {
            self.data.offset 	= 	pageNumber * self.settings.pageSize;
            query.offset = self.data.offset;
        }
    };

    p.searchMore = function searchMore(query) {
        if ( self.data.searchActive) {
            return 'search active';
        }
        if ( self.data.noMoreResults === true) {
            console.warn('no more results')
            return 'no more results';
        }
        //query.pageSize = self.settings.pageSize;
        //	debugger;
        query.offset 		= 	self.data.offset;
        self.data.offset 	+= 	self.settings.pageSize;

        query.limit = self.settings.pageSize;

        var searchId = Math.random();
        self.data.searchActive = true;
        self.data.searchId = searchId;

        setTimeout(function searchTimedOut() {
            if ( self.data.searchId == searchId) {
                console.error('search timed out ... ')
                self.utils.resetSearchId()
            }
        },30*1000);

    };

    p.pagResults = function pagResults(results) {
        var lastPage = results.length < self.settings.pageSize;
        console.info('search', 'lastPage out page', lastPage, results.length ,self.settings.pageSize );
        uiUtils.ifHide(lastPage, self.data.btnMore)
        uiUtils.ifShow(lastPage, self.data.btnEndOfResults)
        if ( lastPage )
            self.data.noMoreResults = true;
        //if (xMode)
        //gUtils.ifHide(firstPage, self.data.btnPrevious)
        self.utils.resetSearchId()
    };

    p.addCount = function addCount(resultCount, fx) {

        self.data.resultCount = resultCount
        var pages = Math.floor(resultCount/self.settings.pageSize)
        //var paginatr = self.data.ui.find('#paginagorholder');

        //u.setText(self.data.ui.paginatorHolder, paren(pages))

        self.data.uiPag.empty()
        currentPage = Math.floor(
            (self.data.offset-self.settings.pageSize)
            /	self.settings.pageSize )
        for ( var i = currentPage; i < 4; i++) {
            var page = i;
            addPageFor(page)
        }


        var btn = u.tag('span')
        btn.text('...')
        self.data.uiPag.append(btn)

        addPageFor(pages)

        function addPageFor(page) {
            var btn = u.tag('button')
            btn.text(page+1)
            btn.click( function onPage() {
                console.log('jump to page', page)
                fx(null, false, page)
            })
            self.data.uiPag.append(btn)
        }

        // paginatr.text(pages)
    };

    p.utils = {};
    p.utils.resetSearchId = function resetSearchId() {
        self.data.searchActive = false;
        self.data.searchId = null;
    }

}