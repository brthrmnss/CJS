/**
 * Created by user1 on 3/5/2018.
 */
var sh = require('shelpers').shelpers;
var shelpers = require('shelpers');

/*
At - small
Aw - overall context
Submind
    id
    trigger
 */

function Symbol() {
    var p = Symbol.prototype;
    p = this;
    var self = this;

    p.init = function init(config) {
        self.settings = sh.dv(config, {});
        self.method();
    }

    p.method = function method(config) {
    }


    self.data.impotance = '4'
    self.data.name = 'd'

    p.test = function test(config) {
    }

    p.proc = function debugLogger() {
        if ( self.silent == true) {
            return;
        }
        sh.sLog(arguments);
    };
}

function Intention() {
    var p = Intention.prototype;
    p = this;
    var self = this;

    p.init = function init(config) {
        self.settings = sh.dv(config, {});
        self.method();
    }
    //can restructure the mind

    p.method = function method(config) {
    }

    p.attentionScanning = function method(config) {
    }

    p.attentionCaptured = function method(config) {
    }

    p.attentionAlternating = function method(config) {
        //two or more things ...
    }
    p.intentionallyDirected = function method() {
        //can't use will. ... need top bottom
    }

    p.test = function test(config) {
    }

    p.proc = function debugLogger() {
        if ( self.silent == true) {
            return;
        }
        sh.sLog(arguments);
    };
}

///Mindfulness ... sati - pay attentiont o write right thein in a more skillful way
//more fully consicous than normaml

//todo bicamal
//show the words and action ..
//what trigers this mind // .. // what is a word for transtion
function Attention() {
    //picture of reality ..into concept
    var p = Attention.prototype;
    p = this;
    var self = this;
    self.data = {}
    self.data.scope = [] //?

    //extrospective , //invtrospective

    //self
    //identify objects

    p.init = function init(config) {
        self.settings = sh.dv(config, {});
        self.method();
    }

    p.method = function method(config) {
    }

    p.attentionScanning = function method(config) {
    }

    p.attentionCaptured = function method(config) {
    }

    p.attentionAlternating = function method(config) {
            //two or more things ...
    }
    p.intentionallyDirected = function method() {
        //can't use will. ... need top bottom
    }

    p.test = function test(config) {
    }

    p.proc = function debugLogger() {
        if ( self.silent == true) {
            return;
        }
        sh.sLog(arguments);
    };
}
function Awareness() {
    //optimal interactino ... called mindfulness
    //miniiual conceptuail .. hollistic, relatnishos of object s...
    //more information about context of eperience
    //bakcground and context ...
    //where, what we are doing ...
    //what we are doing ... and why
    var p = Awareness.prototype;
    p = this;
    var self = this;
    self.data = {}
    self.data.scope = [] //?

    self.data.allObjets = []
    self.data.importantObjects
    //peripheral attenion alerat atnetion which quicky processes he information
        //prevents attention from being overwelmend
    //basic tasks do not require attention , not fast enough

    p.init = function init(config) {
        self.settings = sh.dv(config, {});
        self.method();
    }

    p.method = function method(config) {
    }

    p.overalltTateOfMind = function method(config) {
            //meta-congifitave introspective wanaress
    }

    p.attentionCaptured = function method(config) {
    }

    p.attentionAlternating = function method(config) {
        //two or more things ...
    }
    p.intentionallyDirected = function method() {
        //can't use will. ... need top bottom
    }

    p.test = function test(config) {
    }

    p.proc = function debugLogger() {
        if ( self.silent == true) {
            return;
        }
        sh.sLog(arguments);
    };
}
function MindMoment() {
    //single static chunk
    //therevada
    var p = MindMoment.prototype;
    p = this;
    var self = this;

    p.init = function init(config) {
        self.settings = sh.dv(config, {});
        self.method();
    }

    p.method = function method(config) {
    }

    p.test = function test(config) {
    }

    p.proc = function debugLogger() {
        if ( self.silent == true) {
            return;
        }
        sh.sLog(arguments);
    };
}

function SubMind() { //AKA unconsious process
    var p = SubMind.prototype;
    p = this;
    var self = this;

    p.init = function init(config) {
        self.settings = sh.dv(config, {});
        self.method();
    }

    p.method = function method(config) {
    }

    p.test = function test(config) {
    }

    p.proc = function debugLogger() {
        if ( self.silent == true) {
            return;
        }
        sh.sLog(arguments);
    };
}

exports.Mind = Mind;


function Mind() {
    var p = Mind.prototype;
    p = this;
    var self = this;

    p.init = function init(config) {
        self.settings = sh.dv(config, {});
        self.method();
    }

    p.method = function method(config) {
    }

    p.test = function test(config) {
    }

    p.proc = function debugLogger() {
        if ( self.silent == true) {
            return;
        }
        sh.sLog(arguments);
    };
}

exports.Mind = Mind;

if (module.parent == null) {
    var instance = new Mind();
    var config = {};
    instance.init(config)
    instance.test();
}
