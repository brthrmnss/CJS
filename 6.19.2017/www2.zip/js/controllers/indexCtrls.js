
angular.module('indexCtrls', ['connexionServices', 'angular-md5', 'ui.router', 'ngStorage', 'angular-uuid'])	
	
	.controller('indexController', function($scope, $window, $log, $document, $timeout, $location){
		
		
	});