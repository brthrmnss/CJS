require([], function(){
	//Vice will try out not using this guy
});