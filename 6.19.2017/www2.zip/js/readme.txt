https://local.helloworld3000.com:8043/apps/speak/test.html



run browserEvalServer.js


G:\Dropbox\projects\crypto\browser-eval\BrowserEvalServer.js
G:\Dropbox\projects\crypto\browser-eval\BasicReloadServer2.js
G:\Dropbox\projects\crypto\nodejs-ssl-example-master\serve.js


/Users/user2/Dropbox/projects/delegation/Reader/TTS-Reader/www/uploads/extracted/Shirtmaking_ Developing Skills  David Coffinhtmlz

