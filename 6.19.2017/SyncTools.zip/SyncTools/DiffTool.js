var sh = require('shelpers').shelpers;
var shelpers = require('shelpers');

sh.fs.goToDir = function goToDir(file) {
    sh.run('start "explorer" ' + file);
}

function DiffTool() {
    var p = DiffTool.prototype;
    p = this;
    var self = this;

    self.settings = {};
    self.data = {}

    p.init = function init(config) {
        self.settings = sh.dv(config, {});
        config = self.settings;


    }

    p.doDisff = function doDiff(a, b) {
        var zip = sh.requirePathSH('bin/diff/diff.exe')

        var dirBlank = sh.fs.join(__dirname, 'blank')
        var dir = sh.require('mp/testingFramework', true)
        var cmd = '';
        cmd = [zip, 'diff --brief -Nr', dir, dirBlank]
        cmd = cmd.join(' ')

        console.log('zip', cmd)

        var dirBase = sh.fs.goUpDir(dir);


        console.log('dirBase', dirBase)

        //  asdf.g

        console.log('into', sh.changeWorkingDirectory(dirBase))
        console.log('')

        sh.run2(cmd)
        /*if (self.settings.listDirsToZip) {
         self.zipDirs()
         }*/
    }

    p.doDiff = function doDiff(a, b, makePath) {
        var zip = sh.requirePathSH('bin/diff/diff.exe')

        var diff = 'C:/Program Files/Git/usr/bin'+'/diff.exe'
        diff = sh.qq(diff)
        var cmd = '';
        a = sh.fs.slash(a)
        b = sh.fs.slash(b)
        cmd = [diff, '--brief -Nr', a, b]
        flags = [];

        if ( sh.fs.isDir(a)) {
            flags.push('-Naur')
        } else {
            flags.push('-aur')
        }
        var outputFile = ' > ' + sh.fs.trash('diffTool/output.patch')
        cmd = [diff, flags, a, b, outputFile]
        cmd = cmd.join(' ')

        console.log('zip', cmd)

//        var dirBase = sh.fs.goUpDir(dir);
      //  console.log('dirBase', dirBase)

        //  asdf.g
      //  asdf.g

       // console.log('into', sh.changeWorkingDirectory(dirBase))
        console.log('')

        var out = sh.run(cmd, {failable:true})
        console.log(out.stdout2)

    }
    p.zipDirs = function zipDirs(dirs) {
        var zip = sh.requirePathSH('bin/zip.exe')
        if (dirs) {
            self.settings.listDirsToZip = dirs
        }

        //self.settings.dirZipOutput = sh.dv(self.settings.dirZipOutput)
        sh.dv2(self.settings, 'dirZipOutput', sh.fs.trash('DiffTool/outputZips/'))

        sh.log.file(self.settings.dirZipOutput, 'here is file')

        sh.fs.goToDir(self.settings.dirZipOutput, 'here is file');

        sh.each(self.settings.listDirsToZip, function zipDir(k, dir) {
            var options = {};
            options.callback = function onDone(dirExtract, token) {
                console.log('done', dirExtract)
            }


            var dirLeaf = leaf = sh.fs.leaf(dir)
            var fileOutput = [self.settings.dirZipOutput, leaf + '.zip'].join('/')

            var cmd = '';
            cmd = [zip, '-r9', fileOutput, dirLeaf]
            cmd = cmd.join(' ')

            console.log('zip', cmd)

            var dirBase = sh.fs.goUpDir(dir);


            console.log('dirBase', dirBase)

            //  asdf.g

            console.log('into', sh.changeWorkingDirectory(dirBase))
            console.log('')

            sh.run2(cmd)

            /*

             cmd = ['cd '+dirBase, cmd]

             sh.run2(cmd)

             console.log('finished')
             */
            return;
            options.dirExtract = 'home/user/trash/downloads/Wiz Khalifa - No Sleep.mp3.zip ex'
            options.fileToExtract = '/home/user/trash/downloads/Wiz Khalifa - No Sleep.mp3.zip'
            options.fileToExtract = sh.fs.trash() + '/downloads/Wiz Khalifa - No Sleep.mp3.zip'
            options.dirExtract = options.fileToExtract + 'ex/'
            var go = new FileExtractor()
            go.go(options);
        })
    }

    p.method = function method() {
    }

    p.test = function test(config) {

        self.data.dirTrash = sh.fs.trash('diffTool')
        sh.fs.mkdirp(self.data.dirTrash)
        sh.log.file(self.data.dirTrash)
        // self.automateSyncing();

        sh.fs.copy('testFiles', self.data.dirTrash)
        console.log('start.dir', self.data.dirTrash)

        self.doDiff(
            self.data.dirTrash + '/' + 'a.txt',
            self.data.dirTrash + '/' + 'b.txt'
        )
    }


    function defineUtils() {
        var utils = {};
        p.utils = utils;
        utils.getFilePath = function getFilePath(file) {
            var file = self.settings.dir + '/' + file;
            return file;
        }

        p.proc = function debugLogger() {
            if (self.silent == true) {
                return;
            }
            sh.sLog(arguments);
        };
    }

    defineUtils()
}

exports.DiffTool = DiffTool;

if (module.parent == null) {
    var instance = new DiffTool();
    var config = {};
    instance.init(config)
    instance.test()
    /*asdf.gd
     var dirs = []
     dirs.push('C:/Users/user1/Dropbox/projects/crypto/node_modules/shelpers')
     dirs.push('C:/Users/user1/Dropbox/projects/crypto/mp/SlickRun')
     dirs.push('C:/Users/user1/Dropbox/projects/crypto/mp/GrammarHelperServer')
     instance.zipDirs(dirs)

     var listFiles = []
     //instance.downloadFiles(listFile, true)
     var fileDownloaded = "C:/Users/user1/trash/DiffTool/outputZips/shelpers.zip"
     var dirIncomingFiles = sh.fs.trash('DiffTool/incoming/')
     var dirUnzipped = sh.fs.trash('DiffTool/unziped/')
     var outputFile = instance.moveFiles(fileDownloaded, dirIncomingFiles);
     //instance.unZip(outputFile, dirUnzipped)
     //startBeyondCompareDiff


     //isntance.diff(dir1, dir2)
     instance.test();*/
}



 