// global for react app compat mode
window.MERCURY_EXT_MODE = 'new-tab';
