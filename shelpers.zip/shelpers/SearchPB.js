/**
 * Created by user1 on 2/7/14.
 *
 *
 * 1 find content on piratebay
 * 2 download content via put.io to blasdf
 * 3 iterate over content, add rotten tomato information
 * 4 add new content to db
 *
 * insight:  seperate rotten as a later step
 * get content first
 */

/**
 *
 * pb get from name
 * pb get from names
 *
 * put io download file
 * mega upload upload file (delete afterwards)
 *
 * sync folder
 * connect to mega
 * download missing content
 * import to ritv-db
 *
 * idempotence , have db
 */

var request = require('request');
var cheerio = require('cheerio');
var sh = require('shelpers').shelpers
var PromiseHelper = require('shelpers').PromiseHelper;
var OptionsHelper = require('shelpers').OptionsHelper
var fs = require("fs")
var async = require('async');
var request = require('request');
var request = request.defaults({jar: true})

/*
 wiht new promise helpers
 spromos

 search for content, query==>url
 */
function SearchPB() {

    var p = SearchPB.prototype;
    p = this
    var self = this;

    self.go = function go(options) {

        var paramsHelper = new OptionsHelper();
        paramsHelper.loadOptions(options)
        var fxCallback = paramsHelper.addOption('callback', 'completion callback', true)
        var query = paramsHelper.addOption('query',
            'what torrent to look for', true)

        var token = {}
        self.token = token
        token.query=query
        token.fxCallback=fxCallback;
        token.bail = false
        //placeholders
        token.urlTorrent = null
        token.urlMagnet = null
        token.throwErrorWhenQueryNotFound = paramsHelper.addOption('throwErrorWhenQueryNotFound',
            'if no torrents are found for an item ... we will end the script', false, true)

        var work = new PromiseHelper();
        work.wait = token.simulate==false;
        work.startChain(token)
            .add(self.searchByName)
            .log()
            .add(self.getFirstQuery)
            .add(self.convertMagnetLinkToTorrent)
            .log()
            .add(self.logic.returnMagnetLink)
            .end();
    }

    function createLogic() {
        p.logic = {}
        /**
         * return urlMagnet
         * @param token
         * @param cb
         */
        p.logic.returnMagnetLink = function returnMagnetLink(token, cb) {
            self.proc(token.torrentName)
            cb()
            token.fxCallback(token.urlMagnet)

        }
    }
    createLogic();

    function createAPI() {
        //holder for putio singleton functiosns
        p.putio = {}
        p.putio.getDownloadLink = function getDownlink(file_ids, fx) {
            //https://api.put.io/v2/files/zip?noredirect&file_ids=202737835

            var form = {}
            form.noredirect = ''
            form.file_ids = file_ids
            var url = self.utils.makeUrl2('files/zip')///'+query ) //https://api.put.io/login'
            var requestOptions = {}

            requestOptions.url = url
            requestOptions.form = form;
            requestOptions.method = "POST"

            request(requestOptions, fxCallback)

            function fxCallback(error, response, body) {

                self.proc(url)
                // return
                // self.proc(body)
                //return
                var json = self.utils.parseJSON(body)
                //{ size: 2190137530,
                //    status: 'OK',
                //    url: 'https://s09.put.io/zipstream/2315741.zip?token=509a1dca03ad11e486cb001018321b64' }
                self.proc('url', json.url)
                self.proc('size', json.size / (1000 * 1000))
                var match = null;

                if (fx) {
                    fx(json.url)
                }
            }
        }
    }
    createAPI()



    function defineWork() {
        p.searchByName = function searchByName(token, cb) {
            var query = token.query
            self.proc('completing torrent search for', query)

            //convert query to aporopay formate
            if (sh.includes(query, ' ')) {
                query = query.split(' ').join('+')
            }

            var queryToTorrent = {}
            var url = "http://thepiratebay.se/search/" + query + "/0/7/0" //sort by popularity

            token.url = url
            cb()
        }

        p.getFirstQuery = function getFirstQueryResultInner(token, cb) {
            var url = token.url
            self.proc('getFirstQueryResultInner', 'completing torrent search for', url)
            var fxCallback = function onRecievePBResults(err, resp, body) {

//handle gzip encoding
                if(resp.headers['content-encoding'] == 'gzip'){
                    var zlib = require('zlib');
                    zlib.gunzip(body, function(err, dezipped) {
                        //callback(dezipped.toString());
                        resp.headers['content-encoding'] = null
                        fxCallback(err, resp, dezipped.toString())
                    });
                    return;
                } else {
                    // callback(body);
                }

                $ = cheerio.load(body);

                var torrentlinks = $("[class='detLink']")
                self.proc('length of links' , torrentlinks.length)
                if ( torrentlinks.length > 1 ) {
                    torrentlinks = torrentlinks.slice(0, 1)
                } else {
                    console.log(body.toString())
                }
                if (torrentlinks.length == 0) {
                    self.proc('found no results for',  token.query)
                    var msg =  ['found no results for', token.query].join(' ')
                    if ( token.throwErrorWhenQueryNotFound ) {
                        throw msg
                    } else {
                        console.error('message')
                        return;
                    }
                    sh.callIfDefined(cb, token)
                    return;
                }
                torrentlinks.each(function (link) {
                    var x = $(this)
                    link = x.attr('href')
                    console.log(link)
                    token.urlTorrent = link;
                    sh.callIfDefined(cb, token)
                    return false; //only loop 1x...
                })
            }


            var options = {}
            options.url = url
            options.encoding  =  null
            //options['accept-encoding']= 'gzip;q=0,deflate,sdch'
            //options['accept-encoding']= 'identity'
            request(options, fxCallback)
        }


        p.convertMagnetLinkToTorrent = function convertMagnetLinkToTorrent(token, callback) {
            var urlTorrent = token.urlTorrent
            self.proc('convertMagnetLinkToTorrentInner', urlTorrent)
            if (urlTorrent == null) {
                sh.callIfDefined(callback, token)
                return;
            }

            //append piratebay
            if (urlTorrent.indexOf('htt') != 0) {
                urlTorrent = 'http://thepiratebay.se' + urlTorrent
            }

            var onGetTorrentLink = function onGetTorrentLink(err, resp, body) {

                if(resp.headers['content-encoding'] == 'gzip'){
                    var zlib = require('zlib');
                    zlib.gunzip(body, function(err, dezipped) {
                        resp.headers['content-encoding'] = null
                        onGetTorrentLink(err, resp, dezipped.toString())
                    });
                    //loop back once more
                    return;
                }
                //console.log('......', link)
                //console.log(body)
                var $ = cheerio.load(body);
                var torrentlinks = $("[title='Get this torrent']")
                torrentlinks = torrentlinks.slice(0, 1)
                if (torrentlinks.length == 0) {
                    self.proc('convertMagnetLinkToTorrentInner', 'torrentlinks.length == 0')
                    sh.callIfDefined(callback, token)
                    return;
                }
                torrentlinks.each(function (link) {
                    var x = $(this)
                    self.proc('convertMagnetLinkToTorrentInner', x.attr('href'))
                    var link = x.attr('href')
                    token.urlMagnet = link
                    token.torrentName = $('title').text().replace(' (download torrent) - TPB', '')
                    sh.callIfDefined(callback, token)
                })
            }

            var options = {}
            options.url = urlTorrent
            options.encoding  =  null
            request(options, onGetTorrentLink)
        }
    }
    defineWork()

    function defineUtils() {
        p.utils = {}
    }

    defineUtils();
    /**
     * Receive log commands in special format
     */
    p.proc = function proc() {
        sh.sLog(arguments)
    }
}

if (module.parent == null) {
    var options = {}
    options.callback = function onDone(url){
        console.log('SearchPB complete:', url)
    }
    options.query = '5th Element'
    options.query = 'lynda advanced unity'
    var go = new SearchPB()
    go.go(options);
    return;

}


exports.SearchPB = SearchPB;