/**
 * Created by user on 1/5/15.
 */
/*
 program will run commands
 has autocomplete

 history
 fallback and fall through

 next step
 load/save model
 edit panel
 user object
 add jquery
 make save call
 add autocomplete

 get clipboard?

 bundle in webapp

 */


var shelpers = require('shelpers')
var sh = shelpers.shelpers
var ExpressServerHelper = shelpers.ExpressServerHelper
var TestHelper = shelpers.TestHelper;
var reqPost = TestHelper.reqPost;

function SlickRun() {

    var p = SlickRun.prototype;
    p = this;
    var self = this;


    p.start = function start() {

        self.linux = true
        self.win = false;
        self.mac = false;

    }

    p.startServer = function startServer() {
        //do you have simple?
        var config = {}
        config.port = 10001
        config.addJquery = true
        var server = ExpressServerHelper.new(config)
        server.get('/changeEnv', self.changeEnv);
        //http://127.0.0.1:10001/changeEnv

        self.settings = {}
        self.settings.port = 10001

        self.settings.url = 'http://127.0.0.1:'+ self.settings.port+'/'+'slickrun.html'
        //http://127.0.0.1:10001/slickrun.html

        config.fx = function postStartupFx() {
            self.postStartup()
        }

        server.use(ExpressServerHelper.express.static(__dirname+'/slickrun_html'));
        server.use(ExpressServerHelper.express.static(__dirname+'/slickrun_html'));

        self.loadModel();

        createModelFx()
        createActionsFx(server)
    }


    function createModelFx() {

        /**
         * History,
         * Targets
         * Filters
         * @type {{}}
         */
        self.model = {}

        /**
         * Load model from file
         */
        p.loadModel = function loadModel(){
            self.model = {}
            try {
                var model = sh.readFile()
                model = JSON.parse(model);
            } catch ( e ) {
                console.error('could not load config')
                self.model = {}
            }
        }

        p.saveModel = function loadModel(){
            sh.writeFile2()
        }
    }
    createModelFx()

    function createActionsFx(server) {
        self.runCommand = function runCommand(req, res) {
            self.proc('runCommand');
            res.end();
        }
        server.get('/run', self.runCommand);



        self.runCommand = function runCommand(req, res) {
            self.proc('runCommand');
            res.end();
        }
        server.get('/run', self.runCommand);


        self.openDir = function openDir(req, res) {
            self.proc('openDir');

            var cp = require('child_process')

            var dir = req.query.dir;
            cp.spawn('pcmanfm', [dir]);

            res.end();
        }
        server.get('/openDir', self.openDir);
    }


    p.postStartup = function postStartup() {
        self.testX();
        var open = require('open');

        setTimeout(function openUrl(){
            open(self.settings.url);

            var cp = require('child_process'),
                url_to_open = 'http://duckduckgo.com/';

            cp.spawn('firefox', [ '-new-window', self.settings.url,
                '-height', 200, '-width', 200, '-P', 'Chromeless',
                '-Xno-remote']);
        }, 1*1000)
//http://superuser.com/questions/55915/launching-firefox-into-chromeless-mode-from-command-prompt
    }

    p.testX = function testX() {
        //p.getContent  = function getContent (token, cb, returnReq) {
        var reqoptions = {}
        reqoptions.url = 'http://localhost:'+self.settings.port+'/changeEnv'
        reqoptions.form = {}
        //reqoptions.form.email = cfg.defaultUserEmail+Math.random()
        //reqoptions.form.password = cfg.defaultUserPassword
        reqoptions.method = 'GET'
        reqoptions.fx2 = function storeContents(body){
            console.log('test ok...')
            //cb();
        };
        reqoptions.name = 'test changeEnv'
        //reqoptions.bodyEqual = 'USER_CREATED'
        //if ( returnReq){
        //    return reqoptions
        // }
        console.log('testing...')
        reqPost(reqoptions)
    }

    self.changeEnv = function changeEnv(req, res) {
        self.proc('change');
        res.end();
    }

    p.init = function init() {
        self.startServer();
        self.start();
    }

    /**
     * Receive log commands in special format
     */
    p.proc = function proc() {
        sh.sLog(arguments)
    }

}




var s = new SlickRun()

s.init();
