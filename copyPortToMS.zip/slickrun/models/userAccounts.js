/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('user',
      {
    id: {
      type: DataTypes.INTEGER(10),
      allowNull: false,
      primaryKey: true,
      autoIncrement:  true,
    },
    email: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    username: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    password: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
    validUntil: {
      type: DataTypes.DATE,
      allowNull: true,
    },
    lastLogin: {
      type: DataTypes.DATE,
      allowNull: true,
    },
    /*updatedDate: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: 'CURRENT_TIMESTAMP'
    },*/
    resetPasswordToken: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
    salt: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
    isDeleted: {
      type: 'BIT(1)',
      allowNull: true,
      defaultValue: false
    },
    token: {
      type: DataTypes.TEXT,
      allowNull: false,
    }
  },
      { tableName: 'user'});
};
