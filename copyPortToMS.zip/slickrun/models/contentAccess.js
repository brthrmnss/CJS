/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
    return sequelize.define('contentAccess', {
            id: {
                type: DataTypes.INTEGER(10),
                autoIncrement: true,
                allowNull: false,
                primaryKey:true,
            },
            userId: {
                type: DataTypes.INTEGER(10),
                allowNull: false,
            },
            contentId: {
                type: DataTypes.INTEGER(10),
                allowNull: false,
            },
            clientIP: {
                type: DataTypes.STRING,
                allowNull: false,
            },
            firstRequest: {
                type: DataTypes.DATE,
                allowNull: false,
            },
            lastRequest: {
                type: DataTypes.DATE,
                allowNull: false,
                defaultValue: new Date(),// 'CURRENT_TIMESTAMP'
            },
            totalAccess: {
                type: DataTypes.INTEGER(11),
                allowNull: false,
                defaultValue: '1'
            },
            timeRangeAccess: {
                type: DataTypes.INTEGER(11),
                allowNull: false,
                defaultValue: '1'
            },
            isDeleted: {
                type: DataTypes.INTEGER(4),
                allowNull: false,
                defaultValue: '0'
            }
        },
        { freezeTableName: true}
    );
};
