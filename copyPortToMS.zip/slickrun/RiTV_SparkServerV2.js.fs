/**
 * Designed to test all ritv functions
 * @type {*}
 */

var shelpers = require('shelpers')
var sh = shelpers.shelpers
var ExpressServerHelper = shelpers.ExpressServerHelper
var RestHelperSQLTest = require('shelpers').RestHelperSQLTest;
var Sequelize = RestHelperSQLTest.Sequelize;
var TestServer = require('./sparkserver').TestServer;
var RouteCacheHelper = require('./RouteCacheHelper').RouteCacheHelper;
var SequelizeHelper = shelpers.SequelizeHelper;

var EasyRemoteTester = shelpers.EasyRemoteTester;

var PromiseHelperV3 = shelpers.PromiseHelperV3;
var async	= require('async');

var CredentialServerQuickStart = require('./../ritv/_credentialserver/CredentialServerQuickStart').CredentialServerQuickStart
LoginAPIConsumerService=CredentialServerQuickStart.LoginAPIConsumerService;


function RiTV_SparkServerV2() {
    var p = RiTV_SparkServerV2.prototype;
    p = this;
    var self = this;

    p.init = function init() {
        var  s = new TestServer();
        self.settings = {port: 10003, dir: 'requests/',
            wildcards:false,
            noProxy:true,
            // force:false,
            loginAPI:{
                port:10005,
                dirSessions:sh.getUserHome()+'/'+"sessions_login_api"
            },
            loginAPIConsumer:{
                baseUrl:null, //use local host,
                port:10006,
                portProducer:10005,
                dirSessions:sh.getUserHome()+'/' +"sessions_login_consumer_api"

            },
            contentProviderAPI:{
                defaultContentPath: 'ritv_requests/a.mkv',
                sendDefaultPath : true,
                port: 10015
            },

            fxDone:self.fxServerStarted}




        self.settings.fxServerInit = function fxServerInit(){

        }
        s.startServer(self.settings);


        self.server = s;
        self.helper = s.server.eSH;
        self.helper.addResourceDir(__dirname+'/'+'ritv_public_html')



        self.createSQL(step2);
        function step2() {
            self.defineLoginServer(s.server, step3);
        }


        function step3() {


            //self.defineRealContentAPI(s.server, self.settings);
            //self.defineConfigRestHelperAPI(s.server);

            self.defineBreadcrumbRestHelper(s.server);
            //self.defineFakeContentAPI(s.server);

            self.defineIMDBRestHelper(s.server);
            self.defineProxy(s.server);
        }
    }

    p.fxServerStarted = function fxServerStarted() {
        self.runTests();
    }

    /*
     p.startServer = function startServer() {
     var config = {}
     config.port = 10003
     config.addJquery = true;
     config.testJquery = true;

     config.addWildCards = true
     config.addWildCards_Dir = __dirname + '/' + 'ritv_requests'

     var server = ExpressServerHelper.new(config)

     server.get('/changeEnv', self.changeEnv);

     self.server = server;
     self.helper = self.server.eSH;

     self.helper.addResourceDir(__dirname+'/'+'ritv_public_html')

     self.settings = {}
     self.settings.port = 10003


     self.defineContent(server)

     config.fx = function postStartupFx() {
     self.postStartup()
     }


     }*/

    p.createSQL = function createSQL(cb) {
        var sequelize =  SequelizeHelper.createSQL({cb:finished});
        function finished(sequelize){
            self.sequelize = sequelize;
            //distribute sqls to all sub configs
            self.settings.loginAPI.sequelize = sequelize;
            self.settings.loginAPIConsumer.sequelize = sequelize;
            sh.callIfDefined(cb)
        }
    }

    p.defineProxy = function defineProxy(server) {
        var rH = new RouteCacheHelper();
        server.use('/proxy', function proxy(req, res, next){
            if ( rH.handle({
                id:'test images',
                strategy:'file',
                dir:'proxy_test_request',
                method:'get',
                maxSize:10,
            }, req, res) ) { return; };
            next();
        });
        self.server.setupProxy(server);
    }

    /**
     * Use CredentailsServer to QuickStart a Login Server
     * @param server
     */
    p.defineLoginServer = function defineLoginServer(server, cb) {
        ///mnt/hgfs/Dropbox/projects/crypto/ritv/_credentialserver/CredentialServerQuickStart.js
        var cQS = require('./../ritv/_credentialserver/CredentialServerQuickStart').CredentialServerQuickStart
        var cQS = new cQS();
        self.cQS = cQS;
        //cQS.startLoginAPIServer(self.settings.loginAPI);

        //alternate: run the whole test
        var cSettings = {}
        cSettings.fxDone = function loginServerRunning(){
            console.info('login server running')
            sh.callIfDefined(cb);
        }

        cSettings.loginAPI = self.settings.loginAPI;
        cSettings.loginAPIConsumer = self.settings.loginAPIConsumer;

        //merge server with main server
        cSettings.loginAPI.server = server;
        cSettings.loginAPI.port = self.settings.port;
        cSettings.loginAPIConsumer.portProducer = self.settings.port;

        cQS.testCredentialsServer(cSettings);

        //self.helper.globalMiddleware = self.cQS.credentialsServer.api.topMiddleware_BlockUsersWithoutSessions;
        //self.helper.globalMiddleware = CredentialServerQuickStart.LoginAPIService.topMiddleware_BlockUsersWithoutSessions;


        self.cQS = cQS;

    }

    /**
     * Create content API, and lock it down with login credential server
     * @param server
     */
    p.defineRealContentAPI = function defineRealContentAPI(server, settings) {

        var cPSettings = settings.contentProviderAPI;
        cPSettings.portProducer = settings.loginAPI.port;

        var cGS = new CredentialServerQuickStart();

        //create a new server for contentProviderAPI
        if ( cPSettings.doNotCreateServer != false ) {
            var c = new LoginAPIConsumerService();
            c.startExampleLoginAPIConsumerService(cPSettings);
            server = c.server;
        }

        self.content = RestHelperSQLTest.createHelper('contents', server, {
            name:'contents',
            //routePrePend:'sim/',
            fields:{name: "", src:"", desc: "", user_id: 0, content_id: 0,
                episode:0, season:0, show_name:"",  year:0, imdb_id:""
            },
            fxStart:testContentProviderAPIInterface,
            reset:'onlyIfNeeded',
            genData:RestHelperSQLTest.RestHelper.types.GenDataIfEmpty,
            fxReset :self.utils.generateFakeContentForContentAPI
        });

        //http://192.168.81.133:10003/find_content?limit=3&src=game%201x1
        self.find_content = function find_content(req, res) {
            self.proc('getContent', req.query)
            var q = req.query;

            self.content.utils.genRestOkStub(req, res);


            var query_ = {where:req.query}
            query_.limit = 10;
            req.query = query_;
            self.content.searchItems(req, res)
            // res.end();
        }

        server.get('/api/find_content', self.find_content);

        var contentProvider = require('./content-provider');

        //server.get('/content/:filePath', contentProvider.sendContent);
        /*server.get('/api/get_content/:filePath', function fakeFileRequestMiddleware(req, res) {
         //req.contentPath = 'ritv_requests/b.mkv';
         if ( cPSettings.sendDefaultPath == true ) {
         req.contentPath = cPSettings.defaultContentPath;
         }
         contentProvider.sendContent(req, res)
         });*/
        server.get('/api/get_content', function fakeFileRequestMiddleware(req, res) {
            req.contentPath = req.query.file;
            if ( cPSettings.sendDefaultPath == true ) {
                req.contentPath = cPSettings.defaultContentPath;
            }
            contentProvider.sendContent(req, res)
        });

        function testContentProviderAPIInterface() {

            //do search
            //make request for fake content;

            //login

            //do search
            //make fake request

            var t = EasyRemoteTester.create('test Real Content Provider API', cPSettings);


            var urls = {}
            urls.search = t.utils.createTestingUrl('api/find_content')
            urls.getContent = t.utils.createTestingUrl('api/get_content')
            urls.verifyConsumer = t.utils.createTestingUrl('api/verify');
            t.settings.portOverride = self.settings.loginAPI.port;
            urls.login = t.utils.createTestingUrl('api/login');
            t.settings.portOverride = null;



            t.add(function doSearchWithNoLogin() {
                    t.quickRequest( urls.search,
                        'get', result, {name: "randomTask"})
                    function result(body) {
                        t.assert(body.success==false, 'no ok');
                        t.cb();
                    }
                }
            );


            cGS.testUtils.loginFail(t, urls.login, 'mark', 'randomTask')

            cGS.testUtils.login(t, urls.login, 'mark', 'randomTask2')

            cGS.testUtils.verifyKey(t, urls.verifyConsumer, t.key)

            t.add(function doSearchAfterLogin() {
                    t.quickRequest( urls.search,
                        'get', result, {name: "randomTask"})
                    function result(body) {
                        t.assert(body.length>=0, 'post-verify did not let me do a search');
                        t.cb();
                    }
                }
            );

            t.add(function doSearchWithIMDBId() {
                    t.quickRequest( urls.search,
                        'get', result, {imdb_id: "tt101"})
                    function result(body) {
                        t.assert(body.length>0, 'post-verify did not let me do a search');
                        t.cb();
                    }
                }
            );
            t.add(function doSearchWithLikeInName() {
                    t.quickRequest( urls.search,
                        'get', result, {name: {like:"%Emp%"}});
                    function result(body) {
                        console.log('body', body)
                        t.content = body[0]
                        if ( body.success==false){
                            throw 'not logged in anymore'
                        }
                        t.assert(body.length>0, 'post-verify did not let me do a search');
                        t.cb();
                    }
                }
            );


            t.add(function reqMovie() {
                    t.quickRequest( urls.getContent,
                        'get', result, {file: t.content.src, test:true});
                    /*t.quickRequest( urls.getContent+'/'+t.content.src,
                     'get', result );*/
                    function result(body) {
                        console.log('body', body)
                        t.assert(body=='test ok', 'could not get that content');
                        t.cb();
                    }
                }
            );


            /* console.log = function () {
             //return;
             }*/
            var res = {}
            res.ok = function ok(o) {
                console.log('response was', o )
            }

            var req = {}
            req.ok = function ok(o) {
                console.log('response was', o )
            }

            req.query = { where: {title: { like: '%awe%' } }}
            req.query = {where: Sequelize.and(
                { name: 'a project' },
                Sequelize.or(
                    { id: [1, 2, 3] },
                    { id: { gt: 10 } }
                )
            )}


            req.query = {where:
                Sequelize.and(
                    { src: {like:"%Game%"} },
                    {episode:  2 },
                    {season:  2 }
                    /*Sequelize.or(
                     { id: [1, 2, 3] },
                     { id: { gt: 10 } }
                     )*/
                )
            }

            req.query = {
                name:"game",
                season: 2,
                episode: 3
            }
            //self.content.searchItems(req, res)
            //self.find_content(req, res)

            req.method = 'GET'
            req.contentPath = cPSettings.defaultContent;
            //req.contentPath = 'ritv_requests/a.mp4';
            req.headers = {}
            //contentProvider.sendContent(req, res)

        }
    }



    p.defineBreadcrumbRestHelper = function defineBreadcrumbRestHelper(server) {
        server = self.cQS.credentialsServer.api;
        self.breadcrumbs = RestHelperSQLTest.createHelper('breadcrumbs',
            server,
            {
                name:'breadcrumbs',
                fields:
                {name: "", desc: "", user_id: 0, imdb_id: 0, content_id: 0}
                ,
                fxGetUserId:LoginAPIConsumerService.pullSessionIDFromRequest,
                fxStart:testBreadCrumbsUserId,
            }
        );



        function testBreadCrumbsUserId() {
            var config = {}
            config.port = self.settings.port; ///sh.clone(self.settings)
            config.resetRequest=true;

            var t = EasyRemoteTester.create('test Breadcrumbs API',config);
            var urls = {}
            urls.getBreadcrumbs = t.utils.createTestingUrl('api/breadcrumbs')
            urls.getContent = t.utils.createTestingUrl('api/get_content')
            urls.verifyConsumer = t.utils.createTestingUrl('api/verify');
            t.settings.portOverride = self.settings.loginAPI.port;
            urls.login = t.utils.createTestingUrl('api/login');
            t.settings.portOverride = null;

            t.add(function getBreadcrumbs() {
                    t.quickRequest( urls.getBreadcrumbs,
                        'get', result, {name: "randomTask"})
                    function result(body) {
                        t.assert(body.success==false, 'no ok');
                        t.cb();
                    }
                }
            );

            self.cQS.testUtils.login(t, urls.login, 'mark', 'randomTask2')
            //self.cGS.testUtils.login(t, urls.login, 'mark', 'randomTask2')

            t.add(function getBreadcrumbs() {
                    t.quickRequest( urls.getBreadcrumbs,
                        'get', result, {name: "randomTask"})
                    function result(body) {
                        t.assert(body.success==false, 'no ok');
                        t.cb();
                    }
                }
            );


        }
    }


    p.defineFakeContentAPI = function defineFakeContentAPI(server) {
        //TODO: make new server
        //pull in CreditalServerQuickStart
        //start up credential server, pass in db config
        //decorate server with new vibe
        self.content = RestHelperSQLTest.createHelper('contents', server, {
            name:'contents',
            routePrePend:'sim/',
            fields:{name: "", src:"", desc: "", user_id: 0, content_id: 0,
                episode:0, season:0, show_name:"",  year:0, imdb_id:""
            },
            fxStart:testContentAPIInterface,
            reset:true,
            fxReset :function fxReset() {
                GenerateData = shelpers.GenerateData;
                var gen = new GenerateData();

                var input =  ['Game of Thrones', '4x12', 'The Blacklist',
                    'Empire', "Grey's Anatomy", '6x20',
                    "Schindler's List", 'Raging Bull', 'the Godfather', ''];

                function addSrc(obj) {
                    obj.src =  ''
                    var content = 'content/';
                    /*sh.str.ifStr(obj.series, 'series/')+
                     sh.str.ifStr(obj.series && obj.name != null, obj.name+'/')+
                     sh.str.ifStr(obj.series && obj.name != null, obj.name+'/')+
                     '.mp4'*/
                    if ( obj.series == true) {
                        content += 'series/';
                        if ( obj.series_name != null ) {
                            content += obj.series_name //+ ' - '
                        }
                        if ( obj.name != null ) {
                            content += ' - ' + obj.name //+ ' - '
                        }
                        content += ' ' + obj.season + 'x' + obj.episode;
                    }
                    else {
                        //if ( obj.name != null ) {
                        content += obj.name// + ' - '
                        //}
                        //content += obj.season + ' x ' + obj.episode;
                    }

                    content += '.mp4';
                    obj.src = content;

                }

                function isNumber(n) {
                    return !isNaN(parseFloat(n)) && isFinite(n);
                }


                function makeArray(input) {
                    var output =[]
                    var prev  = {}
                    for (var i = 0; i < input.length; i++) {
                        var item = input[i]

                        var next = input[i+1];

                        var firstNumber = false

                        if ( next != null ){
                            firstNumber = next.slice(0,1)
                        }


                        if ( isNumber(firstNumber) ) {
                            i++;




                            output.pop();


                            var s = next.split('x')[0];
                            var e = next.split('x')[1];
                            s = parseInt(s)
                            e = parseInt(e)
                            for (var sea = 1; sea < s; sea++) {

                                for (var epi = 1; epi < e; epi++) {
                                    var obj = sh.clone(prev);
                                    obj.season = sea;
                                    obj.episode = epi;
                                    obj.series = true;
                                    obj.series_name = item;

                                    addSrc(obj);

                                    obj.desc = item  + ' ' +
                                        obj.season  + 'x' + obj.episode;
                                    output.push(obj);
                                }

                            }


                            continue;
                        }

                        var obj = {}
                        obj.name = item;
                        obj.desc = item;
                        addSrc(obj);
                        output.push(obj);
                        prev = obj;

                    }
                    return output
                }


                var output = makeArray(input)
                var model = gen.create(output, function (item, id, dp) {
                    //item.name = id;
                    // item.id = id;
                    //item.desc = GenerateData.getName();
                });

                return model;
            }
        });

        //http://192.168.81.133:10003/gX?limit=3&src=game%201x1
        //
        self.gX = function gX(req, res) {
            self.proc('change', req.query)
            var q = req.query;
            res.ok = function ok(x){
                if ( req.ok != null ) {
                    req.ok(x);
                    return;
                }
                res.send(x)
            }
            //TODO: move this code somewhere else
            var query = req.query;//JSON.parse(req.query);

            if ( req.query.pquery != null ) {
                query =JSON.parse( req.query.pquery )
            }

            var andLimits = [];
            andLimits.push({ src: {like:"%"+query.name+"%"} })
            if (query.season_name) {
                andLimits.push({ src: {like: "%" + query.season_name + "%"} })
            }
            if (query.episode) {
                andLimits.push({ episode:query.episode });
            }
            if (query.season) {
                andLimits.push({ season:query.season });
            }

            if (query.year && false == true ) {
                andLimits.push({ year:  query.year  })
            }
            var arr =  Sequelize.and.apply(this, andLimits)

            var query_ = {where:arr}

            /*
             Sequelize.and(
             { src: {like:"%Game%"} },
             {episode:  2 },
             {season:  2 }
             *//*Sequelize.or(
             { id: [1, 2, 3] },
             { id: { gt: 10 } }
             )*//*
             )
             }
             */
            req.query = query_;

            self.content.searchItems(req, res)
            // res.end();
        }

        server.get('/gX', self.gX);
        server.get('/api/find_content', self.gX);


        var contentProvider = require('./content-provider');

        var defaultContent = 'ritv_requests/a.mkv'
        server.get('/content/:filePath', contentProvider.sendContent);
        //server.get('/getcontent/:filePath', contentProvider.sendContent);
        server.get('/getcontent/:filePath', function fakeFileRequestMiddleware(req, res) {
            req.contentPath = 'ritv_requests/b.mkv';
            req.contentPath = defaultContent
            contentProvider.sendContent(req, res)
        });



        function testContentAPIInterface() {

            /* console.log = function () {
             //return;
             }*/
            var res = {}
            res.ok = function ok(o) {
                console.log('response was', o )
            }

            var req = {}
            req.ok = function ok(o) {
                console.log('response was', o )
            }

            req.query = { where: {title: { like: '%awe%' } }}
            req.query = {where: Sequelize.and(
                { name: 'a project' },
                Sequelize.or(
                    { id: [1, 2, 3] },
                    { id: { gt: 10 } }
                )
            )}


            req.query = {where:
                Sequelize.and(
                    { src: {like:"%Game%"} },
                    {episode:  2 },
                    {season:  2 }
                    /*Sequelize.or(
                     { id: [1, 2, 3] },
                     { id: { gt: 10 } }
                     )*/
                )
            }

            req.query = {
                name:"game",
                season: 2,
                episode: 3
            }
            //self.content.searchItems(req, res)
            self.gX(req, res)

            req.method = 'GET'
            req.contentPath = defaultContent;
            //req.contentPath = 'ritv_requests/a.mp4';
            req.headers = {}
            //contentProvider.sendContent(req, res)

        }
    }



    p.defineIMDBRestHelper = function defineIMDBRestHelper(server) {
        var restHelperSettings = {
            name:'imdbs',
            fields:
            {name: "", desc: "", user_id: 0, imdb_id: 0, image: "",
                rating:0, year:0, genre:"", series:true, series_name:"",
                series_id:0, seasons:0, episode:0}
            //fxStart:testIMDBs
        }
        self.imdbs = RestHelperSQLTest.createHelper('imdbs', server, restHelperSettings);

        var getImdbIdRoute = '/api/imdb_ids'
        server.get('/api/imdb_ids', function get_imdb_ids(req, res) {


            var token = {}
            var work = new PromiseHelperV3();
            token.silentToken = true
            work.wait = token.simulate == false;
            work.startChain(token)

            work.add(function getunderscoreIdsFromRequest() {
                var idsO = req.query.ids;
                var ids = sh.splitStrIntoArray(idsO);
                if ( ids == null || ids.length == 0  ) {
                    res.end('???')
                    work.stop();
                    return
                }
                ids = sh.array.removeNulls(ids, true)
                token.ids = ids;
                work.next();
            })
            work.add(function checkDatabases() {
                var query = {where:{imdb_id:token.ids}}
                var searchSettings  = {};
                searchSettings.fxResult = gotResult;
                searchSettings.query  = query;
                token.oldResults= [];

                function gotResult(results){
                    var dbIds = sh.arrayCollectProp(results, 'imdb_id')
                    var _ = require('underscore')._
                    token.imdbIdsToGet = _(token.ids).difference(dbIds);
                    token.imdbIdsToGet = sh.array.removeNulls(token.imdbIdsToGet);
                    token.oldResults = results;
                    work.next();
                }
                self.imdbs.search(searchSettings)
            })
            work.add(function getFromIMDB() {

                /*
                 async.eachLimit(urls, 10,
                 function( domainToRequest, callback){
                 //console.log(domainToRequest);
                 request( domainToRequest, function done(body, response, error ) {
                 gotHTML(body, response, error, callback)
                 } );
                 },
                 function onAllURLsSaved(err){
                 self.proc('saveData')
                 sh.callIfDefined(self.settings.fxDone);
                 saveData();
                 }
                 )
                 */

                var contentItemsToCreate = [];
                token.contentItemsToCreate=contentItemsToCreate
                async.eachLimit(token.imdbIdsToGet, 10,
                    function getId(imdb_id, callback) {
                        var imdb_api_get_content =
                            require('./../ritv/imdb_movie_scraper/imdb_api_get_content').imdb_api_get_content;

                        var i = new imdb_api_get_content();
                        if (sh.startsWith(imdb_id, 'tt') == false) {
                            callback()
                            return;
                        }
                        i.getContent(imdb_id, function haveContent(content) {
                            callback();
                            contentItemsToCreate.push(content);
                        });

                    },
                    function finished(err){

                        work.next();
                    })
            })
            work.add(function saveToDatabase() {

                token.newResults= [];
                self.imdbs.settings.actor.bulkAdd(
                    token.contentItemsToCreate,
                    function saveFinished(results)
                    {
                        /*if ( err != null ) {
                         throw err;
                         }*/

                        token.newResults = results;
                        work.next();
                    })

            })
            work.add(function packageResponse() {
                var output = token.oldResults;
                output = output.concat(token.newResults)

                var output2 = sh.arrayCallMethodOnItem(output, 'get')
                output2 = JSON.stringify(output2)
                res.end(output2);
            })


            //res.end();
        });

        self.addToTest(testIMDBs)
        function testIMDBs() {

            var t = EasyRemoteTester.create('testIMDBs', {});
            function testChain(token, cb) {
                console.log('testChain');
                cb();
            }
            t.add(testChain);
            function testChain2(token, cb) {
                console.log('testChain2');
                t.quickRequest(self.createTestingUrl(getImdbIdRoute),
                    'get', result, {name: "randomTask"})
                function result(body) {
                    //t.assert(body=='4', 'msg .... ');
                    t.cb();
                }
            }
            t.add(testChain2);

            t.add(function testRouteIsValid() {
                t.quickRequest(self.createTestingUrl(getImdbIdRoute),
                    'get', result, {name: "randomTask"})
                function result(body) {
                    //t.notError('route is not defined');
                    //t.assert(body!=null, 'route is not defined');
                    t.assert(! sh.startsWith(body, 'Cannot GET' ) , 'route is not defined');
                    t.assert(body=='???', 'route not responding to bad input')
                    t.cb();
                }
            })

            t.add(function testGet1Imdb() {
                t.quickRequest(self.createTestingUrl(getImdbIdRoute),
                    'get', result, {ids: "tt0068646"})
                function result(body) {
                    t.assert( body.length == 1, 'converting item failed');
                    //t.notError('route is not defined');
                    //t.assert(body!=null, 'route is not defined');
                    t.cb();
                }
            })

            t.add(function testGet1Imdb2() {
                t.quickRequest(self.createTestingUrl(getImdbIdRoute),
                    'get', result, {ids: ["tt0068646", 'tt0141842'] })
                function result(body) {
                    t.assert( body.length == 2, 'converting item failed');
                    t.cb();
                }
            })

            function clearItemsInDB(){

                var y = {}
                y.deleteRecordFromQuery = function deleteRecordFromQuery(name,
                                                                         query, cb ) {

                    var imdbDeleteRoute = 'api/' + restHelperSettings.name + '/delete';
                    var imdbRoute_Get = 'api/' +  restHelperSettings.name  + '/get';

                    var route_search = 'api/' + name+ '/search';
                    var route_delete = 'api/' + name  + '/delete';
                    /*      t.add(function deleteItem1Items() {

                     })
                     t.add(function deleteItem2Items() {
                     t.quickRequest(self.createTestingUrl(imdbDeleteRoute),
                     'get', result, {id: 'tt0141842' })
                     function result(body) {
                     //t.assert( body.length == 2, 'converting item failed');
                     t.cb();
                     }
                     })
                     t.add(function getDeleteItem() {
                     t.quickRequest(self.createTestingUrl(imdbRoute_Get),
                     'get', result, {id: 'tt0141842' })
                     function result(body) {
                     t.assert( body == '', 'item not deleted');
                     t.cb();
                     }
                     })*/


                    var token = {}
                    var work = new PromiseHelperV3();
                    token.silentToken = true
                    work.wait = token.simulate == false;
                    work.startChain(token)

                    work.add(function getItem() {
                        t.quickRequest(self.createTestingUrl(route_search),
                            'get', result, query)
                        function result(body) {
                            if ( body.length == 0 ) {
                                sh.callIfDefined(cb);
                                work.stop();
                                return;
                            }
                            token.deleteId = body[0].id
                            //t.assert( body.length == 2, 'converting item failed');
                            work.next();
                            //Error: record does not existError: could not find id tt0068646
                        }
                    })
                    work.add(function deleteItem() {
                        t.quickRequest(self.createTestingUrl(route_delete),
                            'get', result, {id: token.deleteId });
                        function result(body) {
                            work.next();
                        }
                    })
                    work.add(function verifyItemGone() {
                        t.quickRequest(self.createTestingUrl(route_search),
                            'get', result, query)
                        function result(body) {
                            if ( body.length != 0 ) {
                                throw 'could not delete item'
                            }
                            //
                            work.next();
                        }

                        if ( cb ) { cb() };
                    })
                }

                t.add(function removeItem() {
                    y.deleteRecordFromQuery(
                        'imdbs', {imdb_id: "tt0068646"}, t.cb
                    )
                })

                t.add(function removeItem() {
                    y.deleteRecordFromQuery(
                        'imdbs', {imdb_id: "tt0141842"}, t.cb
                    )
                })


            }
            clearItemsInDB();

            t.add(function testGet1Imdb2() {
                t.quickRequest(self.createTestingUrl(getImdbIdRoute),
                    'get', result, {ids: ["tt0068646",, 'tt0141842'] })
                function result(body) {
                    t.assert( body.length == 2, 'converting item failed');
                    t.cb();
                }
            })


            function changeEverything() {
                //create one, request both
                //request

                t.add(function removeItem() {
                    y.deleteRecordFromQuery(
                        'imdbs', {imdb_id: "tt0141842"}, t.cb
                    )
                })
                t.add(function testGet1Imdb2() {
                    t.quickRequest(self.createTestingUrl(getImdbIdRoute),
                        'get', result, {ids: ["tt0068646",, 'tt0141842'] })
                    function result(body) {
                        t.assert( body.length == 2, 'deleted 1 item, both items were not returned');
                        t.cb();
                    }
                })


                t.add(function testGet1Imdb2_justTry() {
                    t.quickRequest(self.createTestingUrl(getImdbIdRoute),
                        'get', result, {ids: ["tt0068646",, 'tt0141842'] })
                    function result(body) {
                        t.assert( body.length == 2, 'deleted 1 item, both items were not returned');
                        t.cb();
                    }
                })

            }

            /*
             t.testChain2 = function testChain() {
             console.log('testChain');
             t.cb();
             }
             work.add(t.testChain2);
             */
        }
    }


    function defineTestHelpers() {
        self.startupTests = [];
        self.addToTest = function addToTests(item, name) {
            self.startupTests.push({name:name, fx:item})
        }
        self.runTests = function runTests(item, name) {

            sh.each(self.startupTests, function runTest(k,v){
                sh.logLine = function logLine(times) {
                    sh.times(times, function(){console.log();});
                }
                sh.times = function times(count, fx) {
                    for (var i = 0; i < count; i++) {
                        fx(i);
                    }
                }
                sh.logLine(3)
                self.proc('running test', v.name)
                sh.logLine(3)
                v.fx();
            })
            // self.startupTests.push({name:name, item:item})
        }

        self.createTestingUrl = function createTestingUrl(end){
            var url = 'http://localhost:' + self.settings.port ;//+ '/' + end;
            if ( ! sh.startsWith(end , '/')){
                url += '/';
            }
            url += end;

            return url;
        }
    }
    defineTestHelpers();


    function defineUtils() {
        self.utils = {}
        self.utils.generateFakeContentForContentAPI = function generateFakeContentForContentAPI() {
            var GenerateData = shelpers.GenerateData;
            var gen = new GenerateData();

            var input = ['Game of Thrones', '4x12', 'The Blacklist',
                'Empire', "Grey's Anatomy", '6x20',
                "Schindler's List", 'Raging Bull', 'the Godfather', ''];

            function addSrc(obj) {
                obj.src = ''
                var content = 'content/';
                /*sh.str.ifStr(obj.series, 'series/')+
                 sh.str.ifStr(obj.series && obj.name != null, obj.name+'/')+
                 sh.str.ifStr(obj.series && obj.name != null, obj.name+'/')+
                 '.mp4'*/
                if (obj.series == true) {
                    content += 'series/';
                    if (obj.series_name != null) {
                        content += obj.series_name //+ ' - '
                    }
                    if (obj.name != null) {
                        content += ' - ' + obj.name //+ ' - '
                    }
                    content += ' ' + obj.season + 'x' + obj.episode;
                }
                else {
                    //if ( obj.name != null ) {
                    content += obj.name// + ' - '
                    //}
                    //content += obj.season + ' x ' + obj.episode;
                }

                content += '.mp4';
                obj.src = content;

            }

            function isNumber(n) {
                return !isNaN(parseFloat(n)) && isFinite(n);
            }


            function makeArray(input) {
                var output = []
                var prev = {}
                for (var i = 0; i < input.length; i++) {
                    var item = input[i]

                    var next = input[i + 1];

                    var firstNumber = false

                    if (next != null) {
                        firstNumber = next.slice(0, 1)
                    }


                    if (isNumber(firstNumber)) {
                        i++;


                        output.pop();


                        var s = next.split('x')[0];
                        var e = next.split('x')[1];
                        s = parseInt(s)
                        e = parseInt(e)
                        for (var sea = 1; sea < s; sea++) {

                            for (var epi = 1; epi < e; epi++) {
                                var obj = sh.clone(prev);
                                obj.season = sea;
                                obj.episode = epi;
                                obj.series = true;
                                obj.series_name = item;

                                addSrc(obj);

                                obj.desc = item + ' ' +
                                    obj.season + 'x' + obj.episode;
                                output.push(obj);
                            }

                        }


                        continue;
                    }

                    var obj = {}
                    obj.name = item;
                    obj.desc = item;
                    addSrc(obj);
                    output.push(obj);
                    prev = obj;

                }
                return output
            }


            var output = makeArray(input)
            var model = gen.create(output, function (item, id, dp) {
                //item.name = id;
                // item.id = id;
                //item.desc = GenerateData.getName();
                item.imdb_id = 'tt'+(id+100);
            });

            return model;
        }

        self.convertQueryParamToQuery = function (req) {
            //TODO: move this code somewhere else
            var query = req.query;//JSON.parse(req.query);

            if ( req.query.pquery != null ) {
                query =JSON.parse( req.query.pquery )
            }

            var andLimits = [];
            andLimits.push({ src: {like:"%"+query.name+"%"} })
            if (query.season_name) {
                andLimits.push({ src: {like: "%" + query.season_name + "%"} })
            }
            if (query.episode) {
                andLimits.push({ episode:query.episode });
            }
            if (query.season) {
                andLimits.push({ season:query.season });
            }

            if (query.year && false == true ) {
                andLimits.push({ year:  query.year  })
            }
            var arr =  Sequelize.and.apply(this, andLimits)

            var query_ = {where:query}
            query_.limit = 10;
            req.query = query_;
        }
    }
    defineUtils();
    /**
     * Receive log commands in special format
     */
    p.proc = function proc() {
        sh.sLog(arguments)
    }

}






var s = new RiTV_SparkServerV2()
s.init();

