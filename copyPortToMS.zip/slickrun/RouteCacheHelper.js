/**
 * script will help you cache a express route with timeout settings
 * goal: pass req and response object to helper with key and will
 * retur a valid result store in a file
 *
 * Tests:
 * This script includes a test that creates a rest server,
 * and will test the route
 *
 * Major challenges - sending files and send data require sendfile vs send
 * saving non plaintext data should be binary, not utf
 */

var shelpers = require('shelpers')
var sh = shelpers.shelpers

var proxy = require('express-http-proxy');
var PromiseHelperV3 = shelpers.PromiseHelperV3;

var TestServer = require('./sparkserver').TestServer;
var EasyRemoteTester = shelpers.EasyRemoteTester;

var getSize = require('get-folder-size');
var touch = require('touch');


function RouteCacheHelper() {
    var p = RouteCacheHelper.prototype;
    p = this;
    var self = this;

    var types = {};

    p.setupRouteCacheHelper = function setupRouteCacheHelper(routeSettings) {
        self.settings = routeSettings;
        self.exceedsMaxSize = false;
    }

    p.handle = function handleRoute(key, req, res) {
        /*if ( settings.timeout ) {

         }*/

        var routeSettings = {}
        if ( key.id != null ) {
            routeSettings = key;
        }
        self.settings = routeSettings;


        var days = 60*1000*60*24;


        if ( routeSettings.maxSize != null ) {
            self.checkDirSize()
            //setInterval(fixAdjustFolderSize, 60*1000*60);
        }


        if ( routeSettings.strategy == 'file') {


            self.proc('file strategy', req.originalUrl, res.statusCode )
            if ( routeSettings.method != null &&
                req.method.toLowerCase() != routeSettings.method ) {
                return false;
            }

            var fileName = req.url
            var url = require('url');
            //fileName = url.parse(req.url).pathname;
            var replacePeriods = false
            replacePeriods = true
            var fileName = decodeURIComponent(fileName);

            ///?url=http://www.imdb.com/search/title?title=raging
            var removePreamble = '/?url='
            if ( sh.startsWith(fileName, removePreamble)) {
                fileName = fileName.slice(removePreamble.length -1);
            }


            if ( replacePeriods ) {
                var joiner = '088898880';
                fileName = fileName.split('.').join(joiner);

            }
            fileName = sh.stripBadFiles(fileName);
            if ( replacePeriods ) {
                fileName = fileName.split(joiner).join('.');
            }

            var detailsFile = fileName+'.details.json';

            var file = routeSettings.dir+'/'+fileName;

            var fileFound = sh.fileExists(file);

            if ( fileFound ) {
                var fs = require('fs');
                var stat = fs.statSync(file);

                if (routeSettings.expires != null) {
                    var hasExpired = sh.time.diff(stat.mtime, null, routeSettings.expires * days)
                    if (hasExpired) {
                        fileFound = false;
                    } else {

                    }
                }

                //files can stale out .... so
                if (routeSettings.maxSize != null) {
                    if (routeSettings.ageOutFiles == null) {
                        if (routeSettings.expires != null) {
                            routeSettings.ageOutFiles = routeSettings.expires / 2;
                        }
                        routeSettings.ageOutFiles = 7;
                    }
                    //touch each file that is older than a week
                    var isStale = sh.time.diff(stat.mtime, null, routeSettings.ageOutFiles * days);
                    if (isStale) {
                        touch(file)
                    }
                }
            }


            self.lastFileFromCache = false;
            //todo: how old is the file? > timeout?
            if ( fileFound ) {
                self.lastFileFromCache = true;
                var binary = false;
                var details = sh.readFile(routeSettings.dir+'/'+detailsFile);
                details = JSON.parse(details);

                var encoding = null
                if ( details.encodedAs == 'binary') {
                    binary = true;
                    encoding = 'binary';
                }

                var content = sh.readFile(file,null,  binary);


                //res._headers = details;
                sh.each(details.headers, function fix(k,v){
                    if ( ! sh.includes(['content-length...','content-encoding...','content-type'], k,true) )
                    { return }
                    res.setHeader(k, v);
                })

                self.proc('match')

/*

                if (details.encodedAs==null) {
                    res.end(content);
                    //fxOldSend.call(res, data)//, details.encodedAs);
                } else {
                   // fxOldSend.call(res, data, details.encodedAs);
                    res.end(content, encoding)
                }
*/

                if (details.encodedAs==null) {
                    console.log('send content')
                    res.send(content);
                } else {
                    console.log('send file')
                    res.sendfile(file);
                }

                return true;
            }

            if ( fileFound == false ) {
                //todo, how big is the folder?
                self.proc('file not found', fileFound )
                var fxOldSend = res.send
                //bypass setting headers
                //res.headersSent = true;
                var fxOldSet = res.set;
                res.set = function re(k, v) {
                    //console.log('set',k)
                    if ( k == 'set-cookie') {
                        return;
                    }
                    //fxOldSet(k,v)
                    fxOldSet.call(res, k,v);
                }

                res.send = function sendReRoute(data) {
                    try {
                        //console.log('data ............', data.length, routeSettings)
                        var abortSave = false
                        if ( data == null ) {
                            fxOldSend.call(res, data);
                            self.proc('aborting save... data is null')
                            return;
                        }
                        if (routeSettings.maxFileSize != null &&
                            data.length > routeSettings.maxFileSize * 1024 * 1024) {
                            self.proc('file size too big for', filename, data.length, 'not saving')
                            abortSave = true
                        }
                        /*if (self.exceeds) {
                         self.proc('exceeds size', 'not saving')
                         abortSave = true
                         }*/
                        if (abortSave) {
                            fxOldSend.call(res, data);
                            self.proc('aborting save')
                            return;
                        }

                        var gzip = res._headers['content-encoding'] == 'gzip'
                        if (gzip ) {

                        }
                        //data = '5555';
                        //console.log('part 2')
                        var plainText = res._headers['content-type'] == 'text/html'
                        var writeIterationCookieCrumb = {}
                        writeIterationCookieCrumb.name = fileName;
                        writeIterationCookieCrumb.dir = routeSettings.dir
                        writeIterationCookieCrumb.contents = data //timestamp
                        /*if (plainText 'content=encoding) {
                         writeIterationCookieCrumb.binary = false;
                         data = data.toString();
                         //data = 'f'
                         }*/
                        //res.unbinary is set to indicate content was decompressed and
                        //should be saved as utf-8
                        if (plainText == false && res.unbinary != false ) { //'content=encoding) {
                            writeIterationCookieCrumb.binary = true;
                        }

                        sh.writeFile2(  writeIterationCookieCrumb  )

                        var writeIterationCookieCrumb = {}
                        writeIterationCookieCrumb.name = detailsFile;
                        writeIterationCookieCrumb.dir = routeSettings.dir
                        var headers = sh.clone(res._headers);

                        var details = {};
                        details.url = req.url;
                        details.headers = headers;

                        if ( res.encodedAs == 'binary' || plainText == false ) {
                            details.encodedAs = 'binary';
                        }

                        writeIterationCookieCrumb.contents = sh.toJSONString(
                            details);
                        sh.writeFile2(
                            writeIterationCookieCrumb
                        )



                        //console.log('part 2', data)
                        if (details.encodedAs==null) {
                            fxOldSend.call(res, data)//, details.encodedAs);
                        } else {
                           // fxOldSend(data, details.encodedAs)
                            res.sendfile(routeSettings.dir+'/'+fileName)
                            //fxOldSend.call(res, data, details.encodedAs);
                        }
                    } catch(e) {
                        self.proc('error', e, e.stack)
                        console.error('e', e)
                    }
                }
            }

        }


        return false;
    }

    function defineUtils() {
        //sh.errors.jumpError('error test');
        self.utils = {}
        self.utils.getSizeOfDir = function getSizeOfDir(cb) {
            getSize(self.settings.dir, function (err, size){
                var fsize = (size/1024/1024).toFixed(2)
                console.log('fsize', fsize);
                cb(fsize, err)
            })
        }

        self.utils.emptyDir = function emptyDir() {
            sh.fs.rmrf(self.settings.dir);
            sh.makePathIfDoesNotExist(self.settings.dir);
        }


        self.checkDirSize = function checkDirSize() {

            getSize(self.settings.dir, function (err, size){
                var fsize = (size/1024/1024).toFixed(2);
                console.log('fsize', fsize);
                var detailsMarker = '.details.json';
                if ( fsize > self.settings.maxSize  ) {
                    var files = sh.getFilesInDirectory(self.settings.dir+'/',
                        false, true);
                    sh.each(files, function findFirstNonJSONFile(k, file){
                        if ( sh.includes(file, detailsMarker )){
                            return;
                        }
                        sh.deleteFile(self.settings.dir+'/'+file);
                        sh.deleteFile(self.settings.dir+'/'+file+detailsMarker);
                        return false;
                    })
                    self.exceedsMaxSize = true;
                }
                self.exceedsMaxSize = false;
            })
        }
    }
    defineUtils();


    function defineTestUtils(t, urlPreAmbleOverride){
        self.testUtils = {};
        var urlPreamble = '/proxy?url='
        if ( urlPreAmbleOverride != null) {
            urlPreamble =  urlPreAmbleOverride;
        }
        var  basicImage = urlPreamble+'http://ia.media-imdb.com/images/M/MV5BMjEyMjcyNDI4MF5BMl5BanBnXkFtZTcwMDA5Mzg3OA@@._V1_SX214_AL_.jpg';
        var  basicHTML = urlPreamble+'http://www.imdb.com/search/title?title=raging'

        self.testUtils.buildRouteHelperTests = function buildRouteHelperTests(t){

            sh.throwErrorIfPropNull(self.settings, 'port', 'port needs to be defined on self.settings');


            self.createTestingUrl = function createTestingUrl(end) {
                var url = 'http://localhost:' + self.settings.port;//+ '/' + end;
                if (!sh.startsWith(end, '/')) {
                    url += '/';
                }
                url += end;

                return url;
            }

            t.getFile = function getFile(url) {
                url = self.testUtils.fixUrl(url)
                url = sh.dv(url, basicImage);

                t.add(function getFile(){
                    t.quickRequest(self.createTestingUrl(url),
                        'get', result )
                    function result(body, res) {
                        //t.assert(body=='4', 'msg .... ');
                        t.as2(res!= null, true, 'response null ')
                        //  console.log(res.headers)
                        t.headers = res.headers;
                        t.assert(body.length > 500 , 'image did not send')
                        t.cb();
                    }
                })

            }

            t.getHTMLFile = function getHTMLFile(url) {
                url = sh.dv(url, basicHTML);
                t.add(function getFile(){
                    t.quickRequest(self.createTestingUrl(url),
                        'get', result )
                    function result(body, res) {
                        //t.assert(body=='4', 'msg .... ');
                        //  console.log(res.headers)
                        t.headers = res.headers;
                        t.as2(body.length > 500 , null, 'image did not send')
                        t.cb();
                    }
                })

            }


            /**
             * Assumes previous file loaded after this one
             * @param url
             */
            t.getFile2 = function getFile2(url) {
                url = sh.dv(url, basicImage);

                t.add(function getFile2() {
                    t.quickRequest(self.createTestingUrl(url),
                        'get', result)
                    function result(body, res) {
                        var prop = 'content-type'
                        t.assert(res.headers[prop] ==
                            t.headers[prop], 'content length not the same');

                        // console.log(res.headers)
                        t.headers = res.headers;
                        t.assert(body.length > 500, 'image did not send')
                        t.cb();
                    }
                })
            }


            t.getInvalidFile = function getInvalidFile(url) {
                url = self.testUtils.fixUrl(url)
                url = sh.dv(url, basicHTML);
                t.add(function getFile(){
                    t.quickRequest(self.createTestingUrl(url),
                        'get', result )
                    function result(body, res) {
                        t.headers = res.headers;
                        //.as2(body.length > 500 , null, 'image did not send')
                        t.cb();
                    }
                })

            }



            t.dirSize = function dirSize(expectedSize) {
                t.add(function getFile2() {
                    self.utils.getSizeOfDir( result)
                    function result(size, err) {
                        t.as2(expectedSize , size, 'size no matched')
                        t.cb();
                    }
                })
            }


            t.filesStored = function checkNumberOfFileStored(expectedSize) {
                t.add(function filesStored() {
                    var files =sh.fs.getFilesInDirectory(self.settings.dir)
                    t.as2(files.length, expectedSize, 'size no matched');
                    //t.assert(files.length == expectedSize, 'size no matched')
                    t.cb();
                })
            }


            t.emptyDir = function emptyDir(expectedSize) {
                t.add(function filesStored() {
                    self.utils.emptyDir();
                    t.cb();
                })

                t.filesStored(0)
            }


            t.loadedLastFileFromSource = function loadedLastFileFromSource() {
                t.add(function loadedLastFileFromSource() {
                    t.as2(self.lastFileFromCache, false, 'last file was not loaded from the source');
                    t.cb();
                })
            }

            t.loadedLastFileFromCache = function loadedLastFileFromCache() {
                t.add(function loadedLastFileFromCache() {
                    t.as2(self.lastFileFromCache, true, 'last file was not loaded from the catch (from the source)');
                    t.cb();
                })
            }


            t.stashLastRequest = function stashLastRequest(url) {
                t.add(function stashLastRequest() {
                    t.stashedRequestBody = t.lastRequestBody;
                    t.cb();
                })
            }

            t.isStashedRequestSameAsLastRequest = function isStashedRequestSameAsLastRequest(url) {
                t.add(function isStashedRequestSameAsLastRequest() {
                    t.as2(t.stashedRequestBody.length , t.lastRequestBody.length, 'last requests did not match');
                    t.as2(t.stashedRequestBody , t.lastRequestBody, 'last requests did not match');

                    t.cb();
                })
            }

        }

        self.testUtils.buildRouteHelperTests(t);

        self.testUtils.fixUrl = function fixUrl(url) {
            if ( url != null ) {
                if ( ! sh.includes( url, urlPreamble ) ) {
                    url =  urlPreamble+ url;
                }
            }
            return url
        }
    }
    self.defineTestUtils=defineTestUtils;
    /**
     * Receive log commands in special format
     */
    p.proc = function proc() {
        sh.sLog(arguments)
    }

}


exports.RouteCacheHelper =  RouteCacheHelper ;


if ( module.parent  == null ) {
    //return;
    var s = new RouteCacheHelper()

    //create express server with proxy route
    //call proxy route

    var token = {}
    var work = new PromiseHelperV3();
    token.silentToken = true
    work.wait = token.simulate==false;
    work.startChain(token)

    var o = {};

    var self = o;
    //setup express server with proxy route
    o.setupExpress = function setupExpress(token, cb){
        self.settings = {port: 10001, dir: 'requests/',
            wildcards:false,
            noProxy:true,
            fxDone:cb}
        s = new TestServer( );
        s.startServer(self.settings);
    }
    work.add(o.setupExpress);

    function defineExample() {
        o.createRouteCacheHelper = function createRouteCacheHelper(token, cb) {
            var rH = new RouteCacheHelper();
            o.routeHelper = rH;
            o.testCachedRoute = function testCachedRoute(req, res) {
                if (rH.handle('test', req, res)) {
                    return;
                }
                ;
            }
            s.server.get('/testCachedRoute', o.testCachedRoute);
            cb();
        }
        work.add(o.createRouteCacheHelper);

        o.testCacheRoute = function testCacheRoute(token, cb) {


            self.createTestingUrl = function createTestingUrl(end) {
                var url = 'http://localhost:' + self.settings.port;//+ '/' + end;
                if (!sh.startsWith(end, '/')) {
                    url += '/';
                }
                url += end;

                return url;
            }

            var t = EasyRemoteTester.create('test route cache helper', {});

            function testChain(token, cb) {
                console.log('testChain');
                cb();
            }

            t.add(testChain);
            var testCachedRoute = '/testCachedRoute';

            function testChain2(token, cb) {
                console.log('testChain2');
                t.quickRequest(self.createTestingUrl(testCachedRoute),
                    'get', result, {name: "randomTask"})
                function result(body) {
                    //t.assert(body=='4', 'msg .... ');
                    t.cb();
                }
            }

            t.add(testChain2);
        }
        work.add(o.testCacheRoute);
    }

    work.add(o.createRouteCacheHelper2 = function createRouteCacheHelper2(token, cb) {
        var rH = new RouteCacheHelper();
        o.routeHelper = rH;
        o.rH = rH;
        var dirProxyFiles = 'proxy_test_request';
        var rHSettings = {
            id:'test images',
            strategy:'file',
            dir:dirProxyFiles,
            method:'get',
            maxSize:10,
            maxFileSize:3,
            expires:10
        }
        rHSettings.port = self.settings.port;
        o.rH.setupRouteCacheHelper(rHSettings);

        o.testCachedRoute = function testCachedRoute(req, res, next){
            next();
            //if ( rH.handle('test', req, res) ) { return; };
        }

        s.server.get('/testCachedRoute', o.testCachedRoute );

        s.server.use('/proxy', function proxy(req, res, next){
            //if ( rH.handle('test', req, res) ) { return; };
            if ( rH.handle(rHSettings, req, res) ) { return; };
            next();
        });
        s.server.use('/proxy2', function proxy(req, res, next){
            //if ( rH.handle('test', req, res) ) { return; };
            if ( rH.handle(rHSettings, req, res) ) { return; };
            next();
        })

        sh.fs.rmrf(dirProxyFiles);

        s.setupProxy(s.server)

        /*
         o.testCachedRoute2 = function testCachedRoute2(req, res){
         if ( rH.handle('test', req, res) ) { return; };
         }
         s.server.get('/testCachedRoute', o.testCachedRoute2 );
         */


        cb();
    })

    o.testCacheRoute = function testCacheRoute(token, cb) {
        self.createTestingUrl = function createTestingUrl(end){
            var url = 'http://localhost:' + self.settings.port ;//+ '/' + end;
            if ( ! sh.startsWith(end , '/')){
                url += '/';
            }
            url += end;

            return url;
        }

        var t = EasyRemoteTester.create('test route cache helper', {});
        function testChain(token, cb) {
            console.log('testChain');
            cb();
        }
        t.add(testChain);
        var  testCachedRoute = '/testCachedRoute';
        t.addS(function testChain2(token, cb) {
            t.quickRequest(self.createTestingUrl(testCachedRoute),
                'get', result, {name: "randomTask"})
            function result(body) {
                //t.assert(body=='4', 'msg .... ');
                t.cb();
            }
        })

        function basicTestOfProxy() {

            var testCachedRoute = '/proxy?url=http://ia.media-imdb.com/images/M/MV5BMjEyMjcyNDI4MF5BMl5BanBnXkFtZTcwMDA5Mzg3OA@@._V1_SX214_AL_.jpg';
            t.add(function testChain2(token, cb) {
                t.quickRequest(self.createTestingUrl(testCachedRoute),
                    'get', result, {name: "randomTask"})
                function result(body, res) {
                    //t.assert(body=='4', 'msg .... ');
                    console.log(res.headers)
                    t.headers = res.headers;
                    t.assert(body.length > 500, 'image did not send')
                    t.cb();
                }
            })
            t.add(function testChain2(token, cb) {
                t.quickRequest(self.createTestingUrl(testCachedRoute),
                    'get', result, {name: "randomTask"})
                function result(body, res) {
                    console.log(res.headers)
                    var prop = 'content-type'
                    t.assert(res.headers[prop] ==
                        t.headers[prop], 'content length not the same');
                    t.assert(body.length > 500, 'image did not send')
                    t.assert(o.routeHelper.lastFileFromCache, 'image did not get cached')
                    t.cb();
                }
            })
        }

        o.routeHelper.defineTestUtils(t)//, '/proxy2?url=');
        //o.routeHelper.defineTestUtils(t, '/proxy2?url=');
        o.rH = o.routeHelper;
        //o.rH.utils.emptyDir();
        function testZeroSize() {
            t.emptyDir(0);
            o.rH.settings.maxSize = 0;
            t.getFile();
            t.getFile2();
            t.dirSize(0)
            t.filesStored(0);
            o.rH.settings.maxSize = 10;
        }
        //testZeroSize();


        function defineGetHTMLFile() {
            t.emptyDir(0);
            t.getHTMLFile();
            t.stashLastRequest()
            t.loadedLastFileFromSource();
            t.getHTMLFile();
            t.isStashedRequestSameAsLastRequest()
            t.loadedLastFileFromCache()
        }
         defineGetHTMLFile();

        function defineGetImageFile() {
            t.emptyDir(0);
            t.getFile();
            t.stashLastRequest()
            t.loadedLastFileFromSource();
            t.getFile2(); //t.getFile2();
            t.isStashedRequestSameAsLastRequest()
            t.loadedLastFileFromCache()
        }
         defineGetImageFile();


        //return;
        function defineGetInvalidImageFile() {
            t.emptyDir(0);
            t.getInvalidFile('asdf3455545');
            t.stashLastRequest()
            t.loadedLastFileFromSource();
            t.getInvalidFile('asdf3455545');
            t.isStashedRequestSameAsLastRequest()
            //t.loadedLastFileFromSource();
            //t.loadedLastFileFromCache()
        }
        defineGetInvalidImageFile();

        function defineGetInvalidImageFile2() {
            t.emptyDir(0);
            t.getInvalidFile('http://tw/.asdf3455545');
            t.stashLastRequest()
            t.loadedLastFileFromSource();
            t.getInvalidFile('http://tw/.asdf3455545');
            t.isStashedRequestSameAsLastRequest()
            t.loadedLastFileFromSource();
            //t.loadedLastFileFromCache()
        }
        defineGetInvalidImageFile2();

        function defineTestExpiration() {
            o.rH.settings.maxSize = 10;//reset settings
            t.emptyDir(0);
            t.getFile();
            t.loadedLastFileFromSource();
            t.getFile();
            t.loadedLastFileFromCache()
            o.rH.settings.expires = (2*1000)/(24*60*60*1000);
            t.getFile();
            t.loadedLastFileFromCache()
            t.wait(5);
            t.getFile();
            t.loadedLastFileFromSource();
        }
        //defineTestExpiration();


        function defineTestMakeFileSize() {
            o.rH.settings.maxSize = 10;//reset settings
            t.emptyDir(0);
            t.getFile();
            t.loadedLastFileFromSource();
            t.getFile();
            t.loadedLastFileFromCache()
            o.rH.settings.expires = (2*1000)/(24*60*60*1000);
            t.getFile();
            t.loadedLastFileFromCache()
            t.wait(5);
            t.getFile();
            t.loadedLastFileFromSource();
        }
        //defineTestMakeFileSize();

        //t.add(testChain2);
    }
    work.add(o.testCacheRoute);
}


