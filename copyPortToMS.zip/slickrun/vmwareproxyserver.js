/**
 * proxy requests for vmware. from one ip address on the machine, to another.
 * Actors: Mobile device, Host PC and Virtual Machine Guest
 * Script will reroute traffic from Host PC to VM
 * Script is to be run on Host PC
 * @type {*}
 */

var shelpers = require('shelpers')
var sh = shelpers.shelpers
var proxy = require('express-http-proxy');
var TestServer = require('./sparkserver').TestServer;

function VmwareProxyServer() {
    var p = VmwareProxyServer.prototype;
    p = this;
    var self = this;

    p.startServer = function startServer(_config) {


    }


    /**
     *
     */
    p.runTests = function runTests() {

    }


    s = new TestServer();
    s.startServer({
        port: 5003, dir: 'requests/',
        wildcards: false,
        fxDone: null
    });

    //setupProxy
    self.setupProxyToVM = function setupProxyToVM(server) {
        server.all('/*', proxy(function getHost(req, res) {
                var output = "http://192.168.81.133:10001"
                //Had to modify proxy module to handle the ':'
                /* express-http-proxy :69
                 if ( reqOpt.hostname == null ) {
                 console.log('hostname is null?', reqOpt)
                 }
                 else if ( reqOpt.hostname.indexOf(':') != -1  ) {
                 var hostname = reqOpt.hostname
                 reqOpt.hostname = hostname.split(':')[0]
                 reqOpt.port = hostname.split(':')[1];
                 }
                 */
                output = "192.168.81.133:10003"
                return output;
            })
        )
        return

    }

    self.setupProxyToVM(s.server);


    p.init = function init(config) {
        self.startServer(config);
        self.start();
    }

    /**
     * Receive log commands in special format
     */
    p.proc = function proc() {
        sh.sLog(arguments)
    }
}

var s = new VmwareProxyServer()


