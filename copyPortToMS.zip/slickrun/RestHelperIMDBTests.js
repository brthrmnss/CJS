/**
 * Created by user on 1/5/15.
 */
/*
 Tests for rest helper
 */

var shelpers = require('shelpers')
var sh = shelpers.shelpers
var TestHelper = shelpers.TestHelper;
var reqPost = TestHelper.reqPost;
var PromiseHelperV3 = shelpers.PromiseHelperV3;


function RestHelperIMDBTests() {
    var p = RestHelperIMDBTests.prototype;
    p = this;
    var self = this;


    function assert(eq, msg) {
        if ( eq == false ){
            throw new Error(msg);
        }
    }




    /**
     *
     */
    p.runTests = function runTests() {

        //self.basicRestTests();
        self.basicRest();

    }


    p.basicRestTests = function runTests() {

        self.settings = {}
        self.settings.port = 10001
        TestHelper.addQuickRequest(self, 'http://localhost:'+self.settings.port+'/');

        var token = {}
        var work = new PromiseHelperV3();
        token.silentToken = true
        work.wait = token.simulate==false;
        work.startChain(token)


        var c = {};

        var restType = 'breadcrumbs'

        self.routeName = function routeName(action, resourceName ) {
            resourceName  = sh.defaultValue(resourceName, restType)
            return 'api/'+resourceName+'/'+action
        }
        self.testGet = function testGet(token, cb) {
            self.quickRequest(self.routeName('', restType), 'get', result, {user_id: "6"})
            function result(body) {
                console.log('body', body)
                c.count = body.length;
                //tasks.showId(0, 'lll');
                //assert(tasks.records.length == 2, 'did not reset')
                cb();
            }
        }
        work.add(self.testGet);

        self.get_create = function get_create(token, cb) {
            c.newBreadcrumb = {}
            c.newBreadcrumb.imdb_id = 565
            c.newBreadcrumb.user_id = 565
            c.newBreadcrumb.duration = 0;
            self.quickRequest(self.routeName('create', restType), 'get', result, c.newBreadcrumb)
            //data.addItem();
            function result(body, resp) {
                console.log('body', body)
                if ( resp.headers.location != null ) {
                    //reduce count, ad this was an existing entry ....
                    c.count --;
                }
                //assert(data.checkRecordSize(), 'did not add task properly')
                cb();
            }
        }
        work.add(self.get_create);



        self.get_create = function get_create(token, cb) {
            c.newBreadcrumb.duration = 50;
            self.quickRequest(self.routeName('create', restType), 'get', result, c.newBreadcrumb)
            //data.addItem();
            function result(body, resp) {
                console.log('body', body)
                c.nextPlaceId = resp.headers.location;
                //assert(data.checkRecordSize(), 'did not add task properly')
                cb();
            }
        }
        work.add(self.get_create);


        self.get_create2 = function get_create(token, cb) {
            c.newBreadcrumb.duration = 50;
            self.quickRequest( c.nextPlaceId , 'get', result)
            function result(body, resp) {
                assert(body.duration == c.newBreadcrumb.duration , 'duration was not updated')
                cb();
            }
        }
        work.add(self.get_create2);




        self.verifySize = function verifySize(token, cb) {
            c.newBreadcrumb.duration = 50;
            self.quickRequest( self.routeName('', restType), 'get', result)
            function result(body, resp) {
                assert(body.length == c.count +1, 'add 2 items ' + body.length +' ' +  c.count +1 )
                // c.nextPlace = resp.id;
                //assert(data.checkRecordSize(), 'did not add task properly')
                cb();
            }
        }
        work.add(self.verifySize);

    }

    p.basicRest = function testProxyIMDB() {

        return;
        self.settings = {}
        self.settings.port = 10001
        TestHelper.addQuickRequest(self, 'http://localhost:'+self.settings.port+'/');

        var token = {}
        var work = new PromiseHelperV3();
        token.silentToken = true
        work.wait = token.simulate==false;
        work.startChain(token)


        var c = {};

        var restType = 'breadcrumbs'

        self.makeUrl = function makeUrl(url_ ) {
            //resourceName  = sh.defaultValue(resourceName, restType)
            return   url_
        }
        self.testGet = function testGet(token, cb) {
            self.quickRequest(self.makeUrl('/proxy?url=http://www.imdb.com/title/tt1661199/'), //&user_id=2&indivSearch=true'),
                'get', result, {user_id: "6"})
            function result(body) {
                console.log('body', body)
                c.count = body.length;
                //tasks.showId(0, 'lll');
                //assert(tasks.records.length == 2, 'did not reset')
                cb();
            }
        }
        work.add(self.testGet);

        return;

        self.get_create = function get_create(token, cb) {
            c.newBreadcrumb = {}
            c.newBreadcrumb.imdb_id = 565
            c.newBreadcrumb.user_id = 565
            c.newBreadcrumb.duration = 0;
            self.quickRequest(self.routeName('create', restType), 'get', result, c.newBreadcrumb)
            //data.addItem();
            function result(body, resp) {
                console.log('body', body)
                if ( resp.headers.location != null ) {
                    //reduce count, ad this was an existing entry ....
                    c.count --;
                }
                //assert(data.checkRecordSize(), 'did not add task properly')
                cb();
            }
        }
        work.add(self.get_create);



        self.get_create = function get_create(token, cb) {
            c.newBreadcrumb.duration = 50;
            self.quickRequest(self.routeName('create', restType), 'get', result, c.newBreadcrumb)
            //data.addItem();
            function result(body, resp) {
                console.log('body', body)
                c.nextPlaceId = resp.headers.location;
                //assert(data.checkRecordSize(), 'did not add task properly')
                cb();
            }
        }
        work.add(self.get_create);


        self.get_create2 = function get_create(token, cb) {
            c.newBreadcrumb.duration = 50;
            self.quickRequest( c.nextPlaceId , 'get', result)
            function result(body, resp) {
                assert(body.duration == c.newBreadcrumb.duration , 'duration was not updated')
                cb();
            }
        }
        work.add(self.get_create2);




        self.verifySize = function verifySize(token, cb) {
            c.newBreadcrumb.duration = 50;
            self.quickRequest( self.routeName('', restType), 'get', result)
            function result(body, resp) {
                assert(body.length == c.count +1, 'add 2 items ' + body.length +' ' +  c.count +1 )
                // c.nextPlace = resp.id;
                //assert(data.checkRecordSize(), 'did not add task properly')
                cb();
            }
        }
        work.add(self.verifySize);

    }





    /**
     * Receive log commands in special format
     */
    p.proc = function proc() {
        sh.sLog(arguments)
    }

}

exports.RestHelperIMDBTests = RestHelperIMDBTests;

if ( module.parent == null ) {
    var tester = new RestHelperIMDBTests();
    tester.runTests();
}