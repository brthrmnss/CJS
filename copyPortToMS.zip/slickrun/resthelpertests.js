/**
 * Created by user on 1/5/15.
 */
/*
 Tests for rest helper
 */

var shelpers = require('shelpers')
var sh = shelpers.shelpers
var TestHelper = shelpers.TestHelper;
var reqPost = TestHelper.reqPost;


function RestHelperTests() {
    var p = RestHelperTests.prototype;
    p = this;
    var self = this;


    function assert(eq, msg) {
        if ( eq == false ){
            throw new Error(msg);
        }
    }


    function testRoutes() {
        p.testX = function testX() {
            var reqoptions = {}
            reqoptions.url = 'http://localhost:'+self.settings.port+'/changeEnv'
            reqoptions.form = {}
            reqoptions.method = 'GET'
            reqoptions.fx2 = function storeContents(body){
                console.log('test ok...')
            };
            reqoptions.name = 'test changeEnv'
            console.log('testing...')
            reqPost(reqoptions)
        }
        p.test2 = function test2() {
            var reqoptions = {}
            reqoptions.url = 'http://localhost:'+self.settings.port+'/post/jgrew'
            reqoptions.form = {}
            reqoptions.method = 'GET'
            reqoptions.showBody =  true;
            reqoptions.fx2 = function storeContents(body){
                console.log(reqoptions.url, 'test ok...')
            };
            reqoptions.name = 'test changeEnv'
            console.log('testing...')
            reqPost(reqoptions)
        }
        p.quickRequest = function quickRequest(url, method, fx, postData) {
            if ( method == null ) {
                method = types.GET
            }
            var reqoptions = {}
            reqoptions.url = 'http://localhost:'+self.settings.port+'/'+url
            if ( postData == null ) { postData = {} }
            if ( method == types.POST || method == types.POST.toLowerCase() ) {
                reqoptions.form = postData
            } else {
                reqoptions.qs = postData
            }

            reqoptions.method = method
            reqoptions.showBody =  true;
            reqoptions.fx2 = function storeContents(body){
                console.log(reqoptions.url, 'test ok...')
            };
            reqoptions.name = 'test ' + sh.paren(url)
            console.log('testing...')
            reqPost(reqoptions)
        }
    }
    testRoutes()

    /**
     *
     */
    p.runTests = function runTests() {
        //self.quickRequest('api/login', 'post', null )
        //self.quickRequest('api/login', 'post', null, {username:"fred"})

        function testBreadCrumbs() {
            return
            self.quickRequest('api/breadcrumbs', 'get', null, {user_id:"6"},
                        function verifyLength7(body) {
                            body = JSON.parse(body)
                            assert(body.length== 7, 'wrong size')
                        })
            self.quickRequest('api/breadcrumbs', 'get', null, {user_id:"6"})
        }
        testBreadCrumbs();
        return;
        self.quickRequest('api/getSession', 'get', null, {user_id:"6"})
        return

        // self.testX();
        // self.test2();
        // self.quickRequest('testMethod')
        // self.quickRequest('testPost', 'post')
        // self.quickRequest('final/api/hart')

        self.quickRequest('testPost', 'post', null, {username:"fred"})
        self.quickRequest('testPostx', 'post', null, {username:"fredx"})
    }


    /**
     * Receive log commands in special format
     */
    p.proc = function proc() {
        sh.sLog(arguments)
    }

}

exports.RestHelperTests = RestHelperTests;

