/**
 * Usage, override properties in config.js that need to be changed for local repo
 * @type {{}}
 */
var config = {};

config.db.port = "3306";
config.db.user = "root";
config.db.password = "password";
config.db.database = "fileserver";



module.exports = config;