var config = {};

config.paths = {}; //This is the env for the paths
config.paths.root = __dirname + '/..';
config.paths.file_store = config.paths.root + "/files";

config.server = {}; //This is the env for the WEB server
config.server.name = "127.0.0.1";
config.server.port_http = "8000";

config.db = {}; //This is the env for the DB server
config.db.client = "mysql";
config.db.server = "127.0.0.1";
config.db.port = "8889";
config.db.requiredVersion = "5.6";
config.db.connectionLimit = 20;
config.db.user = "fileserver";
config.db.password = "fileserverpwd";
config.db.database = "fileserver";


config.db.port = "3306";
config.db.user = "root";
config.db.password = "password";
config.db.database = "fileserver";


config.encode = {}; //This is env for the encode/decode key
config.encode.rowIdEncrptKey = "Yathura";

config.auth = {}; //This is env for the authentication
config.auth.secret = "this is the secret secret secret 12356";
config.auth.secretExpiresInMinutes = 2;

config.content = {}; //This is env for the content
config.content.accessRestrictInMinutes = 5;
config.content.accessRestrictCount = 3;


module.exports = config;