C:\Users\user1\Dropbox\projects\learn angular\port3\app


C:\Users\user1\Dropbox\projects\crypto\slickrun\portfolio_dir



#where to get index pages from? 
C:\Users\user1\Dropbox\projects\learn angular\port3\.tmp