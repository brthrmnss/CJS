console.log('script ran...')
var times = [];
for ( var i = 0 ; i < 10; i++) {
    times.push(i)
}


var async = require('async')

async.forEachSeries(times, function procTimes(iterationInx, fxDoneIteration) {



    if (iterationInx==2){
        var prompt = require('prompt');
        prompt.start();
        prompt.get(['continue'], function (err, result) {
            if (err) { return onErr(err); }
            console.log('Command-line input received:');
            console.log('  Username: ' + '"'+result.continue+'"', result.continue == 'y');
            console.log('  Email: ' + result.email);
            if (result.continue == 'y') {
                fxDoneIteration();
                console.log('continuing')
            } else {
                prompt.pause();
               // process.exit();
            }
        });
        return;
    }


    setTimeout(function (i) {
        console.log('at ' + i)
        fxDoneIteration();
    },  1000, iterationInx+1)


}, function done() {})