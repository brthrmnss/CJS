/**
 * Created by user on 7/30/15.
 */

/**
 * 2 modes
 * real mode
 * and procted mode
 */
var sh = require('shelpers').shelpers;
var shelpers = require('shelpers');

var EasyRemoteTester = shelpers.EasyRemoteTester;

function ScriptHoster() {
    var p = ScriptHoster.prototype;
    p = this;
    var self = this;
    self.settings = {}
    self.data = {};
    p.init = function init(url, appCode) {
        if ( url.get != null ) {
            self.server= url;
            // self.settings = {}
        }

        self.defineServer()
    }
    p.defineServer = function defineServer() {
        var server = self.server

        self.output = '';
        self.outputLast = ''
        server.get('/run_command', function run_command(req, res) {


            self.output = '';
            self.outputLast = ''


            var cmd = req.query.cmd
            if ( cmd != null ) {
            }

            var file = '';
            var args = [];

            var queryData = req.query.data;
            if ( queryData != null ) {
                if ( sh.isString(queryData) &&
                    sh.startsWith(queryData, '{')) {
                    var json = JSON.parse(req.query.data)
                };
                json = queryData;

                cmd = json.cmd;
                file = json.file;
                if ( sh.includes(json.cmd, ' ')  ) {
                    var cmds = sh.splitStringOnQuotes(json.cmd);
                    cmd = cmds.pop()
                    args = cmds
                };
            };

            var oneshot = req.query.oneshot;

            oneshot = sh.dv(oneshot, true)
            if ( oneshot == "false" ) {oneshot = false}


            //write a config

            var CommandRunner = sh.CommandRunner
            var cR  = new CommandRunner();
            var settings ={}
            settings.cmd = cmd
            settings.args = args
            settings.silent = false;


            var fxCallbackTestComplete = function fxCallbackTestComplete() {
                console.log('done')
                if ( oneshot ) {
                    res.json({
                        output: sh.toJSONString(
                            self.output),
                        success: true, session: req.session
                    });
                }
            }
            self.output  = ''
            settings.fxEcho =  function fxEcho(data){
                self.output += data
                self.outputLast += data

            }
            settings.fxCallback =  fxCallbackTestComplete

            cR.execute(settings);


            self.data.lastCmd = cR;

            if ( oneshot == false ) {
                res.json({
                    status: "started",
                    success: true
                });
            }

        })


        server.get('/cmd_get_output', function cmd_get_output(req, res) {
            var all = req.query.all
            sh.convertUrlValToBoolean = function convertUrlValToBoolean(val, defaultVal) {
                if ( val == true || val == 'true') {
                    val = true
                }
                if ( val == true || val == 'false') {
                    val = false
                }
                if ( defaultVal != null && val == null ) {
                    val = defaultVal;
                };

                return val;

            }
            sh.urlVal = sh.convertUrlValToBoolean;

            all = sh.convertUrlValToBoolean(req.query.all, true)
            console.error(all)

            var output = {}
            if ( all ) {
                output.output = self.output
            } else {
                output.output = self.outputLast
            }

            res.json(output);
        })

        server.get('/cmd_send', function cmd_get_output(req, res) {
            var query = req.query.input
            self.data.lastCmd.write(query)
            res.json({output:'sent ' + query, success:true})
            // res.json(output);
        })
    }

    p.test = function test(delay) {

        self.proc('running tests')

        var config = {}
        config.port = self.settings.port; ///sh.clone(self.settings)
        //config.resetRequest=true;
        //config.fxDone = fxDone

        var t = EasyRemoteTester.create('test testRunCommandRoute',config);
        var urls = {}
        urls.run_command = t.utils.createTestingUrl('run_command')
        urls.get_output = t.utils.createTestingUrl('cmd_get_output')
        urls.cmd_send = t.utils.createTestingUrl('cmd_send')
        t.add(function doSearchWithNoLogin() {
                var json = {};
                json.cmd = 'node test_remote_cmd.js'
                t.quickRequest( urls.run_command,
                    'get', result, {data: json})
                function result(body) {
                    console.log(body);
                    t.assert(body.success==true, 'could not call basic command');
                    t.assert(sh.includes(body.output, 'ran...'), 'call did not work');
                    t.cb();
                }
            }
        );


        /*

         t.add(function testCountUp() {
         var json = {};
         json.cmd = 'node test_remote_cmd_countup.js'
         t.quickRequest( urls.run_command,
         'get', result, {data: json, oneshot:false})
         function result(body) {
         console.log(body);
         t.assert(body.success==true, 'could not call basic command');
         t.assert(body.status=='started', 'could not call basic command');
         t.cb();
         }
         }
         );
         t.wait(1)
         t.add(function testCountUp() {
         var json = {};
         t.quickRequest( urls.get_output,
         'get', result, {data: json, all:false})
         function result(body) {
         console.log(body);
         t.assert(sh.includes(body.output, 'at'), 'call did not work');
         t.cb();
         }
         }
         );

         t.wait(2)
         t.add(function testCountUp() {
         var json = {};
         t.quickRequest( urls.get_output,
         'get', result, {data: json, all:false})
         function result(body) {
         console.log(body);
         t.assert(sh.includes(body.output, 'at'), 'call did not work');
         t.assert(! sh.includes(body.output, 'at 1'), 'giving me old log stuff');
         t.cb();
         }
         }
         );

         t.wait(2)
         t.add(function testCountUp() {
         var json = {};
         t.quickRequest( urls.get_output,
         'get', result, {data: json, all:true})
         function result(body) {
         console.log(body);
         t.assert(sh.includes(body.output, 'at'), 'did not get part of log');
         t.assert( sh.includes(body.output, 'at 1'), 'did not get full log');
         t.cb();
         }
         }
         );

         */
        function checkOutputFor(strMatch) {
            return function testCountUp() {

                var json = {};
                t.quickRequest(urls.get_output,
                    'get', result, {data: json, all: true})
                function result(body) {
                    console.log(body);
                    t.assert(sh.includes(body.output, strMatch), 'did not include ' + strMatch);
                    t.cb();
                }

            }
        };

        function checkOutputDoNotHave(strMatch) {
            return function testCountUp() {
                var json = {};
                t.quickRequest(urls.get_output,
                    'get', result, {data: json, all: true})
                function result(body) {
                    console.log(body);
                    t.assert( ! sh.includes(body.output, strMatch), ' output includes ' + strMatch);
                    t.cb();
                }

            }
        };





        t.add(function startPromptScript() {
                var json = {};
                json.cmd = 'node test_remote_cmd_countup_prompt.js'
                t.quickRequest( urls.run_command,
                    'get', result, {data: json, oneshot:false})
                function result(body) {
                    console.log(body);
                    t.assert(body.success==true, 'could not call basic command');
                    t.assert(body.status=='started', 'could not call basic command');
                    t.cb();
                }
            }
        );
        t.wait(4)
        t.add(function inputGo() {
                var query = {};
                query.input = 'y'
                t.quickRequest( urls.cmd_send,
                    'get', result, query)
                function result(body) {
                    console.log('body', body);
                    t.assert(body.success==true, 'could not set input');
                    //t.assert(body.status=='started', 'could not call basic command');
                    t.cb();
                }
            }
        );
        t.wait(4)
        t.add(checkOutputFor('at 5'));
        t.add(startPromptScript);

        function startPromptScript() {
            var json = {};
            json.cmd = 'node test_remote_cmd_countup_prompt.js'
            t.quickRequest( urls.run_command,
                'get', result, {data: json, oneshot:false})
            function result(body) {
                console.log(body);
                t.assert(body.success==true, 'could not call basic command');
                t.assert(body.status=='started', 'could not call basic command');
                t.cb();
            }
        }


        t.wait(4)
        t.add(function inputGo() {
                var query = {};
                query.input = 'n'
                t.quickRequest( urls.cmd_send,
                    'get', result, query)
                function result(body) {
                    console.log('body', body);
                    t.assert(body.success==true, 'could not set input');
                    //t.assert(body.status=='started', 'could not call basic command');
                    t.cb();
                }
            }
        );

        t.wait(4)
        t.add(checkOutputDoNotHave('at 5'));

    }

    p.create = function create(stg) {


        self.settings.port = stg.port;
        self.settings.port = sh.dv(self.settings.port, 15150)

        var ExpressServerHelper = shelpers.ExpressServerHelper

        var config = {}
        config.port = self.settings.port;
        config.addJquery = true;
        config.testJquery = true;

        config.addWildCards = true
        config.addWildCards_Dir = __dirname + '/' + 'ritv_requests'

        var server = ExpressServerHelper.new(config)

        //server.get('/changeEnv', self.changeEnv);

        self.server = server;
        self.helper = self.server.eSH;

        self.helper.addResourceDir(__dirname+'/'+'ritv_public_html')
        config.fx = function postStartupFx() {
            //self.postStartup()
            self.loginServer= {};
            self.loginServer.server = self.server
            sh.callIfDefined(stg.cb)

        }
        return self.server;
    }

    p.proc = function debugLogger() {
        if ( self.silent == true) {
            return
        }
        sh.sLog(arguments)
    }


}

exports.ScriptHoster = ScriptHoster;

if (module.parent == null) {
    var sH = new ScriptHoster()
    var server = sH.create({port:15151,cb:sH.test});
    sH.init(server);
}



