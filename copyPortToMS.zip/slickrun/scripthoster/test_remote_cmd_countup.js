console.log('script ran...')
for ( var i = 0 ; i < 10; i++) {
    //var i_temp = i;
      setTimeout(function (i) {
        // var i_temp = i;
          console.log('at ' + i)
    }, i*1000, i+1)
}