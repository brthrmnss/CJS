/**
 * Designed to test all ritv functions
 * @type {*}
 */

var shelpers = require('shelpers');
var sh = shelpers.shelpers;
var SettingsHelper = require('shelpers').SettingsHelper;

var ExpressServerHelper = shelpers.ExpressServerHelper
var RestHelperSQLTest = require('shelpers').RestHelperSQLTest;
var Sequelize = RestHelperSQLTest.Sequelize;
var TestServer = require('./sparkserver').TestServer;
var RouteCacheHelper = require('./RouteCacheHelper').RouteCacheHelper;
var SequelizeHelper = shelpers.SequelizeHelper;

var EasyRemoteTester = shelpers.EasyRemoteTester;

var PromiseHelperV3 = shelpers.PromiseHelperV3;
var async	= require('async');

var CommandRunner = sh.CommandRunner;

//var CredentialServerQuickStart = require('./../ritv/_credentialserver/CredentialServerQuickStart').CredentialServerQuickStart
//LoginAPIConsumerService=CredentialServerQuickStart.LoginAPIConsumerService;


function Portfolio_SparkServer() {
    var p = Portfolio_SparkServer.prototype;
    p = this;
    var self = this;

    self.loadConfig = function loadConfig(configFile, fx){
        self.configFile = configFile;
        var defaultSettings = {
            port: 10002,
            dir: 'requests/',
            //dirHtml: 'ritv_public_html/', //
            dirHtml: '../quick/', //
            mysql:{
                database:'fileserver',
                user:"root",
                password:'password',
                port:3306
            },
            wildcards:false,
            enableAnonymouse:true,
            noProxy:true,
            // force:false,
            loginAPI:{
                port:10005,
                dirSessions:sh.getUserHome()+'/'+"sessions_login_api",
                publicRoutes:['favicon.ico', 'output.html', 'output/sparrow',
                    '/output/scripts', '/output/', '/proxy?']
            },
            loginAPIConsumer:{
                baseUrl:null, //use local host,
                port:10006,
                portProducer:10005,
                dirSessions:sh.getUserHome()+'/' +"sessions_login_consumer_api"

            },
            contentProviderAPI:{
                defaultContentPath: 'ritv_requests/a.mkv',
                sendDefaultPath : true,
                port: 10015
            },
            fxDone:self.fxServerStarted
        }


        var sH = new SettingsHelper();
        self.settingsHelper = sH;
        //sH.defaultSettings = defaultSettings;

        var settingsHelperConfig = {}
        settingsHelperConfig.input = configFile;
        settingsHelperConfig.defaultSettings = defaultSettings;

        settingsHelperConfig.fxResult = function doneLoadingSettingsFile(settings) {
            self.proc('options', settings);


            //if linux, use linux root dir
            if ( sh.isWin()==false ) {
                if ( settings['dir.linux'] != null ) {
                    settings.dir = settings['dir.linux'];
                }
                if ( settings['dir.linux2'] != null ) {
                    if ( sh.fileExists( settings['dir.linux2'] ) ) {
                        settings.dir = settings['dir.linux2'];
                    }
                }
            }
            self.settings = settings;
            self.settings.noSQL = true;
            self.init2(self.settings);
        }

        self.helper = SettingsHelper.LoadSettings(settingsHelperConfig);
    }

    p.init = function init(configFile) {
        self.loadConfig(configFile)
    }

    p.init2 = function init2(settings) {
        var  s = new TestServer();

        self.settings  = settings;


        self.login = ! self.settings.enableAnonymouse  ;


        self.settings2 = sh.clone(self.settings);

        //stepNeg1();
        self.startServer(step2B);

        function stepNeg1() {
            self.createSQL(step2);
        }

        function step2() {
            if ( self.settings.enableAnonymouse != true ) {
                self.defineLoginServer(null, step2B);
            } else {
                self.startServer(step2B);
            }
        }

        function step2B() {
            self.settings.server = self.loginServer.server;
            self.settings.fxInitServer = fxInitServer;
            s.startServer(self.settings);

            self.server = s;

            //if ( true ) {
            //fake out sessions
            function fxInitServer(app) {
                var bodyParser = require('body-parser');
                var session = require('express-session');
                var cookieParser= require('cookie-parser');
                var FileStore = require('session-file-store')(session);


                self.define_YeomanRoutes(app);

                app.use(bodyParser());
                app.use(cookieParser());
                app.use(session({ store: new FileStore(
                    {path: 'anon_sessions' }),
                    secret: 'spaceyok', resave: false, saveUninitialized: true }));

            }
            var app = self.server.server;

            function setupSessionRoute() {
                app.get('/set_session', function set_session(req, res) {
                    var userSession = req.session;
                    var session = req.query; //.file;
                    ;
                    sh.copyProps(session, req.session)
                    res.json({ msg: 'success', success: true, session: req.session });
                })

            }
            setTimeout(setupSessionRoute, 1000);

            self.helper = s.server.eSH;
            /*
             //self.helper.addResourceDir(__dirname+'/../'+'public_html/dist');
             self.helper.addResourceDir(__dirname+'/'+'portfolio_dir');
             //display .tmp dir
             self.helper.addResourceDir(__dirname+'/'+'../'+'../'+'learn angular/port3/.tmp/');
             //
             self.helper.addResourceDir(__dirname+'/'+'../'+'../'+'learn angular/port3/app/');
             //bower components
             self.helper.addResourceDir(__dirname+'/'+'../'+'../'+'learn angular/port3/');
             */
            //old config





            // self.helper.addResourceDir(self.settings.dirHtml);

            step3_setupRoutes();


        }


        function deployYeoManApp(dirAppOverrides, dirYeomanApp, fileIndexAlias) {

            //U: Did you alias the index file name?
            if ( fileIndexAlias != null) {
                fileIndexAlias = dirAppOverrides + '/'+ fileIndexAlias;
                self.helper.addRoute_aliasFile('index.html', fileIndexAlias );
                self.helper.addRoute_aliasFile('index.htm', fileIndexAlias );
                self.helper.addRoute_aliasFile('/', fileIndexAlias );
            }

            //U: Ov
            //
            // erride template with personal contents
            self.helper.addResourceDir(dirAppOverrides);
            //U: serve main generated contents
            self.helper.addResourceDir(dirYeomanApp+'.tmp/');
            //U: add backup app resources are are not generated
            self.helper.addResourceDir(dirYeomanApp+'app/');
            //U: serve bower components
            self.helper.addResourceDir(dirYeomanApp);
        }

        self.define_YeomanRoutes =   function deployYeoManApp(
            server ) { //dirAppOverrides, dirYeomanApp, fileIndexAlias) {


            var _dirAppOverrides = __dirname+'/'+'portfolio_dir';
            var _dirYeomanApp = __dirname+'/'+'../'+'../'+'learn angular/port3/';
            var _dirYeomanApp = __dirname+'/'+'../'+'port3/';
            var _fileIndexAlias =/* _dirAppOverrides+'/'*/ 'port3_app.html';
            _fileIndexAlias = null;

            var express =  require('express');
            // override template with personal contents
            server.use(express.static(_dirAppOverrides));
            //U: serve main generated contents
            server.use(express.static(_dirYeomanApp+'.tmp/'));
            //U: add backup app resources are are not generated
            server.use(express.static(_dirYeomanApp+'app/'));;
            //U: serve bower components
            server.use(express.static(_dirYeomanApp));


            console.log(_dirYeomanApp+'app/')

            return;
            var _dirAppOverrides = __dirname+'/'+'portfolio_dir';
            var _dirYeomanApp = __dirname+'/'+'../'+'../'+'learn angular/port3/';
            var _fileIndexAlias =/* _dirAppOverrides+'/'*/ 'port3_app.html';
            _fileIndexAlias = null;


            //U: Did you alias the index file name?
            if ( fileIndexAlias != null) {
                fileIndexAlias = dirAppOverrides + '/'+ fileIndexAlias;
                self.helper.addRoute_aliasFile('index.html', fileIndexAlias );
                self.helper.addRoute_aliasFile('index.htm', fileIndexAlias );
                self.helper.addRoute_aliasFile('/', fileIndexAlias );
            }

            //U: Ov
            //
            // erride template with personal contents
            self.helper.addResourceDir(dirAppOverrides);
            //U: serve main generated contents
            self.helper.addResourceDir(dirYeomanApp+'.tmp/');
            //U: add backup app resources are are not generated
            self.helper.addResourceDir(dirYeomanApp+'app/');
            //U: serve bower components
            self.helper.addResourceDir(dirYeomanApp);
        }

        self.define_CommandRunnerRoutes = function define_CommandRunnerRoutes(server) {
            server.get('/run_command', function run_command(req, res) {

                var cmd = req.query.cmd
                if ( cmd != null ) {
                }

                var file = '';
                var args = [];

                var queryData = req.query.data;
                if ( queryData != null ) {
                    if ( sh.isString(queryData) &&
                        sh.startsWith(queryData, '{')) {
                        var json = JSON.parse(req.query.data)
                    }
                    json = queryData;

                    cmd = json.cmd;
                    file = json.file;
                    if ( sh.includes(json.cmd, ' ')  ) {
                        var cmds = sh.splitStringOnQuotes(json.cmd);
                        cmd = cmds.pop()
                        args = cmds
                    }
                }

                //write a config

                var CommandRunner = sh.CommandRunner
                var cR  = new CommandRunner();
                var settings ={}
                settings.cmd = cmd
                settings.args = args
                settings.silent = false;


                var fxCallbackTestComplete = function fxCallbackTestComplete() {
                    console.log('done')
                    res.json({ output: sh.toJSONString(
                        self.output),
                        success: true, session: req.session });
                }
                self.output  = ''
                settings.fxEcho =  function fxEcho(data){
                    self.output += data

                }
                settings.fxCallback =  fxCallbackTestComplete

                cR.execute(settings);

            })



            function testRunCommandRoute(fxDone) {
                var config = {}
                config.port = self.settings.port; ///sh.clone(self.settings)
                //config.resetRequest=true;
                config.fxDone = fxDone

                var t = EasyRemoteTester.create('test testRunCommandRoute',config);
                var urls = {}
                urls.run_command = t.utils.createTestingUrl('run_command')


                self.testUtils.login(t, true)


                t.add(function doSearchWithNoLogin() {
                        var json = {};
                        json.cmd = 'node portfolio_dir/test_remote_cmd.js'
                        t.quickRequest( urls.run_command,
                            'get', result, {data: json})
                        function result(body) {
                            console.log(body);
                            t.assert(body.success==true, 'could not call basic command');
                            t.cb();
                        }
                    }
                );




            }

            self.t.addInner(testRunCommandRoute);

        }

        function step3_setupRoutes() {


            self.t  = EasyRemoteTester.create('test everything');
            self.t.wait(2);


            self.define_CommandRunnerRoutes(s.server);

            self.define_fileDirListRoutes(s.server);

            self.define_Prompts(s.server);
            self.define_Prompts_Log(s.server);

            return;

            self.defineTestUserContacts(s.server);

            //self.define_runFileRoutes(s.server);

            //self.t.wait(80);
            //
            //self.defineConfigRestHelperAPI(s.server);

            //self.defineBreadcrumbRestHelper(s.server);
            //self.defineFakeContentAPI(s.server);
            //self.defineRealContentAPI(s.server, self.settings);

            //self.defineIMDBRestHelper(s.server);
            self.defineGetConfigRoute(s.server);
            self.defineUserConfigRestHelper(s.server);
            //self.define_UserRestHelper(s.server);

            self.defineProxyRoutes(s.server);

            //self.runUserAcceptenceTest(s.server);

        }
    }

    p.fxServerStarted = function fxServerStarted() {
        self.runTests();
    }


    p.startServer = function startServer(cb) {
        var config = {}
        config.port = self.settings.port;
        config.addJquery = true;
        config.testJquery = true;

        config.addWildCards = true
        config.addWildCards_Dir = __dirname + '/' + 'ritv_requests'

        var server = ExpressServerHelper.new(config)

        //server.get('/changeEnv', self.changeEnv);

        self.server = server;
        self.helper = self.server.eSH;

        self.helper.addResourceDir(__dirname+'/'+'ritv_public_html')

        //self.defineContent(server)

        config.fx = function postStartupFx() {
            //self.postStartup()
            self.loginServer= {};
            self.loginServer.server = self.server
            sh.callIfDefined(cb)

        }


    }


    p.createSQL = function createSQL(cb) {
        var mysqlSettings = sh.clone(self.settings.mysql);
        mysqlSettings.cb = finishedInitMySQL;
        var sequelize =  SequelizeHelper.createSQL(mysqlSettings);
        function finishedInitMySQL(sequelize){
            self.sequelize = sequelize;
            //distribute sqls to all sub configs
            self.settings.loginAPI.sequelize = sequelize;
            self.settings.loginAPIConsumer.sequelize = sequelize;
            sh.callIfDefined(cb)
        }
    }


    /**
     * Use CredentailsServer to QuickStart a Login Server
     * @param server
     */
    p.defineLoginServer = function defineLoginServer(server, cb) {
        ///mnt/hgfs/Dropbox/projects/crypto/ritv/_credentialserver/CredentialServerQuickStart.js
        var cQS = require('./../ritv/_credentialserver/CredentialServerQuickStart').CredentialServerQuickStart
        var cQS = new cQS();
        self.cQS = cQS;
        //cQS.startLoginAPIServer(self.settings.loginAPI);

        //alternate: run the whole test
        var cSettings = {}
        cSettings.fxDone = function loginServerRunning(){
            console.info('login server running')
            self.loginServer = self.cQS.credentialsServer;
            self.urls = {}
            self.urls.loginAPI = self.cQS.urlsLogin;

            try {
                //end ConsumerService server
                self.cQS.api2.app.close();
            } catch ( error ) {}
            sh.callIfDefined(cb);
        }

        cSettings.loginAPI = self.settings.loginAPI;
        cSettings.loginAPIConsumer = self.settings.loginAPIConsumer;

        //merge server with main server
        //cSettings.loginAPI.server = server;
        cSettings.loginAPI.port = self.settings.port;
        cSettings.loginAPIConsumer.portProducer = self.settings.port;

        cQS.testCredentialsServer(cSettings);

        //self.helper.globalMiddleware = self.cQS.credentialsServer.api.topMiddleware_BlockUsersWithoutSessions;
        //self.helper.globalMiddleware = CredentialServerQuickStart.LoginAPIService.topMiddleware_BlockUsersWithoutSessions;


        self.cQS = cQS;

    }

    /**
     * Create content API, and lock it down with login credential server
     * @param server
     */
    p.defineRealContentAPI = function defineRealContentAPI(server, settings) {

        var cPSettings = settings.contentProviderAPI;



        //var cSettings_loginAPIConsumer = self.settings.loginAPIConsumer;
        //cSettings_loginAPIConsumer.portProducer = settings.loginAPI.port;

        cPSettings.dirSessions = settings.loginAPIConsumer.dirSessions;
        cPSettings.portProducer = settings.loginAPIConsumer.portProducer;

        //create a new server for contentProviderAPI
        if (self.login == true) {
            var c = new LoginAPIConsumerService();
            c.startExampleLoginAPIConsumerService(cPSettings);
            server = c.server;
        } else {
            self.settings.contentProviderAPI.port = self.settings.port;
        }



        self.content = RestHelperSQLTest.createHelper('contents', server, {
            name:'contents',
            //routePrePend:'sim/',
            fields:{name: "", src:"", desc: "", user_id: 0, content_id: 0,
                episode:0, season:0, show_name:"",  year:0, imdb_id:"",
                series_imdb_id:""
            },
            //fxStart:testContentProviderAPIInterface,
            reset:'onlyIfNeeded',
            genData:RestHelperSQLTest.RestHelper.types.GenDataIfEmpty,
            fxReset :self.utils.generateFakeContentForContentAPI
        });

        //http://192.168.81.133:10003/find_content?limit=3&src=game%201x1
        self.find_content = function find_content(req, res) {
            self.proc('getContent', req.query)
            var q = req.query;
            if ( req.query != null && req.query.query != null  ) {
                q = JSON.parse(req.query.query)
            }

            self.content.utils.genRestOkStub(req, res);


            var query_ = {where:q}
            query_.limit = 10;
            req.query = query_;
            self.content.searchItems(req, res)
            // res.end();
        }

        server.get('/api/find_content', self.find_content);

        var contentProvider = require('./content-provider');

        //server.get('/content/:filePath', contentProvider.sendContent);
        /*server.get('/api/get_content/:filePath', function fakeFileRequestMiddleware(req, res) {
         //req.contentPath = 'ritv_requests/b.mkv';
         if ( cPSettings.sendDefaultPath == true ) {
         req.contentPath = cPSettings.defaultContentPath;
         }
         contentProvider.sendContent(req, res)
         });*/
        server.get('/api/get_content', function fakeFileRequestMiddleware(req, res) {
            req.contentPath = req.query.file;
            if ( cPSettings.sendDefaultPath == true ) {
                req.contentPath = cPSettings.defaultContentPath;
            }
            contentProvider.sendContent(req, res)
        });

        function testContentProviderAPIInterface(fxDone) {

            //do search
            //make request for fake content;

            //login

            //do search
            //make fake request

            var c = sh.clone(cPSettings)
            c.fxDone = fxDone;
            var t = EasyRemoteTester.create('test Real Content Provider API', c);


            var urls = {}
            urls.search = t.utils.createTestingUrl('api/find_content')
            urls.getContent = t.utils.createTestingUrl('api/get_content')
            urls.verifyConsumer = t.utils.createTestingUrl('api/verify');
            t.settings.portOverride = self.settings.loginAPI.port;
            urls.login = t.utils.createTestingUrl('api/login');
            t.settings.portOverride = null;


            if ( self.login != false ) {

                t.add(function doSearchWithNoLogin() {
                        t.quickRequest( urls.search,
                            'get', result, {name: "randomTask"})
                        function result(body) {
                            console.log(body);
                            t.assert(body.success==false, 'no ok');
                            t.cb();
                        }
                    }
                );



                self.cQS.testUtils.loginFail(t, urls.login, 'mark', 'randomTask')
                self.cQS.testUtils.login(t, urls.login, 'mark', 'randomTask2')
                self.cQS.testUtils.verifyKey(t, urls.verifyConsumer, t.key)
            }
            t.add(function doSearchAfterLogin() {
                    t.quickRequest( urls.search,
                        'get', result, {name: "randomTask"})
                    function result(body) {
                        t.assert(body.length>=0, 'post-verify did not let me do a search');
                        t.cb();
                    }
                }
            );

            t.add(function doSearchWithIMDBId() {
                    t.quickRequest( urls.search,
                        'get', result, {imdb_id: "tt101"})
                    function result(body) {
                        t.assert(body.length>0, 'post-verify did not let me do a search');
                        t.cb();
                    }
                }
            );
            t.add(function doSearchWithLikeInName() {
                    t.quickRequest( urls.search,
                        'get', result, {name: {like:"%Emp%"}});
                    function result(body) {
                        console.log('body', body)
                        t.content = body[0]
                        if ( body.success==false){
                            throw 'not logged in anymore'
                        }
                        t.assert(body.length>0, 'post-verify did not let me do a search');
                        t.cb();
                    }
                }
            );


            t.add(function reqMovie() {
                    t.quickRequest( urls.getContent,
                        'get', result, {file: t.content.src, test:true});
                    /*t.quickRequest( urls.getContent+'/'+t.content.src,
                     'get', result );*/
                    function result(body) {
                        console.log('body', body)
                        t.assert(body=='test ok', 'could not get that content');
                        t.cb();
                    }
                }
            );


            /* console.log = function () {
             //return;
             }*/
            var res = {}
            res.ok = function ok(o) {
                console.log('response was', o )
            }

            var req = {}
            req.ok = function ok(o) {
                console.log('response was', o )
            }

            req.query = { where: {title: { like: '%awe%' } }}
            req.query = {where: Sequelize.and(
                { name: 'a project' },
                Sequelize.or(
                    { id: [1, 2, 3] },
                    { id: { gt: 10 } }
                )
            )}


            req.query = {where:
                Sequelize.and(
                    { src: {like:"%Game%"} },
                    {episode:  2 },
                    {season:  2 }
                    /*Sequelize.or(
                     { id: [1, 2, 3] },
                     { id: { gt: 10 } }
                     )*/
                )
            }

            req.query = {
                name:"game",
                season: 2,
                episode: 3
            }
            //self.content.searchItems(req, res)
            //self.find_content(req, res)

            req.method = 'GET'
            req.contentPath = cPSettings.defaultContent;
            //req.contentPath = 'ritv_requests/a.mp4';
            req.headers = {}
            //contentProvider.sendContent(req, res)

        }

        self.t.addInner(testContentProviderAPIInterface);
    }



    p.define_Prompts = function defineBreadcrumbRestHelper(server) {
        //server = self.cQS.credentialsServer.api;
        self.prompts = RestHelperSQLTest.createHelper('prompt',
            server,
            {
                name:'prompt',
                fields:
                {name: "", desc: "", user_id: 0, imdb_id: "", minutes: 0,
                    one_per_day:true, data:"" , data_json:"text"},
                fxUserId:self.utils.getUserIdFromSession,
                noSQL:self.settings.noSQL,
                //fxGetUserId:LoginAPIConsumerService.pullSessionIDFromRequest,
                //fxStart:testBreadCrumbsUserId
                //port:self.settings.port,
            }
        );
        function testBreadCrumbsUserId(fxDone) {
            var config = {}
            config.port = self.settings.port; ///sh.clone(self.settings)
            //config.resetRequest=true;
            config.fxDone = fxDone

            var t = EasyRemoteTester.create('test Breadcrumbs API',config);
            var urls = {}
            urls.getBreadcrumbs = t.utils.createTestingUrl('api/breadcrumbs')
            urls.getContent = t.utils.createTestingUrl('api/get_content')
            urls.verifyConsumer = t.utils.createTestingUrl('api/verify');
            t.settings.portOverride = self.settings.loginAPI.port;
            urls.login = t.utils.createTestingUrl('api/login');
            t.settings.portOverride = null;

            if ( self.login ) {
                self.cQS.testUtils.logout(t, self.urls.loginAPI.logout)
                t.add(function getBreadcrumbs() {
                        t.quickRequest( urls.getBreadcrumbs,
                            'get', result, {name: "randomTask"})
                        function result(body) {
                            t.assert(body.success==false, 'no ok');
                            t.cb();
                        }
                    }
                );
            }

            self.testUtils.login(t)
            //self.cQS.testUtils.login(t, urls.login, 'mark', 'randomTask2')

            self.breadcrumbs.defineTestUtils(t);

            var newImdb = {imdb_id:456456, name:'g'}
            self.breadcrumbs.testUtils.create_get(t, newImdb)
            //self.breadcrumbs.testUtils.create(t, newImdb )
            self.breadcrumbs.testUtils.search(t, {name: "randomTask"})

        }
        //self.t.addInner(testBreadCrumbsUserId);
    }

    p.define_Prompts_Log = function define_Prompts_RestHelper(server) {
        //server = self.cQS.credentialsServer.api;
        self.promptsLog = RestHelperSQLTest.createHelper('promptlog',
            server,
            {
                name:'promptlog',
                fields:
                {name: "", desc: "", user_id: 0, color: "", comments: "",
                    data:"", progress:0, data_json:"text"},
                fxUserId:self.utils.getUserIdFromSession,
                noSQL:self.settings.noSQL,
                //fxGetUserId:LoginAPIConsumerService.pullSessionIDFromRequest,
                //fxStart:testBreadCrumbsUserId
                //port:self.settings.port,
            }
        );

        function testBreadCrumbsUserId(fxDone) {
            var config = {}
            config.port = self.settings.port; ///sh.clone(self.settings)
            //config.resetRequest=true;
            config.fxDone = fxDone

            var t = EasyRemoteTester.create('test Breadcrumbs API',config);
            var urls = {}
            urls.getBreadcrumbs = t.utils.createTestingUrl('api/breadcrumbs')
            urls.getContent = t.utils.createTestingUrl('api/get_content')
            urls.verifyConsumer = t.utils.createTestingUrl('api/verify');
            t.settings.portOverride = self.settings.loginAPI.port;
            urls.login = t.utils.createTestingUrl('api/login');
            t.settings.portOverride = null;


            if ( self.login ) {
                self.cQS.testUtils.logout(t, self.urls.loginAPI.logout)
                t.add(function getBreadcrumbs() {
                        t.quickRequest( urls.getBreadcrumbs,
                            'get', result, {name: "randomTask"})
                        function result(body) {
                            t.assert(body.success==false, 'no ok');
                            t.cb();
                        }
                    }
                );
            }



            self.testUtils.login(t)
            //self.cQS.testUtils.login(t, urls.login, 'mark', 'randomTask2')

            self.breadcrumbs.defineTestUtils(t);

            var newImdb = {imdb_id:456456, name:'g'}
            self.breadcrumbs.testUtils.create_get(t, newImdb)
            //self.breadcrumbs.testUtils.create(t, newImdb )
            self.breadcrumbs.testUtils.search(t, {name: "randomTask"})
            /* t.add(function getBreadcrumbs() {
             t.quickRequest( urls.getBreadcrumbs,
             'get', result, {name: "randomTask"})
             function result(body) {
             t.assert(body.success==false, 'no ok');
             t.cb();
             }
             }
             );*/





        }
       // self.t.addInner(testBreadCrumbsUserId);
    }

    p.defineBreadcrumbRestHelper = function defineBreadcrumbRestHelper(server) {
        //server = self.cQS.credentialsServer.api;
        self.breadcrumbs = RestHelperSQLTest.createHelper('breadcrumbs',
            server,
            {
                name:'breadcrumbs',
                fields:
                {name: "", desc: "", user_id: 0, imdb_id: "", content_id: 0,
                    progress:0},
                fxUserId:self.utils.getUserIdFromSession
                ,
                //fxGetUserId:LoginAPIConsumerService.pullSessionIDFromRequest,
                fxStart:testBreadCrumbsUserId
                //port:self.settings.port,
            }
        );



        function testBreadCrumbsUserId(fxDone) {
            var config = {}
            config.port = self.settings.port; ///sh.clone(self.settings)
            //config.resetRequest=true;
            config.fxDone = fxDone

            var t = EasyRemoteTester.create('test Breadcrumbs API',config);
            var urls = {}
            urls.getBreadcrumbs = t.utils.createTestingUrl('api/breadcrumbs')
            urls.getContent = t.utils.createTestingUrl('api/get_content')
            urls.verifyConsumer = t.utils.createTestingUrl('api/verify');
            t.settings.portOverride = self.settings.loginAPI.port;
            urls.login = t.utils.createTestingUrl('api/login');
            t.settings.portOverride = null;


            if ( self.login ) {
                self.cQS.testUtils.logout(t, self.urls.loginAPI.logout)
                t.add(function getBreadcrumbs() {
                        t.quickRequest( urls.getBreadcrumbs,
                            'get', result, {name: "randomTask"})
                        function result(body) {
                            t.assert(body.success==false, 'no ok');
                            t.cb();
                        }
                    }
                );
            }



            self.testUtils.login(t)
            //self.cQS.testUtils.login(t, urls.login, 'mark', 'randomTask2')

            self.breadcrumbs.defineTestUtils(t);

            var newImdb = {imdb_id:456456, name:'g'}
            self.breadcrumbs.testUtils.create_get(t, newImdb)
            //self.breadcrumbs.testUtils.create(t, newImdb )
            self.breadcrumbs.testUtils.search(t, {name: "randomTask"})
            /* t.add(function getBreadcrumbs() {
             t.quickRequest( urls.getBreadcrumbs,
             'get', result, {name: "randomTask"})
             function result(body) {
             t.assert(body.success==false, 'no ok');
             t.cb();
             }
             }
             );*/





        }

        self.t.addInner(testBreadCrumbsUserId);
    }


    p.defineUserConfigRestHelper = function defineSettingsRestHelper(server) {
        //server = self.cQS.credentialsServer.api;
        self.userConfigs = RestHelperSQLTest.createHelper('user_configs',
            server,
            {
                name:'user_configs',
                fields:
                {name: "", desc: "", user_id: 0, type: "", config: ""},
                fxUserId:self.utils.getUserIdFromSession,
                //fxStart:testBreadCrumbsUserId,
                //port:self.settings.port
            }
        );




        function testBreadCrumbsUserId(fxDone) {
            return;
            var config = {}
            config.port = self.settings.port; ///sh.clone(self.settings)
            //config.resetRequest=true;

            var t = EasyRemoteTester.create('test Breadcrumbs API',config);
            var urls = {}
            urls.getBreadcrumbs = t.utils.createTestingUrl('api/breadcrumbs')
            urls.getContent = t.utils.createTestingUrl('api/get_content')
            urls.verifyConsumer = t.utils.createTestingUrl('api/verify');
            t.settings.portOverride = self.settings.loginAPI.port;
            urls.login = t.utils.createTestingUrl('api/login');
            t.settings.portOverride = null;


            self.cQS.testUtils.logout(t, self.urls.loginAPI.logout)

            t.add(function getBreadcrumbs() {
                    t.quickRequest( urls.getBreadcrumbs,
                        'get', result, {name: "randomTask"})
                    function result(body) {
                        t.assert(body.success==false, 'no ok');
                        t.cb();
                    }
                }
            );

            self.cQS.testUtils.login(t, urls.login, 'mark', 'randomTask2')
            self.breadcrumbs.defineTestUtils(t);

            var newImdb = {imdb_id:456456, name:'g'}
            self.breadcrumbs.testUtils.create_get(t, newImdb)
            self.breadcrumbs.testUtils.search(t, {name: "randomTask"})
        }
    }

    p.defineGetConfigRoute = function defineGetConfigRoute(server) {
        server.get('/api/config', function returnConfig(req, res) {
            res.json(self.settings2);
        }) //add to an array of testing objetcs ...
        /*
         setTimeout(function () {
         testConfig();
         }, 8000);
         */
        function testConfig(fx){
            var config = {}
            config.port = self.settings.port; ///sh.clone(self.settings)
            //config.resetRequest=true;
            config.fxDone = fx;
            var t = EasyRemoteTester.create('test get confi API',config);
            var urls = {}
            urls.getConfig = t.utils.createTestingUrl('api/config')

            //self.cQS.testUtils.login(t, self.urls.loginAPI.login, 'mark', 'randomTask2')
            self.testUtils.login(t);

            t.add(function getConfig() {
                    t.quickRequest( urls.getConfig,
                        'get', result, {name: "randomTask"})

                    function result(body) {
                        t.assert(body.success!=false, 'could not get config');
                        t.cb();
                    }
                }
            );


        }


        //self.t.addInner(testConfig);

    }

    var path = require('path')
    var fs = require("fs")
    //http://127.0.0.1:10001/filelist
    p.define_fileDirListRoutes = function define_fileDirListRoutes(server) {
        server.get('/filelist/*', function(req, res) {
            //rewriters

            var dir = null;
            if ( req.query.dir != null ) {
                dir = req.query.dir;
            }
            if ( req.params != null ) {
                dir = req.params[0]
            }

            if ( sh.fileExists(dir) == false ) {
                res.json({success:false})
                return
            }
            var isDir = sh.isDirectory(dir)

            function getFile(file) {
                var filePath = dir;
                var stats = fs.statSync(filePath)
                stats.isDir = false;
                stats.path = filePath;
                stats.filename = path.basename(filePath);

                return stats
            }

            if ( isDir ) {
                var files = sh.getFilesInDirectory(dir, false, false, true  )

                var ret = {} ;
                ret.files = files;


                ret.details = fs.readdirSync(dir);

                function getFileDetails() {
                    var fs = require("fs")
                    var files = fs.readdirSync(dir);
                    var output = [];
                    for (var i in files) {
                        try {
                            if (!files.hasOwnProperty(i)) continue;
                            var fileName = files[i];
                            var name = dir + '/' + files[i];
                            var stats = fs.statSync(name)
                            stats.isDir = stats.isDirectory()
                            stats.path = name;
                            stats.filename = fileName;
                            output.push(stats);
                        } catch (e) {
                        }
                    }
                    return output;
                }
                ret.details = getFileDetails()

                res.json(ret);
            } else {

                var ret = {};
                ret.file = getFile()

                res.json(ret);
            }

        })





        function test_define_fileDirListRoutes(fxDone) {
            var config = {}
            config.port = self.settings.port; ///sh.clone(self.settings)
            //config.resetRequest=true;
            config.fxDone = fxDone

            var t = EasyRemoteTester.create('test testRunCommandRoute',config);
            var urls = {}
            urls.filelist = t.utils.createTestingUrl('filelist')


            self.testUtils.login(t, true)


            t.add(function getBasicFile() {
                    t.quickRequest( urls.filelist+'/'+'test.json',
                        'get', result, {})
                    function result(body) {
                        console.log(body);
                        t.assert(body.file.filename ==
                            'test.json', 'no ok');
                        t.cb();
                    }
                }
            );


            t.add(function getBasicFile2() {
                    t.quickRequest( urls.filelist+'/'+'slickrun_html',
                        'get', result, {})
                    function result(body) {
                        console.log(body);
                        t.assert(body.files.length > 2 , 'no ok');
                        t.cb();
                    }
                }
            );

            t.add(function getBadFile() {
                    t.quickRequest( urls.filelist+'/'+'slickcrun_html',
                        'get', result, {})
                    function result(body) {
                        console.log(body);
                        t.assert(body.success == false , 'no ok');
                        t.cb();
                    }
                }
            );



        }

        self.t.addInner(test_define_fileDirListRoutes);


    };

    //http://127.0.0.1:10001/api/test_contacts/count
    p.defineTestUserContacts = function defineTestUserContacts(server) {
        var testContactsHelperSettings = {
            name:'test_contacts',
            fields:
            {name: "", desc: "", user_id: 0, imdb_id: 0, image: "",
                rating:0, year:0, genre:"", series:true, series_name:"",
                series_id:0, seasons:0, episode:0,
                first_name:'', last_name:'', gender:'',
                street:'', city:'', state:'', zip_code:'',
                email:''},
            requiredFields:{
                first_name:''
            }
        }
        self.test_contacts = RestHelperSQLTest.createHelper(
            'test_contacts', server, testContactsHelperSettings);



        /*
         self.userConfigs = RestHelperSQLTest.createHelper('user_configs',
         server,
         {
         name:'user_configs',
         fields:
         {name: "", desc: "", user_id: 0, type: "", config: ""},
         fxUserId:self.utils.getUserIdFromSession,
         //fxStart:testBreadCrumbsUserId,
         //port:self.settings.port
         }
         );
         */
    }

    p.defineIMDBRestHelper = function defineIMDBRestHelper(server) {
        var restHelperSettings = {
            name:'imdbs',
            fields:
            {name: "", desc: "", user_id: 0, imdb_id: 0, image: "",
                rating:0, year:0, genre:"", series:true, series_name:"",
                series_id:0, seasons:0, episode:0}
            //fxStart:testIMDBs
        }
        self.imdbs = RestHelperSQLTest.createHelper('imdbs', server, restHelperSettings);

        var getImdbIdRoute = '/api/imdb_ids'
        server.get('/api/imdb_ids', function get_imdb_ids(req, res) {


            var token = {}
            var work = new PromiseHelperV3();
            token.silentToken = true
            work.wait = token.simulate == false;
            work.startChain(token)

            work.add(function getunderscoreIdsFromRequest() {
                var idsO = req.query.ids;
                var ids = sh.splitStrIntoArray(idsO);
                if ( ids == null || ids.length == 0  ) {
                    res.end('[]')
                    work.stop();
                    return
                }
                ids = sh.array.removeNulls(ids, true)
                token.ids = ids;
                work.next();
            })
            work.add(function checkDatabases() {
                var query = {where:{imdb_id:token.ids}}
                var searchSettings  = {};
                searchSettings.fxResult = gotResult;
                searchSettings.query  = query;
                token.oldResults= [];

                function gotResult(results){
                    var dbIds = sh.arrayCollectProp(results, 'imdb_id')
                    var _ = require('underscore')._
                    token.imdbIdsToGet = _(token.ids).difference(dbIds);
                    token.imdbIdsToGet = sh.array.removeNulls(token.imdbIdsToGet);
                    token.oldResults = results;
                    work.next();
                }
                self.imdbs.search(searchSettings)
            })
            work.add(function getFromIMDB() {

                /*
                 async.eachLimit(urls, 10,
                 function( domainToRequest, callback){
                 //console.log(domainToRequest);
                 request( domainToRequest, function done(body, response, error ) {
                 gotHTML(body, response, error, callback)
                 } );
                 },
                 function onAllURLsSaved(err){
                 self.proc('saveData')
                 sh.callIfDefined(self.settings.fxDone);
                 saveData();
                 }
                 )
                 */

                var contentItemsToCreate = [];
                token.contentItemsToCreate=contentItemsToCreate
                async.eachLimit(token.imdbIdsToGet, 10,
                    function getId(imdb_id, callback) {
                        var imdb_api_get_content =
                            require('./../ritv/imdb_movie_scraper/imdb_api_get_content').imdb_api_get_content;

                        var i = new imdb_api_get_content();
                        if (sh.startsWith(imdb_id, 'tt') == false) {
                            callback()
                            return;
                        }
                        i.getContent(imdb_id, function haveContent(content) {
                            callback();
                            contentItemsToCreate.push(content);
                        });

                    },
                    function finished(err){

                        work.next();
                    })
            })
            work.add(function saveToDatabase() {

                token.newResults= [];
                self.imdbs.settings.actor.bulkAdd(
                    token.contentItemsToCreate,
                    function saveFinished(results)
                    {
                        /*if ( err != null ) {
                         throw err;
                         }*/

                        token.newResults = results;
                        work.next();
                    })

            })
            work.add(function packageResponse() {
                var output = token.oldResults;
                output = output.concat(token.newResults)

                var output2 = sh.arrayCallMethodOnItem(output, 'get')
                output2 = JSON.stringify(output2)
                res.end(output2);
            })


            //res.end();
        });

        //self.addToTest(testIMDBs)
        self.t.addInner(testIMDBs);
        function testIMDBs(fxDone) {

            var t = EasyRemoteTester.create('testIMDBs', {fxDone:fxDone});

            self.testUtils.login(t);

            function testChain(token, cb) {
                console.log('testChain');
                cb();
            }
            t.add(testChain);
            function testChain2(token, cb) {
                console.log('testChain2');
                t.quickRequest(self.createTestingUrl(getImdbIdRoute),
                    'get', result, {name: "randomTask"})
                function result(body) {
                    //t.assert(body=='4', 'msg .... ');
                    t.cb();
                }
            }


            t.add(testChain2);

            t.add(function testRouteIsValid() {
                t.quickRequest(self.createTestingUrl(getImdbIdRoute),
                    'get', result, {name: "randomTask"})
                function result(body) {
                    //t.notError('route is not defined');
                    //t.assert(body!=null, 'route is not defined');
                    if ( sh.isString(body) ) {
                        t.assert(!sh.startsWith(body, 'Cannot GET'), 'route is not defined');
                    }
                    t.assert(body=='[]' || body.length ==0, 'route not responding to bad input')
                    t.cb();
                }
            })

            t.add(function testGet1Imdb() {
                t.quickRequest(self.createTestingUrl(getImdbIdRoute),
                    'get', result, {ids: "tt0068646"})
                function result(body) {
                    t.assert( body.length = 1, 'converting item failed');
                    //t.notError('route is not defined');
                    //t.assert(body!=null, 'route is not defined');
                    t.cb();
                }
            })

            t.add(function testGet1Imdb2() {
                t.quickRequest(self.createTestingUrl(getImdbIdRoute),
                    'get', result, {ids: ["tt0068646", 'tt0141842'] })
                function result(body) {
                    t.assert( body.length == 2, 'converting item failed');
                    t.cb();
                }
            })

            function clearItemsInDB(){

                var y = {}
                y.deleteRecordFromQuery = function deleteRecordFromQuery(name,
                                                                         query, cb ) {

                    var imdbDeleteRoute = 'api/' + restHelperSettings.name + '/delete';
                    var imdbRoute_Get = 'api/' +  restHelperSettings.name  + '/get';

                    var route_search = 'api/' + name+ '/search';
                    var route_delete = 'api/' + name  + '/delete';
                    /*      t.add(function deleteItem1Items() {

                     })
                     t.add(function deleteItem2Items() {
                     t.quickRequest(self.createTestingUrl(imdbDeleteRoute),
                     'get', result, {id: 'tt0141842' })
                     function result(body) {
                     //t.assert( body.length == 2, 'converting item failed');
                     t.cb();
                     }
                     })
                     t.add(function getDeleteItem() {
                     t.quickRequest(self.createTestingUrl(imdbRoute_Get),
                     'get', result, {id: 'tt0141842' })
                     function result(body) {
                     t.assert( body == '', 'item not deleted');
                     t.cb();
                     }
                     })*/


                    var token = {}
                    var work = new PromiseHelperV3();
                    token.silentToken = true
                    work.wait = token.simulate == false;
                    work.startChain(token)

                    work.add(function getItem() {
                        t.quickRequest(self.createTestingUrl(route_search),
                            'get', result, query)
                        function result(body) {
                            if ( body.length == 0 ) {
                                sh.callIfDefined(cb);
                                work.stop();
                                return;
                            }
                            token.deleteId = body[0].id
                            //t.assert( body.length == 2, 'converting item failed');
                            work.next();
                            //Error: record does not existError: could not find id tt0068646
                        }
                    })
                    work.add(function deleteItem() {
                        t.quickRequest(self.createTestingUrl(route_delete),
                            'get', result, {id: token.deleteId });
                        function result(body) {
                            work.next();
                        }
                    })
                    work.add(function verifyItemGone() {
                        t.quickRequest(self.createTestingUrl(route_search),
                            'get', result, query)
                        function result(body) {
                            if ( body.length != 0 ) {
                                throw 'could not delete item'
                            }
                            //
                            work.next();
                        }

                        if ( cb ) { cb() };
                    })
                }

                t.add(function removeItem() {
                    y.deleteRecordFromQuery(
                        'imdbs', {imdb_id: "tt0068646"}, t.cb
                    )
                })

                t.add(function removeItem() {
                    y.deleteRecordFromQuery(
                        'imdbs', {imdb_id: "tt0141842"}, t.cb
                    )
                })


            }
            clearItemsInDB();

            t.add(function testGet1Imdb2() {
                t.quickRequest(self.createTestingUrl(getImdbIdRoute),
                    'get', result, {ids: ["tt0068646",, 'tt0141842'] })
                function result(body) {
                    t.assert( body.length == 2, 'converting item failed');
                    t.cb();
                }
            })


            function changeEverything() {
                //create one, request both
                //request

                t.add(function removeItem() {
                    y.deleteRecordFromQuery(
                        'imdbs', {imdb_id: "tt0141842"}, t.cb
                    )
                })
                t.add(function testGet1Imdb2() {
                    t.quickRequest(self.createTestingUrl(getImdbIdRoute),
                        'get', result, {ids: ["tt0068646",, 'tt0141842'] })
                    function result(body) {
                        t.assert( body.length == 2, 'deleted 1 item, both items were not returned');
                        t.cb();
                    }
                })


                t.add(function testGet1Imdb2_justTry() {
                    t.quickRequest(self.createTestingUrl(getImdbIdRoute),
                        'get', result, {ids: ["tt0068646",, 'tt0141842'] })
                    function result(body) {
                        t.assert( body.length == 2, 'deleted 1 item, both items were not returned');
                        t.cb();
                    }
                })

            }

            /*
             t.testChain2 = function testChain() {
             console.log('testChain');
             t.cb();
             }
             work.add(t.testChain2);
             */
        }
    }


    p.defineProxyRoutes = function defineProxyRoutes(server) {
        var rH = new RouteCacheHelper();
        server.use('/proxy', function proxy(req, res, next){
            if ( rH.handle({
                    id:'test images',
                    strategy:'file',
                    dir:'proxy_test_request',
                    method:'get',
                    maxSize:10
                }, req, res) ) { return; };
            next();
        });

        var rH = new RouteCacheHelper();
        server.use('/proxy2', function proxy(req, res, next){
            if ( rH.handle({
                    id:'test images',
                    strategy:'file',
                    dir:'proxy_test_request',
                    method:'get',
                    maxSize:10
                }, req, res) ) { return; };
            next();
        });
        self.server.setupProxy(server);

    }

    /**
     * Go through steps users takes to authenticate
     * @param server
     */
    p.runUserAcceptenceTest = function runUserAcceptanceTest(server) {
        function defineUAT(fxDone) {
            var settings =  (self.settings);
            settings.fxDone = fxDone;
            var t = EasyRemoteTester.create('test UAT integrative API', self.settings);



            self.testUtils.login(t);
            //self.cQS.testUtils.login(t, self.urls.loginAPI.login, 'mark', 'randomTask2')
            self.breadcrumbs.testUtils.search(t);
            //search
            //watch something

            self.userConfigs.defineTestUtils(t, self.settings);
            self.userConfigs.testUtils.search(t, {name:'ritv'});

            var config = {lang:'english', color:'red'}
            config = sh.toJSONString( config)
            self.userConfigs.testUtils.create_get(t,
                {name:'ritv', config:config,
                    upsertQuery:{name:'ritv'}
                });


        }
        // sh.waitXSecs(5, defineUAT );

        self.t.addInner(defineUAT);

    }

    function defineTestHelpers() {
        self.startupTests = [];
        self.addToTest = function addToTests(item, name) {
            self.startupTests.push({name:name, fx:item})
        }
        self.runTests = function runTests(item, name) {

            sh.each(self.startupTests, function runTest(k,v){
                sh.logLine = function logLine(times) {
                    sh.times(times, function(){console.log();});
                }
                sh.times = function times(count, fx) {
                    for (var i = 0; i < count; i++) {
                        fx(i);
                    }
                }
                sh.logLine(3)
                self.proc('running test', v.name)
                sh.logLine(3)
                v.fx();
            })
            // self.startupTests.push({name:name, item:item})
        }

        self.createTestingUrl = function createTestingUrl(end){
            var url = 'http://localhost:' + self.settings.port ;//+ '/' + end;
            if ( ! sh.startsWith(end , '/')){
                url += '/';
            }
            url += end;

            return url;
        }
    }
    defineTestHelpers();


    function defineUtils() {
        self.utils = {}
        self.utils.generateFakeContentForContentAPI = function generateFakeContentForContentAPI() {
            var GenerateData = shelpers.GenerateData;
            var gen = new GenerateData();

            var input = ['Game of Thrones', '4x12', 'The Blacklist',
                'Empire', "Grey's Anatomy", '6x20',
                "Schindler's List", 'Raging Bull', 'the Godfather', ''];

            function addSrc(obj) {
                obj.src = ''
                var content = 'content/';
                /*sh.str.ifStr(obj.series, 'series/')+
                 sh.str.ifStr(obj.series && obj.name != null, obj.name+'/')+
                 sh.str.ifStr(obj.series && obj.name != null, obj.name+'/')+
                 '.mp4'*/
                if (obj.series == true) {
                    content += 'series/';
                    if (obj.series_name != null) {
                        content += obj.series_name //+ ' - '
                    }
                    if (obj.name != null) {
                        content += ' - ' + obj.name //+ ' - '
                    }
                    content += ' ' + obj.season + 'x' + obj.episode;
                }
                else {
                    //if ( obj.name != null ) {
                    content += obj.name// + ' - '

                    if ( obj.name == 'Raging Bull') {
                        obj.year = 1980
                        obj.imdb_id = 'tt0081398'
                    }
                    if ( obj.name == 'the Godfather') {
                        obj.year = 1972
                        obj.imdb_id = 'tt0068646'
                    }


                    //}
                    //content += obj.season + ' x ' + obj.episode;
                }

                content += '.mp4';
                obj.src = content;

            }

            function isNumber(n) {
                return !isNaN(parseFloat(n)) && isFinite(n);
            }


            function makeArray(input) {
                var output = []
                var prev = {}
                for (var i = 0; i < input.length; i++) {
                    var item = input[i]

                    var next = input[i + 1];

                    var firstNumber = false

                    if (next != null) {
                        firstNumber = next.slice(0, 1)
                    }


                    if (isNumber(firstNumber)) {
                        i++;


                        output.pop();


                        var s = next.split('x')[0];
                        var e = next.split('x')[1];
                        s = parseInt(s)
                        e = parseInt(e)
                        for (var sea = 1; sea < s; sea++) {

                            for (var epi = 1; epi < e; epi++) {
                                var obj = sh.clone(prev);
                                obj.season = sea;
                                obj.episode = epi;
                                obj.series = true;
                                obj.series_name = item;

                                addSrc(obj);

                                obj.desc = item + ' ' +
                                    obj.season + 'x' + obj.episode;
                                output.push(obj);
                            }

                        }


                        continue;
                    }

                    var obj = {}
                    obj.name = item;
                    obj.desc = item;
                    addSrc(obj);
                    output.push(obj);
                    prev = obj;

                }
                return output
            }


            var output = makeArray(input)
            var model = gen.create(output, function (item, id, dp) {
                //item.name = id;
                // item.id = id;
                //item.desc = GenerateData.getName();

                item.imdb_id= sh.dv(item.imdb_id,'tt'+(id+100));
            });

            return model;
        }

        self.convertQueryParamToQuery = function (req) {
            //TODO: move this code somewhere else
            var query = req.query;//JSON.parse(req.query);

            if ( req.query.pquery != null ) {
                query =JSON.parse( req.query.pquery )
            }

            var andLimits = [];
            andLimits.push({ src: {like:"%"+query.name+"%"} })
            if (query.season_name) {
                andLimits.push({ src: {like: "%" + query.season_name + "%"} })
            }
            if (query.episode) {
                andLimits.push({ episode:query.episode });
            }
            if (query.season) {
                andLimits.push({ season:query.season });
            }

            if (query.year && false == true ) {
                andLimits.push({ year:  query.year  })
            }
            var arr =  Sequelize.and.apply(this, andLimits)

            var query_ = {where:query}
            query_.limit = 10;
            req.query = query_;
        }

        self.utils.getUserIdFromSession = function getUserIdFromSession(req){
            if ( self.login == false ) {
                return 2;
                //return null;
            }
            return req.session.user_id;
        }
    }
    defineUtils();

    function defineTestUtils() {
        self.testUtils = {}

        self.testUtils.login = function login(t, logOut) {
            if ( self.login== false) {
                return;
            }

            //TODO: Wire up differently
            if ( logOut && self.login ) {
                self.cQS.testUtils.logout(t, self.urls.loginAPI.logout)
                t.add(function getBreadcrumbs() {
                        t.quickRequest( urls.getBreadcrumbs,
                            'get', result, {name: "randomTask"})
                        function result(body) {
                            t.assert(body.success==false, 'no ok');
                            t.cb();
                        }
                    }
                );
            }


            self.cQS.testUtils.login(t, self.urls.loginAPI.login, 'mark', 'randomTask2')
        }
        self.login = self.testUtils.login;
    }
    defineTestUtils();

    /**
     * Receive log commands in special format
     */
    p.proc = function proc() {
        sh.sLog(arguments)
    }

}






var s = new Portfolio_SparkServer()
s.init();

