/**
 * Created by user on 12/17/14.
 */
var sh = require('shelpers').shelpers
var PromiseHelper = require('shelpers').PromiseHelper;
var OptionsHelper = require('shelpers').OptionsHelper
//var SettingsHelper = require('shelpers').SettingsHelper

var cfg =  require('./config.js');
 //cfg.


var Sequelize = require('sequelize')
, sequelize = new Sequelize(cfg.db.database, cfg.db.user, cfg.db.password, {
    dialect: "mysql", // or 'sqlite', 'postgres', 'mariadb'
    port:    cfg.db.port, // or 5432 (for postgres)
        define: {
            timestamps: false,
        }
})




var UserContents= require('./models/contentAccess.js')(sequelize,Sequelize);
var User = require('./models/userAccounts')(sequelize,Sequelize);
var Content = require('./models/content.js')(sequelize,Sequelize);

//UserContents.hasOne(User);
UserContents.belongsTo(User, {as:'User', foreignKey:'userId'});
UserContents.belongsTo(Content, {as:'Content', foreignKey:'contentId'});
//UserContents.belongsTo(User)
//UserContents.belongsTo(Content)

/*
 with new promise helpers
 search for content, query==>url
 */
function TestLogin() {

    var p = TestLogin.prototype;
    p = this;
    var self = this;

    self.defineUtils = function defineUtils() {
        self.utils = {};
        self.utils.createIt = function createIt(props){
            console.log(props.msg)
            var user = props.model.build(props.hash)

            user.save()
                .complete(function(err) {
                    if (!!err) {
                        console.log('The instance has not been saved:', err)
                    } else {
                        console.log('We have a persisted instance now')
                        props.callbackRetry(props.token, probs.callback)
                    }
                })

            return
        }

        self.utils.getItemIfNotDefinedRetry = function getItemIfNotDefinedRetry(props){
            props.query = sh.defaultValue(props.query);
            var itemName = props.model.toString();

            props.model.find(props.query).success(function(resultObj) {

                //console.log('...')

                if ( resultObj == null ) {

                    self.utils.createIt(props)


                    return
                }

                props.storeItem = sh.dv(props.storeItem, itemName)
                props.token[props.storeItem] //.user= user;
                cb()
            })


        }
    }

    self.go = function go(options) {
        var paramsHelper = new OptionsHelper();
        paramsHelper.loadOptions(options)
        var fxCallback = paramsHelper.addOption('callback', 'completion callback', true)
        var query = paramsHelper.addOption('query',
            'what torrent to look for', false)

        var token = sh.clone(options)
        self.token = token
        token.query=query
        token.silentToken = true
        token.fxCallback=fxCallback;
        //token.bail = false
        //token.test = options.test;
        var work = new PromiseHelper();
        work.name = 'Template Chain'
        work.wait = token.simulate==false;
        work.startChain(token)
            .add(self.connectToDb)
            .add(self.syncDatabaseDefintion)
            .add(self.getUser)
            .add(self.getContent)
            .log()
            .add(self.createUserContent)
            .log()
            .end();
    }

    function defineWork() {
        p.connectToDb = function connectToDb(token, cb) {
            sequelize
                .authenticate()
                .complete(function(err) {
                    if (!!err) {
                        console.log('Unable to connect to the database:', err, err.stack)
                    } else {
                        console.log('Syced successfully.')
                        cb();
                    }
                })

        }
        p.syncDatabaseDefintion = function syncDatabaseDefintion(token, cb) {
            sequelize.sync({force: true}).complete(function (err) {
                if (!!err) {
                    console.log('Unable to sync the database:', err, err.stack)
                } else {
                    console.log('Connection has been established successfully.')
                    cb();
                }
            });
            return;


        }

        p.getUser = function getUser(token, cb) {
            self.utils.getItemIfNotDefinedRetry(
                {
                    model:User,
                    props:{
                        username: 'user1',
                        password: "password",
                        email: "user@user.com",
                        token: "234234"
                        //  password: generatePasswordHash('i-am-so-great')
                    },
                    msg:'User does not exists...',
                    callback:cb,
                    token:token,
                    callbackRetry:self.getUser
                }

            )


            return;
            User.find({}).success(function(user) {

                // project will be an instance of Project and stores the content of the table entry
                // with id 123. if such an entry is not defined you will get null
                console.log('...')

                if ( user == null ) {

                    self.utils.createIt(
                        {
                        model:User,
                        props:{
                            username: 'user1',
                            password: "password",
                            email: "user@user.com",
                            token: "234234"
                            //  password: generatePasswordHash('i-am-so-great')
                        },
                        msg:'User does not exists...',
                        callback:cb,
                        token:token,
                        callbackRetry:self.getUser
                    }
                    )

                    console.log('user was null...')
                    var user = User.build({
                        username: 'user1',
                        password: "password",
                        email: "user@user.com",
                        token: "234234"
                        //  password: generatePasswordHash('i-am-so-great')
                    })

                    user.save()
                        .complete(function(err) {
                            if (!!err) {
                                console.log('The instance has not been saved:', err)
                            } else {
                                console.log('We have a persisted instance now')
                                self.getUser(token, cb)
                            }
                        })

                    return
                }


                token.user= user;
                cb()
            })

        }
        p.getContent = function getContent(token, cb) {
            Content.find({}).success(function(content) {
                // project will be an instance of Project and stores the content of the table entry
                // with id 123. if such an entry is not defined you will get null
                console.log('...')
                if ( content == null ) {
                    console.log('content null...')
                    var content = Content.build({
                        name: 'Test Content',
                        fileName: "hhh.txt",
                        path :"D",
                        type: "type?"
                        //  password: generatePasswordHash('i-am-so-great')
                    })

                    content.save()
                        .complete(function(err) {
                        if (!!err) {
                            console.log('The instance has not been saved:', err)
                        } else {
                            console.log('We have a persisted instance now')
                            self.getContent(token, cb)
                        }
                    })

                    return
                }
                token.content= content;
                cb()
            })

        }
        p.createUserContent = function createUserContent(token, cb) {
            var userContent = UserContents.build({
                clientIP: 'john-doe',
                //  password: generatePasswordHash('i-am-so-great')
            })


            userContent.setContent(token.content)
            userContent.setUser(token.user)
//sdfgdf.d
            cb();
            return
            userContent
                .save()
                .complete(function(err) {
                    if (!!err) {
                        console.log('The instance has not been saved:', err)
                    } else {
                        console.log('We have a persisted instance now')
                    }
                })
        }


        var cfg = {}
        cfg.defaultUserEmail = 'test2@email.com'
        cfg.defaultUserPassword = 'test2'
        p.signup  = function signup (token, cb, returnReq) {
            var reqoptions = {}
            reqoptions.url = 'http://localhost:8000/auth/signup'
            reqoptions.form = {}
            reqoptions.form.email = cfg.defaultUserEmail
            reqoptions.form.password = cfg.defaultUserPassword
            reqoptions.fx = cb;
            reqoptions.name = 'good login attempt'
            reqoptions.bodyNotEqual = 'USER_NOT_EXIST'
            if ( returnReq){
                return reqoptions
            }
            reqPost(reqoptions)
        }

        p.signupBad = function signupBad(token, cb, returnReq) {
            var reqoptions = self.signup(null, null, true)
            reqoptions.name = 'bad signup attempt'
            reqoptions.fx = cb;
            reqPost(reqoptions)
        }



        p.downloadPutIoFile = function downloadPutIoFile(token, cb) {
            cb()
        }

        p.uploadToMegaUpload = function uploadToMegaUpload(token, cb) {

        }
    }
    defineWork()

    function createLogic() {
        p.logic = {}
        /**
         * return urlMagnet
         * @param token
         * @param cb
         */
        p.logic.returnMagnetLink = function returnMagnetLink(token, cb) {
            self.proc(token.torrentName)
            cb()
            token.fxCallback(token.urlMagnet)

        }
    }
    createLogic();

    function defineUtils() {
        p.utils = {}
    }
    defineUtils();

    p.proc = function proc() {
        sh.sLog(arguments)
    }
}

if (module.parent == null) {
    //var args = process.argv.splice(2);

    var options = {}
    options.callback = function onDone(url){
        console.log('done', url)
    }
    options.query = '5th Element'
    var go = new TestLogin()
    go.go(options);
    return;

}