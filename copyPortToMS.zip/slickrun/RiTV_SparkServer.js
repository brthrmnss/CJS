/**
 * Created by user on 1/5/15.
 */
/*


 host jquery
 host bootstrap

 make route to get path


 */




/**
 * Created by user on 1/5/15.
 */
/*
 program will run commands
 has autocomplete

 history
 fallback and fall through
 */

var shelpers = require('shelpers')
var sh = shelpers.shelpers
var ExpressServerHelper = shelpers.ExpressServerHelper
var TestHelper = shelpers.TestHelper;
var reqPost = TestHelper.reqPost;
var RestHelperSQLTest = require('shelpers').RestHelperSQLTest;
var Sequelize = RestHelperSQLTest.Sequelize;


throw 'dont use this one';

function RitvTestListServer() {
    var p = RitvTestListServer.prototype;
    p = this;
    var self = this;

    p.start = function start() {

        self.linux = true
        self.win = false;
        self.mac = false;


    }

    p.startServer = function startServer() {
        var config = {}
        config.port = 10003
        config.addJquery = true;
        config.testJquery = true;

        config.addWildCards = true
        config.addWildCards_Dir = __dirname + '/' + 'ritv_requests'

        var server = ExpressServerHelper.new(config)

        server.get('/changeEnv', self.changeEnv);

        self.server = server;
        self.helper = self.server.eSH;

        self.helper.addResourceDir(__dirname+'/'+'ritv_public_html')

        self.settings = {}
        self.settings.port = 10003


        self.defineContent(server)

        config.fx = function postStartupFx() {
            self.postStartup()
        }


    }

    p.defineContent = function defineContent(server) {
        self.content = RestHelperSQLTest.createHelper('contents', server, {
            name:'contents',
            fields:{name: "", src:"", desc: "", user_id: 0, content_id: 0,
                episode:0, season:0, show_name:"",  year:0, imdb_id:""
            },
            fxStart:runTest,
            fxReset :function fxReset() {
                GenerateData = shelpers.GenerateData;
                var gen = new GenerateData();

                var input =  ['Game of Thrones', '4x12', 'The Blacklist',
                    'Empire', "Grey's Anatomy", '6x20',
                    "Schindler's List", 'Raging Bull', 'the Godfather', ''];

                function addSrc(obj) {
                    obj.src =  ''
                    var content = 'content/';
                    /*sh.str.ifStr(obj.series, 'series/')+
                     sh.str.ifStr(obj.series && obj.name != null, obj.name+'/')+
                     sh.str.ifStr(obj.series && obj.name != null, obj.name+'/')+
                     '.mp4'*/
                    if ( obj.series == true) {
                        content += 'series/';
                        if ( obj.series_name != null ) {
                            content += obj.series_name //+ ' - '
                        }
                        if ( obj.name != null ) {
                            content += ' - ' + obj.name //+ ' - '
                        }
                        content += ' ' + obj.season + 'x' + obj.episode;
                    }
                    else {
                        //if ( obj.name != null ) {
                        content += obj.name// + ' - '
                        //}
                        //content += obj.season + ' x ' + obj.episode;
                    }

                    content += '.mp4';
                    obj.src = content;

                }

                function isNumber(n) {
                    return !isNaN(parseFloat(n)) && isFinite(n);
                }


                function makeArray(input) {
                    var output =[]
                    var prev  = {}
                    for (var i = 0; i < input.length; i++) {
                        var item = input[i]

                        var next = input[i+1];

                        var firstNumber = false

                        if ( next != null ){
                            firstNumber = next.slice(0,1)
                        }


                        if ( isNumber(firstNumber) ) {
                            i++;




                            output.pop();


                            var s = next.split('x')[0];
                            var e = next.split('x')[1];
                            s = parseInt(s)
                            e = parseInt(e)
                            for (var sea = 1; sea < s; sea++) {

                                for (var epi = 1; epi < e; epi++) {
                                    var obj = sh.clone(prev);
                                    obj.season = sea;
                                    obj.episode = epi;
                                    obj.series = true;
                                    obj.series_name = item;

                                    addSrc(obj);

                                    obj.desc = item  + ' ' +
                                        obj.season  + 'x' + obj.episode;
                                    output.push(obj);
                                }

                            }


                            continue;
                        }

                        var obj = {}
                        obj.name = item;
                        obj.desc = item;
                        addSrc(obj);
                        output.push(obj);
                        prev = obj;

                    }
                    return output
                }


                var output = makeArray(input)
                var model = gen.create(output, function (item, id, dp) {
                    //item.name = id;
                    // item.id = id;
                    //item.desc = GenerateData.getName();
                });

                return model;
            }
        });




        //http://192.168.81.133:10003/gX?limit=3&src=game%201x1
        //
        self.gX = function gX(req, res) {
            self.proc('change', req.query)
            var q = req.query;
            res.ok = function ok(x){
                if ( req.ok != null ) {
                    req.ok(x);
                    return;
                }
                res.send(x)
            }
            var query = req.query;//JSON.parse(req.query);

            if ( req.query.pquery != null ) {
                query =JSON.parse( req.query.pquery )
            }

            var andLimits = [];
            andLimits.push({ src: {like:"%"+query.name+"%"} })
            if (query.season_name) {
                andLimits.push({ src: {like: "%" + query.season_name + "%"} })
            }
            if (query.episode) {
                andLimits.push({ episode:query.episode });
            }
            if (query.season) {
                andLimits.push({ season:query.season });
            }

            if (query.year && false == true ) {
                andLimits.push({ year:  query.year  })
            }
            var arr =  Sequelize.and.apply(this, andLimits)

            var query_ = {where:arr}

            /*
                Sequelize.and(
                    { src: {like:"%Game%"} },
                    {episode:  2 },
                    {season:  2 }
                    *//*Sequelize.or(
                     { id: [1, 2, 3] },
                     { id: { gt: 10 } }
                     )*//*
                )
            }
            */
            req.query = query_;

            self.content.searchItems(req, res)
            // res.end();
        }

        server.get('/gX', self.gX);


        var contentProvider = require('./content-provider');

        var defaultContent = 'ritv_requests/a.mkv'
        server.get('/content/:filePath', contentProvider.sendContent);
        //server.get('/getcontent/:filePath', contentProvider.sendContent);
        server.get('/getcontent/:filePath', function fakeFileRequestMiddleware(req, res) {
            req.contentPath = 'ritv_requests/b.mkv';
            req.contentPath = defaultContent
            contentProvider.sendContent(req, res)
        });



        function runTest() {

           /* console.log = function () {
                //return;
            }*/
            var res = {}
            res.ok = function ok(o) {
                console.log('response was', o )
            }

            var req = {}
            req.ok = function ok(o) {
                console.log('response was', o )
            }

            req.query = { where: {title: { like: '%awe%' } }}
            req.query = {where: Sequelize.and(
                { name: 'a project' },
                Sequelize.or(
                    { id: [1, 2, 3] },
                    { id: { gt: 10 } }
                )
            )}


            req.query = {where:
                Sequelize.and(
                    { src: {like:"%Game%"} },
                    {episode:  2 },
                    {season:  2 }
                    /*Sequelize.or(
                     { id: [1, 2, 3] },
                     { id: { gt: 10 } }
                     )*/
                )
            }

            req.query = {
                name:"game",
                season: 2,
                episode: 3
            }
            //self.content.searchItems(req, res)
            self.gX(req, res)

            req.method = 'GET'
            req.contentPath = defaultContent;
            //req.contentPath = 'ritv_requests/a.mp4';
            req.headers = {}
            //contentProvider.sendContent(req, res)

        }
    }

    p.postStartup = function postStartup() {
        function testRoutes() {
            return
            /*
             self.testX();
             self.test2();
             self.quickRequest('testMethod')
             self.quickRequest('testPost', 'post')
             self.quickRequest('final/api/hart')
             */
            //self.server.eSH.quickRequest('jquery.js')
            //self.server.eSH.testHelper.verifyResponse('jquedry.js')
            //self.server.eSH.testHelper.verifyResponse('jquery.js')
            //TODO alias long methods ....
            self.server.eSH.testHelper.verifyResponse('testMethod.json')

            self.server.eSH.testHelper.quickRequest('todolist.html')
        }
        testRoutes()
    }

    function testRoutes() {
        p.testX = function testX() {
            var reqoptions = {}
            reqoptions.url = 'http://localhost:'+self.settings.port+'/changeEnv'
            reqoptions.form = {}
            reqoptions.method = 'GET'
            reqoptions.fx2 = function storeContents(body){
                self.proc('test ok...')
            };
            reqoptions.name = 'test changeEnv'
            self.proc('testing...')
            reqPost(reqoptions)
        }
        p.test2 = function test2() {
            var reqoptions = {}
            reqoptions.url = 'http://localhost:'+self.settings.port+'/post/jgrew'
            reqoptions.form = {}
            reqoptions.method = 'GET'
            reqoptions.showBody =  true;
            reqoptions.fx2 = function storeContents(body){
                self.proc(reqoptions.url, 'test ok...')
            };
            reqoptions.name = 'test changeEnv'
            self.proc('testing...')
            reqPost(reqoptions)
        }
        p.quickRequest = function quickRequest(url, method, fx) {
            if ( method == null ) {
                method = 'GET'
            }
            var reqoptions = {}
            reqoptions.url = 'http://localhost:'+self.settings.port+'/'+url
            reqoptions.form = {}
            reqoptions.method = method
            reqoptions.showBody =  true;
            reqoptions.fx2 = function storeContents(body){
                self.proc(reqoptions.url, 'test ok...')
            };
            reqoptions.name = 'test ' + sh.paren(url)
            self.proc('testing...')
            reqPost(reqoptions)
        }
    }
    testRoutes()


    self.changeEnv = function changeEnv(req, res) {
        self.proc('change');
        res.end();
    }

    p.init = function init() {
        self.startServer();
        self.start();
    }

    /**
     * Receive log commands in special format
     */
    p.proc = function proc() {
        sh.sLog(arguments)
    }

}




var s = new RitvTestListServer()

s.init();

