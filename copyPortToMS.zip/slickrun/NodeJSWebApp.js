/**
 * Created by smorris1 on 1/3/14.
 * Combines spark server
 * and hosts directory ,
 * returns reference to server
 */
var sh = require('shelpers').shelpers;

function NodeJSWebApp() {
    var p = NodeJSWebApp.prototype;
    p = this;
    var self = this;
    p.startup = function startup(config) {

        var defaults = {}
        defaults.port = 10001

        defaults.dir_public = filename.name;

        defaults

        self.settings = config;

        self.startServer()

    }

    p.startServer = function startServer(config) {
        var server = new SparkServer();


        server.startServer(self.settings)



    }

    p.proc = function debugLogger() {
        if ( self.silent == true) {
            return
        }
        sh.sLog(arguments)
    }


}


if (module.parent == null) {

}


exports.NodeJSWebApp = NodeJSWebApp;

